# Selected six native images

This is a review-derived ZIP of byte-identical selected originals, named front/side/back/closeup/pose/depth.png for convenient delivery. Source paths, native pixels and SHA are in source-selection.json. It is not a collage, crop, upscale or new image generation. Failed/blocked attempts remain in the separate complete-run and review history. Pose/depth are illustrative; no exact latent3D or real-person size accuracy claim.
