import pathlib,json,numpy as np,vtk
from vtk.util.numpy_support import numpy_to_vtk
p=pathlib.Path(__file__).resolve().parent;r=p.parents[2];a=json.load(open(r/'web/human-studio/assets/human.json'));ids=np.array(a['bodyVertexIds']);names=[b['name'] for b in a['bones']];v=[];f=[]
for l in open(r/'work/full-imagegen-hillclimb-20261118/iteration-1/eval-1-original-product/with_skill/run-1/outputs/model-fit/final/posed.obj'):
 if l.startswith('v '):v.append(list(map(float,l.split()[1:4])))
 if l.startswith('f '):f.append([int(t)-1 for t in l.split()[1:]])
v=np.array(v);f=np.array(f);si=np.array(a['skinIndices']).reshape(-1,4)[ids];sw=np.array(a['skinWeights']).reshape(-1,4)[ids];fc=np.zeros(len(f),int);ws={}
for s,k in [('L',1),('R',2)]:
 w=(np.isin(si,[i for i,n in enumerate(names) if 'arm' in n and n.endswith('.'+s)])*sw).sum(1);ws[s]=w;fc[w[f].mean(1)>=.25]=k
mesh=vtk.vtkPolyData();pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(v,deep=True));mesh.SetPoints(pts);ca=vtk.vtkCellArray()
for face in f:ca.InsertNextCell(3,face.tolist())
mesh.SetPolys(ca);cs=numpy_to_vtk(np.array([[188,194,203],[242,139,45],[41,152,218]],np.uint8)[fc],deep=True,array_type=vtk.VTK_UNSIGNED_CHAR);cs.SetNumberOfComponents(3);mesh.GetCellData().SetScalars(cs)
mapper=vtk.vtkPolyDataMapper();mapper.SetInputData(mesh);mapper.SetScalarModeToUseCellData();mapper.SetColorModeToDirectScalars();actor=vtk.vtkActor();actor.SetMapper(mapper);actor.GetProperty().SetAmbient(.35);actor.GetProperty().SetDiffuse(.65)
ren=vtk.vtkRenderer();ren.SetBackground(.97,.98,.99);ren.AddActor(actor);win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.AddRenderer(ren);win.SetSize(1000,1000);cam=ren.GetActiveCamera();cam.ParallelProjectionOn();cam.SetViewUp(0,1,0)
for name,close in [('guide_side_parity',False),('guide_side_closeup_parity',True)]:
 cam.SetUseExplicitProjectionTransformMatrix(False)
 if close:
  upper=v[(ws['L']+ws['R']>.25)];cen=upper.mean(0);cen[1]=np.percentile(upper[:,1],60);scale=30
 else:cen=(v.min(0)+v.max(0))/2;scale=(v[:,1].max()-v[:,1].min())*.54
 cam.SetPosition(*(cen+np.array([400,0,0])));cam.SetFocalPoint(*cen);cam.SetParallelScale(scale);ren.ResetCameraClippingRange()
 mat=vtk.vtkMatrix4x4();mat.DeepCopy(cam.GetProjectionTransformMatrix(1.,-1.,1.))
 for j in range(4):mat.SetElement(0,j,-mat.GetElement(0,j))
 cam.SetExplicitProjectionTransformMatrix(mat);cam.SetUseExplicitProjectionTransformMatrix(True);win.Render();cap=vtk.vtkWindowToImageFilter();cap.SetInput(win);cap.Update();wr=vtk.vtkPNGWriter();wr.SetFileName(str(p/(name+'.png')));wr.SetInputConnection(cap.GetOutputPort());wr.Write()
