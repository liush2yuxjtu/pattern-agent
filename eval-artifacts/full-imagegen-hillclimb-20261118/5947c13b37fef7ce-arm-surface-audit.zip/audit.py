import json, pathlib, hashlib, sys, collections
import numpy as np, vtk
from vtk.util.numpy_support import numpy_to_vtk, vtk_to_numpy
ROOT=pathlib.Path(__file__).resolve().parents[3]; OUT=pathlib.Path(__file__).resolve().parent
BASE=ROOT/'work/full-imagegen-hillclimb-20261118/iteration-1/eval-1-original-product/with_skill/run-1/outputs/model-fit/final'
A=ROOT/'web/human-studio/assets/human.json'; asset=json.load(open(A)); ids=np.array(asset['bodyVertexIds']); names=[b['name'] for b in asset['bones']]
def obj(p):
 v=[];f=[]
 for l in open(p):
  if l.startswith('v '):v.append(list(map(float,l.split()[1:4])))
  if l.startswith('f '):f.append([int(t.split('/')[0])-1 for t in l.split()[1:]])
 return np.array(v),np.array(f)
V,F=obj(BASE/'posed.obj');N,FN=obj(BASE/'neutral.obj');assert np.array_equal(F,FN)
remap={int(v):i for i,v in enumerate(ids)};SF=np.array([[remap[i] for i in t] for t in np.array(asset['indices']).reshape(-1,3)])
assert np.array_equal(F,SF),(F.shape,SF.shape)
SI=np.array(asset['skinIndices']).reshape(-1,4)[ids]; SW=np.array(asset['skinWeights']).reshape(-1,4)[ids]
def weights(pred):return (np.isin(SI,[i for i,n in enumerate(names) if pred(n)])*SW).sum(1)
W={s:weights(lambda n,s=s:('upperarm' in n or 'lowerarm' in n) and n.endswith('.'+s)) for s in ['L','R']}
TW=weights(lambda n:n.startswith(('spine','breast','clavicle','shoulder')))
# Broad union: every triangle incident on >=0.25 arm-influenced vertex, not just pure interiors.
ARM={s:np.where(W[s][F].max(1)>=.25)[0] for s in W}
TORSO=np.where((TW[F].max(1)>=.25)&((W['L']+W['R'])[F].mean(1)<.50))[0]
adj=[set() for _ in V]
for a,b,c in F:
 adj[a].update([b,c]);adj[b].update([a,c]);adj[c].update([a,b])
near3=[]
for i in range(len(V)):
 seen={i};front={i}
 for _ in range(3):front=set().union(*(adj[j] for j in front))-seen;seen|=front
 near3.append(seen)
def poly(faces,colors=None):
 p=vtk.vtkPolyData();points=vtk.vtkPoints();points.SetData(numpy_to_vtk(V,deep=True));p.SetPoints(points)
 ca=vtk.vtkCellArray()
 for face in faces:ca.InsertNextCell(3,face.tolist())
 p.SetPolys(ca)
 if colors is not None:
  cs=numpy_to_vtk(np.array(colors,dtype=np.uint8),deep=True,array_type=vtk.VTK_UNSIGNED_CHAR);cs.SetNumberOfComponents(3);p.GetCellData().SetScalars(cs)
 return p
TP=poly(F[TORSO]);results={}; contacts={}
for side,af in ARM.items():
 c=vtk.vtkCollisionDetectionFilter();c.SetInputData(0,poly(F[af]));c.SetInputData(1,TP)
 for i in [0,1]:m=vtk.vtkMatrix4x4();m.Identity();c.SetMatrix(i,m)
 c.SetCollisionModeToAllContacts();c.SetBoxTolerance(0);c.SetCellTolerance(1e-10);c.SetNumberOfCellsPerNode(2);c.Update()
 pairs=[]; rejected=0
 for i in range(c.GetNumberOfContacts()):
  ai=int(af[c.GetContactCells(0).GetValue(i)]);ti=int(TORSO[c.GetContactCells(1).GetValue(i)])
  if any(int(b) in near3[int(a)] for a in F[ai] for b in F[ti]):rejected+=1;continue
  cp=c.GetContactsOutput().GetCell(i);p=[c.GetContactsOutput().GetPoint(cp.GetPointId(k)) for k in range(cp.GetNumberOfPoints())]
  aw={n:float((((SI[F[ai]]==names.index(n))*SW[F[ai]]).sum(1)).mean()) for n in names if ('arm' in n) and n.endswith('.'+side)}
  pairs.append({'arm_face_zero_based':ai,'torso_face_zero_based':ti,'arm_source_vertex_ids':ids[F[ai]].tolist(),'torso_source_vertex_ids':ids[F[ti]].tolist(),'contact_segment_cm':p,'arm_neutral_centroid_cm':N[F[ai]].mean(0).tolist(),'bone_weight_mean':aw})
 contacts[side]=pairs;results[side]={'arm_candidate_faces':len(af),'arm_candidate_vertices':len(np.unique(F[af])),'raw_contact_segments':c.GetNumberOfContacts(),'excluded_within_3_topology_hops':rejected,'remote_contact_segments':len(pairs),'remote_arm_faces':len(set(p['arm_face_zero_based'] for p in pairs)),'remote_torso_faces':len(set(p['torso_face_zero_based'] for p in pairs))}
# Semantic category per triangle: strongest arm mean weight or torso/rest.
fc=np.zeros(len(F),int)
for side,k in [('L',1),('R',2)]:fc[W[side][F].mean(1)>=.25]=k
colors=np.array([[188,194,203],[242,139,45],[41,152,218]],dtype=np.uint8)[fc]
full=poly(F,colors);locator=vtk.vtkStaticCellLocator();locator.SetDataSet(full);locator.BuildLocator()
# Occlusion uses first actual triangle hit, no bone markers; sampled every arm triangle centroid.
visibility={}
for axis,title in [(0,'side_plusX'),(2,'front_plusZ')]:
 visibility[title]={}
 for side,k in [('L',1),('R',2)]:
  faceids=np.where(fc==k)[0];vis=[]
  for fi in faceids:
   p=V[F[fi]].mean(0);start=p.copy();start[axis]=V[:,axis].max()+100;end=p.copy();end[axis]-=.01
   t=vtk.mutable(0.);pt=[0.,0.,0.];pc=[0.,0.,0.];sid=vtk.mutable(0);cid=vtk.mutable(0)
   hit=locator.IntersectWithLine(start,end,1e-7,t,pt,pc,sid,cid)
   if hit and np.linalg.norm(np.array(pt)-p)<.025:vis.append(int(fi))
  visibility[title][side]={'total_semantic_arm_faces':len(faceids),'visible_centroid_faces':len(vis),'visible_face_ids':vis}
# Scientific offscreen render exact OBJ, opaque depth test; +X matches runtime side.
renderer=vtk.vtkRenderer();renderer.SetBackground(.97,.98,.99);window=vtk.vtkRenderWindow();window.SetOffScreenRendering(1);window.AddRenderer(renderer);window.SetSize(1000,1000)
mapper=vtk.vtkPolyDataMapper();mapper.SetInputData(full);mapper.SetScalarModeToUseCellData();mapper.SetColorModeToDirectScalars();actor=vtk.vtkActor();actor.SetMapper(mapper);actor.GetProperty().SetAmbient(.35);actor.GetProperty().SetDiffuse(.65);renderer.AddActor(actor)
cam=renderer.GetActiveCamera();cam.ParallelProjectionOn();cam.SetViewUp(0,1,0)
def render(name,pos,center,scale):
 cam.SetPosition(*pos);cam.SetFocalPoint(*center);cam.SetParallelScale(scale);renderer.ResetCameraClippingRange();window.Render();cap=vtk.vtkWindowToImageFilter();cap.SetInput(window);cap.Update();wr=vtk.vtkPNGWriter();wr.SetFileName(str(OUT/(name+'.png')));wr.SetInputConnection(cap.GetOutputPort());wr.Write()
center=(V.min(0)+V.max(0))/2;scale=(V[:,1].max()-V[:,1].min())*.54
render('side_plusX',center+np.array([400,0,0]),center,scale);render('front_plusZ',center+np.array([0,0,400]),center,scale)
upper=V[(W['L']+W['R']>.25)];cen=upper.mean(0);cen[1]=np.percentile(upper[:,1],60)
render('side_closeup',cen+np.array([400,0,0]),cen,30);render('front_closeup',cen+np.array([0,0,400]),cen,30)
report={'method':'Independent VTK triangle intersection, broad skin-influence sets, source bodyVertexIds OBJ mapping, exclude <=3 topology hops. Opaque true-mesh rendering. First-hit cell-locator visibility of triangle centroids. Units cm.','vertices':len(V),'triangles':len(F),'torso_faces':len(TORSO),'results':results,'contacts':contacts,'visibility':visibility,'hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [A,BASE/'neutral.obj',BASE/'posed.obj',BASE/'final-state.json',pathlib.Path(__file__)]}}
(OUT/'audit.json').write_text(json.dumps(report,indent=2));print(json.dumps({'results':results,'visibility':{a:{s:{k:v for k,v in vals.items() if k!='visible_face_ids'} for s,vals in x.items()} for a,x in visibility.items()}},indent=2))
