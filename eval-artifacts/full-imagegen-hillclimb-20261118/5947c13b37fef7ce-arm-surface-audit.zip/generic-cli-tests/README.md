# Generic semantic render CLI checks

Tool: `tools/human_fit/pose_guided/render_semantic_view.py`

CLI accepts `--asset --mesh --camera --view --out` (PNG filename). It reads source topology, compact `bodyVertexIds`, four-channel skin weights and camera `views[view].axis/px_per_cm/center_cm` plus canvas dimensions. Outputs opaque semantic PNG, exact visible mask, labels and source/matrix metadata. Front/side/back projection; no auto-fit. Side screen-right +Z and nearer +X, explicitly mirrored relative to conventional +X look-at/up+Y image.

Requirements are existing `numpy` and `opencv-python`; CPU rasterization needs no VTK, graphics server or display credentials. The tool is standalone, and has no imports from fitting/runtime/grader code.

Actual fresh case side and front CLIs exit0; viewed both images. Additional actual 320×400 front probe named `probe`, scale2px/cm and center(3,125), also exit0 and viewed. Independent expected projection checks, known first-hit near-L elbow label, back-axis matrix, and mismatched OBJ face-order rejection all pass in verification.json. Same-side camera matrix and known visible elbow surface projection exactly match earlier frozen VTK guide (0px difference); visible orange mask IoU0.98948, with rasterization/antialias differences. This does not claim every boundary pixel is identical.

Provenance: the earlier `../native_side_semantic.png` was rendered by the original VTK audit script before this CLI existed. It remains unchanged (SHA256 6cee59cef05d1217d58fc1eed06f1c171c3beb506add3bce795e098e83bef40d). These new side/front/probe images are outputs of the new CLI. The fresh actor continues using the earlier frozen image. Neither image is a grading oracle.

Limitations: exact source/compact OBJ order and topology required; input centimetres/Y up required; weights provide approximate face semantics rather than anatomical segmentation; hands remain grey; opaque mesh visibility does not infer bone visibility under garments or collision freedom. Lighting differs from VTK. It never modifies pose, mesh, input camera, asset, runtime or old outputs.

Full commands and source hashes are preserved in commands.txt, each output JSON and verification.json. This verifies CLI behavior/projection, not a product/anatomy PASS.
