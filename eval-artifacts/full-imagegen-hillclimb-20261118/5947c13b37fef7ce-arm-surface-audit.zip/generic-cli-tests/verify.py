import importlib.util,json,pathlib,hashlib,numpy as np,cv2
P=pathlib.Path(__file__).resolve().parent;ROOT=P.parents[3];tool=ROOT/'tools/human_fit/pose_guided/render_semantic_view.py';sp=importlib.util.spec_from_file_location('semantic',tool);mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
asset=ROOT/'web/human-studio/assets/human.json';mesh=ROOT/'work/full-imagegen-hillclimb-20261118/iteration-1/eval-1-original-product/with_skill/run-1/outputs/model-fit/final/posed.obj';camera=mesh.parent/'views/camera.json';v,f=mod.read_obj(mesh);a=json.load(open(asset));cam=json.load(open(camera));anchor=np.array([39.93133135266667,124.82256625333333,13.644826057666668,1.]);native=json.load(open(P.parent/'native_side_semantic.json'));checks={}
for view,name in [('side','side'),('front','front')]:
 metadata=json.load(open(P/(name+'.json')));mat=np.array(metadata['world_xyz1_to_pixel_xy']);point=mat@anchor;expected=np.array([384+6*anchor[2],1086-6*anchor[1]]) if view=='side' else np.array([384+6*anchor[0],1086-6*anchor[1]])
 error=float(np.linalg.norm(point-expected));assert error<1e-9;label=cv2.imread(str(P/(name+'.labels.png')),0)[int(point[1]),int(point[0])];assert label==2
 checks[view]={'anchor_pixel':point.tolist(),'expected_pixel':expected.tolist(),'error_px':error,'visible_anchor_label':int(label),'canvas':metadata['canvas']}
assert np.array_equal(np.array(json.load(open(P/'side.json'))['world_xyz1_to_pixel_xy']),np.array(native['projection_pixel_matrix_worldXYZ1']))
checks['same_native_projection_matrix']=True
checks['frozen_native_anchor_difference_px']=float(np.linalg.norm(np.array(native['anchor_projected_pixel_xy'])-np.array(checks['side']['anchor_pixel'])))
image=cv2.imread(str(P.parent/'native_side_semantic.png'))[:,:,::-1].astype(float);old=(image[:,:,0]>image[:,:,2]*1.5)&(image[:,:,0]>image[:,:,1]*1.2);new=cv2.imread(str(P/'side.labels.png'),0)==2
checks['orange_visible_mask_iou_with_frozen_vtk']=float((old&new).sum()/(old|new).sum());assert checks['orange_visible_mask_iou_with_frozen_vtk']>.98
checks['mask_comparison_limit']='Frozen VTK orange inferred by RGB ratios; CPU hard labels vs VTK antialiasing. IoU is not pixel-identical claim. Known visible surface anchor projection error is exactly zero.'
frontprobe=json.load(open(P/'front-probe.json'));pt=np.array(frontprobe['world_xyz1_to_pixel_xy'])@anchor;expected=np.array([160+2*(anchor[0]-3),200-2*(anchor[1]-125)]);assert np.linalg.norm(pt-expected)<1e-9;assert frontprobe['canvas']==[320,400];assert cv2.imread(str(P/'front-probe.labels.png'),0)[int(pt[1]),int(pt[0])]==2
checks['front_small_custom_probe']={'view':'probe','axis':frontprobe['axis'],'canvas':frontprobe['canvas'],'px_per_cm':2,'center_cm':[3,125],'anchor_pixel':pt.tolist(),'error_px':float(np.linalg.norm(pt-expected))}
wrong=f.copy();wrong[[0,1]]=wrong[[1,0]]
try:mod.semantic_faces(a,v,wrong);raise AssertionError('Mismatched topology incorrectly accepted')
except ValueError as exc:checks['mismatched_face_order_rejected']=str(exc)
_,_,backmatrix,backdepth,_=mod.projection(cam,'back');assert np.array_equal(backdepth,[0,0,-1]);assert np.array_equal(backmatrix,[[-6,0,0,384],[0,-6,0,1086]])
checks['back_axis_probe']={'matrix':backmatrix.tolist(),'nearer_depth_axis':backdepth.tolist()}
checks['tool_sha256']=mod.sha(tool);checks['frozen_native_sha256_unchanged']=mod.sha(P.parent/'native_side_semantic.png');assert checks['frozen_native_sha256_unchanged']==native['image_sha256'];checks['verdict']='PASS for listed CLI/projection checks; no anatomy or generation PASS claim'
(P/'verification.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks,indent=2))
