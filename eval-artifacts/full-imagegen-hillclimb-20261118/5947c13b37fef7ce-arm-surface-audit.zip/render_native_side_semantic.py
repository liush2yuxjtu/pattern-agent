import pathlib,json,numpy as np,vtk
from vtk.util.numpy_support import numpy_to_vtk
p=pathlib.Path(__file__).resolve().parent;r=p.parents[2];a=json.load(open(r/'web/human-studio/assets/human.json'));ids=np.array(a['bodyVertexIds']);names=[b['name'] for b in a['bones']];v=[];f=[]
for l in open(r/'work/full-imagegen-hillclimb-20261118/iteration-1/eval-1-original-product/with_skill/run-1/outputs/model-fit/final/posed.obj'):
 if l.startswith('v '):v.append(list(map(float,l.split()[1:4])))
 if l.startswith('f '):f.append([int(t)-1 for t in l.split()[1:]])
v=np.array(v);f=np.array(f);si=np.array(a['skinIndices']).reshape(-1,4)[ids];sw=np.array(a['skinWeights']).reshape(-1,4)[ids];fc=np.zeros(len(f),int);ws={}
for s,k in [('L',1),('R',2)]:
 w=(np.isin(si,[i for i,n in enumerate(names) if 'arm' in n and n.endswith('.'+s)])*sw).sum(1);ws[s]=w;fc[w[f].mean(1)>=.25]=k
mesh=vtk.vtkPolyData();pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(v,deep=True));mesh.SetPoints(pts);ca=vtk.vtkCellArray()
for face in f:ca.InsertNextCell(3,face.tolist())
mesh.SetPolys(ca);cs=numpy_to_vtk(np.array([[188,194,203],[242,139,45],[41,152,218]],np.uint8)[fc],deep=True,array_type=vtk.VTK_UNSIGNED_CHAR);cs.SetNumberOfComponents(3);mesh.GetCellData().SetScalars(cs)
mapper=vtk.vtkPolyDataMapper();mapper.SetInputData(mesh);mapper.SetScalarModeToUseCellData();mapper.SetColorModeToDirectScalars();actor=vtk.vtkActor();actor.SetMapper(mapper);actor.GetProperty().SetAmbient(.35);actor.GetProperty().SetDiffuse(.65)
ren=vtk.vtkRenderer();ren.SetBackground(.97,.98,.99);ren.AddActor(actor);win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.AddRenderer(ren);win.SetSize(1000,1000);cam=ren.GetActiveCamera();cam.ParallelProjectionOn();cam.SetViewUp(0,1,0)
# Exact primary-side native canvas: 768x1152, 6px/cm, center Z=0,Y=85.
win.SetSize(768,1152)
cen=np.array([0.,85.,0.]);cam.SetPosition(400.,85.,0.);cam.SetFocalPoint(*cen);cam.SetParallelScale(96.)
ren.ResetCameraClippingRange()
mat=vtk.vtkMatrix4x4();mat.DeepCopy(cam.GetProjectionTransformMatrix(768/1152,-1.,1.))
for j in range(4):mat.SetElement(0,j,-mat.GetElement(0,j))
cam.SetExplicitProjectionTransformMatrix(mat);cam.SetUseExplicitProjectionTransformMatrix(True);win.Render()
cap=vtk.vtkWindowToImageFilter();cap.SetInput(win);cap.Update();wr=vtk.vtkPNGWriter();wr.SetFileName(str(p/'native_side_semantic.png'));wr.SetInputConnection(cap.GetOutputPort());wr.Write()
anchor=np.array([39.93133135266667,124.82256625333333,13.644826057666668]);projected=np.array([384+6*anchor[2],576-6*(anchor[1]-85)])
ren.SetWorldPoint(*anchor,1.);ren.WorldToDisplay();display=ren.GetDisplayPoint();vtk_canvas=np.array([display[0],1152-display[1]])
import hashlib
metadata={'role':'Supplemental generation control for corresponding actual posed model; not grading oracle','canvas':[768,1152],'pixels_per_cm':6,'center_horizontal_Z_vertical_Y':[0,85],'horizontal':'+Z','depth_nearer':'+X','projection_pixel_matrix_worldXYZ1':[[0,0,6,384],[0,-6,0,1086]],'vtk_projection_matrix':[[mat.GetElement(i,j) for j in range(4)] for i in range(4)],'anchor_world_cm':anchor.tolist(),'anchor_projected_pixel_xy':projected.tolist(),'anchor_vtk_display_converted_top_left_xy':vtk_canvas.tolist(),'expected_pixel_xy':[465.87,337.06],'expected_error_px':float(np.linalg.norm(projected-np.array([465.87,337.06]))),'vtk_vs_analytic_error_px':float(np.linalg.norm(vtk_canvas-projected)),'source_posed_obj_sha256':hashlib.sha256((r/'work/full-imagegen-hillclimb-20261118/iteration-1/eval-1-original-product/with_skill/run-1/outputs/model-fit/final/posed.obj').read_bytes()).hexdigest(),'source_asset_sha256':hashlib.sha256((r/'web/human-studio/assets/human.json').read_bytes()).hexdigest(),'render_script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'image_sha256':hashlib.sha256((p/'native_side_semantic.png').read_bytes()).hexdigest()}
assert metadata['expected_error_px']<=1
assert metadata['vtk_vs_analytic_error_px']<1e-6
(p/'native_side_semantic.json').write_text(json.dumps(metadata,indent=2));print(json.dumps(metadata,indent=2))
