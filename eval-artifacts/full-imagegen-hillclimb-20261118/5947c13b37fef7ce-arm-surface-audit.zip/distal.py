exec(open(__file__.replace('distal.py','audit.py')).read().split('# Semantic category')[0])
report=json.load(open(OUT/'audit.json'));source=np.array(asset['vertices']).reshape(-1,3)[ids];summary={}
strict=np.where((TW[F].min(1)>.25)&((W['L']+W['R'])[F].max(1)<.05))[0]
for side in ['L','R']:
 a=next(b for b in asset['bones'] if b['name']=='upperarm01.'+side);b=next(b for b in asset['bones'] if b['name']=='upperarm02.'+side)
 raw=np.array(asset['vertices']).reshape(-1,3);shoulder=raw[asset['joints'][a['head']]].mean(0);elbow=raw[asset['joints'][b['tail']]].mean(0);axis=elbow-shoulder;progress=(source-shoulder)@axis/(axis@axis)
 fore=weights(lambda n:n.startswith('lowerarm') and n.endswith('.'+side))
 sets={'distal_upperarm_elbow':np.where((W[side][F].max(1)>=.25)&(progress[F].mean(1)>=.5)&(fore[F].mean(1)<.5))[0],'forearm':np.where(fore[F].max(1)>=.25)[0],'whole_arm':ARM[side]}
 summary[side]={}
 for name,faces in sets.items():
  for tname,tf in [('broad_torso',TORSO),('strict_torso_core',strict)]:
   c=vtk.vtkCollisionDetectionFilter();c.SetInputData(0,poly(F[faces]));c.SetInputData(1,poly(F[tf]))
   for i in [0,1]:m=vtk.vtkMatrix4x4();m.Identity();c.SetMatrix(i,m)
   c.SetCollisionModeToAllContacts();c.SetCellTolerance(1e-10);c.Update();remote=[]
   for j in range(c.GetNumberOfContacts()):
    ai=int(faces[c.GetContactCells(0).GetValue(j)]);ti=int(tf[c.GetContactCells(1).GetValue(j)])
    if not any(int(b) in near3[int(a)] for a in F[ai] for b in F[ti]):remote.append([ai,ti])
   summary[side][name+'__'+tname]={'arm_triangles':len(faces),'torso_triangles':len(tf),'raw_contact_segments':c.GetNumberOfContacts(),'contacts_beyond_3_hops':remote}
report['distal_strict_crosscheck']=summary
(OUT/'audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(summary,indent=2))
