# Independent arm surface audit — 2026-11-18

结论：实际 posed OBJ 的近侧 L 上臂/肘/前臂并没有远离肩部地穿入胸/躯干；side 上的胸前重叠主要是投影叠合。真实不透明三维渲染证实 +X side 近臂是 L（橙色），R（蓝色）几乎完全遮挡。不能因为两个 elbow 骨点都在画幅内，就认为两者都可见。

这是一份新增的独立几何诊断，不是对旧 grade 的修改，也不是整体 PASS。未修改模型、冻结 runtime、skill、原 outputs；未读取或写入 grader 目录。实际输入 hashes 在 audit.json，代码和产物 hashes 在 SHA256SUMS。

## 输入、覆盖与方法

- 13,380 vertices / 26,756 triangles，单位 cm。OBJ faces 精确等于 human.json indices 按 bodyVertexIds 重映射后的结果；neutral/posed face 顺序一致。未采用作者 diagnostics。
- 读取四通道 skinIndices/skinWeights。每侧 whole arm 取任何顶点 upperarm/lowerarm 合权重 >=0.25 的所有 triangles：1,274 triangles / 666 vertices。包含混合肩接缝以免漏边。
- broad torso 取任何顶点 spine/breast/clavicle/shoulder 合权重 >=0.25 且三个顶点 arm 合权重均值 <0.5：3,390 triangles。strict torso core 另取 torso 最小顶点权重 >0.25 且每顶点 arm 合权重 <0.05：2,668 triangles。
- 实际 vtkCollisionDetectionFilter all contacts、identity transform、cell tolerance 1e-10。先保留交线，再单独标记 3-hop 内连续拓扑邻域（不是直接将所有肩部接触记错）。每条剩余交线保存 face/source vertex IDs、接触端点、骨权重、最短拓扑/neutral surface edge 距离。
- 从原始 source rest joints 求 shoulder→elbow 轴。独立 distal half upperarm/elbow 集取轴向进度>=0.5 的 arm triangles（排除 forearm 主权重部分）：每侧361 triangles；forearm 任意顶点 lowerarm 权重>=0.25：每侧655 triangles。对 broad/strict torso 全三角检测，未先用可见性过滤。
- vtkStaticCellLocator 对实际 forearm/upperarm 顶点求精确最近 torso triangle 点距。此为“顶点→三角”距离，不能当成全连续面最小间隙；连续面是否相交由上述三角检测另行验证。

## 实际结果

| 检查 | L | R |
|---|---:|---:|
| distal upperarm/elbow vs broad torso 原始交线 | 0 | 0 |
| forearm vs broad torso 原始交线 | 0 | 0 |
| distal upperarm/elbow vs strict torso 原始交线 | 0 | 0 |
| forearm vs strict torso 原始交线 | 0 | 0 |
| whole arm vs broad torso 原始交线 | 1495 | 1571 |
| 其中<=3 hops 连续肩/腋窝邻域交线 | 1495 | 1563 |
| >3 hops 剩余交线 | 0 | 8 |
| whole arm vs strict torso >3 hops 交线 | 0 | 0 |
| forearm 两 lowerarm 分组的顶点→torso 最小点距 | 4.3139 cm | 1.9774 cm |

R 的8条剩余交线涉及5个arm faces和4个torso faces，全部恰好4 hops、neutral surface edge geodesic 4.05–6.90cm，集中于近端上臂/腋窝连续折叠区域，不含任何 lowerarm 权重；不是肘/前臂跨进胸的远端交线。contact bbox 为 X[-10.129,-9.038], Y[127.792,129.095], Z[3.382,6.446] cm。它们是实际可复现的局部三角相交，应保留披露；仅凭4-hop局部折叠不能把它们推广为远端 arm-torso 异常，亦不在此宣告其全部生理解剖质量正常。strict torso core 检查中这些局部折叠均消失，远端子集原始交线从始至终为0。

upperarm01 最近点距离为0源于与torso集合连续/重叠的肩接缝，不能当穿透证据。upperarm02 最近点 L1.518cm / R0.0634cm 亦含近端折叠边界，不能当全肘最小间隙。

## 看图与可见性

- side_plusX.png / side_closeup.png：真实 posed OBJ、不透明深度测试，橙=L、蓝=R、灰=其余身体。与 runtime side 相同 +X 深度方向；VTK camera 向 -X 看、up=+Y，所以其屏幕向右为 -Z（脸朝左）。root 已核验 primary side guide 的 horizontal=+Z、depth=+X（脸朝右），因此 guide 与本图仅水平反射：同一归一化宽度下 u_guide=1-u_vtk，纵坐标和深度完全不变。这不是换 pose 或改相机深度；遮挡顺序和近L/远R结论反射后保持。这里不把本图像素坐标直接套到 native guide。不是服装生成图，也不是 ImageGen 结果。closeup 实际看见 L 上臂斜向胸前投影、肘在胸高附近、前臂向手部下降；前视 front_plusZ.png / front_closeup.png 证实近臂在身体侧外。
- 首击射线检测对每个语义 arm triangle centroid 从 +X / +Z 朝向网格发射，只把实际第一命中到该点距离<0.025cm 记为 visible。+X：L 628/1206，R 15/1206；+Z：L 569/1206，R 564/1206。此数为“三角形中心可见数”，不是像素面积，也不是vertex/bone inframe。
- 该可见性测试使用全部不透明人体 triangles 作为遮挡体。它并不能保证每块三角全部可见，但足以否定“side 两臂同样清楚可见”的假设。

代码 audit.py、extra.py、distal.py；完整结构化结果 audit.json；实际命令 commands.txt；成功运行日志 run.log/extra.log/distal.log。最初两次无有效 X display/auth 的渲染尝试失败，最终使用现有桌面的 Xauthority 后三次计算均 exit 0；不涉及权限或安全设置修改。

补充：guide_side_parity.png / guide_side_closeup_parity.png 用VTK投影矩阵水平反射直接重绘，屏幕向右=+Z、深度仍+X，已实际查看closeup。仅匹配guide轴和parity，不声明其framing/native像素完全相同。visible_near_L_elbow_anchors.json 提供首击可见近L肘表面三角中心世界坐标，可供已有native投影映射直接使用；不是被遮住的farR elbow骨点。

追加精确同primary side native相机的生成控制图 native_side_semantic.png：768×1152、6px/cm、center(Z,Y)=(0,85)、horizontal=+Z/depth=+X，用原posed OBJ直接VTK重绘，未resize旧图。visible near-L elbow表面点投影(465.868956346,337.064602480)，对expected(465.87,337.06)误差0.00472px；VTK实际display与解析矩阵误差0。native_side_semantic.json保存矩阵与源hash。此图仅为对应模型的生成控制补充，不作为grader评分oracle。
