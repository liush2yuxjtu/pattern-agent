import json,pathlib,numpy as np,hashlib
p=pathlib.Path(__file__).resolve().parent;r=p.parents[2];x=json.load(open(p/'audit.json'));a=json.load(open(r/'web/human-studio/assets/human.json'));ids=np.array(a['bodyVertexIds']);src=np.array(a['vertices']).reshape(-1,3)
v=[];f=[]
for line in open(r/'work/full-imagegen-hillclimb-20261118/iteration-1/eval-1-original-product/with_skill/run-1/outputs/model-fit/final/posed.obj'):
 if line.startswith('v '):v.append(list(map(float,line.split()[1:4])))
 if line.startswith('f '):f.append([int(t)-1 for t in line.split()[1:]])
v=np.array(v);f=np.array(f);b=next(b for b in a['bones'] if b['name']=='upperarm02.L');elbow=src[a['joints'][b['tail']]].mean(0);visible=x['visibility']['side_plusX']['L']['visible_face_ids'];candidates=sorted(visible,key=lambda fi:np.linalg.norm(src[ids[f[fi]]].mean(0)-elbow));anchors=[]
for fi in candidates[:8]:
 anchors.append({'face_zero_based':fi,'source_vertices':ids[f[fi]].tolist(),'visible_surface_centroid_cm':v[f[fi]].mean(0).tolist(),'source_rest_centroid_distance_to_elbow_cm':float(np.linalg.norm(src[ids[f[fi]]].mean(0)-elbow))})
(p/'visible_near_L_elbow_anchors.json').write_text(json.dumps({'method':'visible first-hit face centroids, sorted by source rest centroid proximity to actual upperarm02.L tail joint. World cm; project using primary guide native mapping. All near L, not far R.','anchors':anchors},indent=2));print(json.dumps(anchors[:3],indent=2))
