exec(open(__file__.replace('extra.py','audit.py')).read().split('# Semantic category')[0])
import heapq
report=json.load(open(OUT/'audit.json'))
TL=vtk.vtkStaticCellLocator();TL.SetDataSet(TP);TL.BuildLocator()
coverage={}
for side in ['L','R']:
 groups={name:weights(lambda n,name=name:n==name) for name in names if ('arm' in name and name.endswith('.'+side))}
 coverage[side]={}
 for name,gw in groups.items():
  vertices=np.where((gw>=.35)&(W[side]>.5))[0];distances=[]
  for vi in vertices:
   pt=[0.,0.,0.];ci=vtk.mutable(0);sid=vtk.mutable(0);d=vtk.mutable(0.)
   TL.FindClosestPoint(V[vi],pt,ci,sid,d);distances.append((float(d)**.5,int(vi),pt,int(TORSO[int(ci)])))
  if distances:
   d,vi,p,ti=min(distances)
   coverage[side][name]={'sampled_vertices':len(vertices),'incident_faces':int(np.isin(F,vertices).any(1).sum()),'minimum_vertex_to_torso_triangle_distance_cm':d,'minimum_vertex_obj_zero_based':vi,'minimum_source_vertex':int(ids[vi]),'minimum_vertex_posed_cm':V[vi].tolist(),'closest_torso_point_cm':p,'closest_torso_face':ti,'median_vertex_triangle_distance_cm':float(np.median([d[0] for d in distances]))}
# Exact graph shortest path; positive edge lengths taken from neutral OBJ.
for side,pairs in contacts.items():
 for p in pairs:
  src=list(F[p['arm_face_zero_based']]);target=set(F[p['torso_face_zero_based']]);q=collections.deque((int(s),0) for s in src);seen=set(src)
  while q:
   vi,d=q.popleft()
   if vi in target: p['minimum_topology_hops']=d;break
   for j in adj[vi]-seen:seen.add(j);q.append((j,d+1))
  heap=[(0.,int(s)) for s in src];heapq.heapify(heap);best={s:0. for s in src}
  while heap:
   d,vi=heapq.heappop(heap)
   if vi in target:p['minimum_neutral_surface_edge_geodesic_cm']=d;break
   if d>best[vi]:continue
   for j in adj[vi]:
    nd=d+np.linalg.norm(N[vi]-N[j])
    if nd<best.get(j,float('inf')):best[j]=nd;heapq.heappush(heap,(nd,j))
report['contacts']=contacts;report['point_triangle_coverage']=coverage
(OUT/'audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'point_triangle_coverage':coverage,'R_contact_topology':[(p['minimum_topology_hops'],p['minimum_neutral_surface_edge_geodesic_cm']) for p in contacts['R']]},indent=2))
