from pathlib import Path
import tempfile,json,shutil,subprocess,sys,hashlib
BASE=Path(__file__).resolve().parents[1];G=BASE/'grader';realrun=BASE/'iteration-1/eval-1-original-product/with_skill/run-1';realout=realrun/'outputs';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before={str(p.relative_to(realout)):sha(p) for p in realout.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'};rows=[]
for kind in ['stale-trace','missing-manual']:
 with tempfile.TemporaryDirectory(prefix='independent-grade-binding-') as name:
  root=Path(name);grader=root/'grader';grader.mkdir()
  for p in G.iterdir():
   if p.name=='__pycache__':continue
   if p.name in ['write_final_grading.py','source-provenance-audit.json','freeze.json']:shutil.copy2(p,grader/p.name)
   else:(grader/p.name).symlink_to(p.resolve(),target_is_directory=p.is_dir())
  for n in ['protocol','case-inputs','arm-audit']:(root/n).symlink_to((BASE/n).resolve(),target_is_directory=True)
  target=root/'iteration-1/eval-1-original-product/with_skill/run-1/outputs';target.mkdir(parents=True)
  for p in realout.rglob('*'):
   rel=p.relative_to(realout);q=target/rel
   if p.is_dir():q.mkdir(exist_ok=True)
   elif p.is_file():q.symlink_to(p.resolve())
  if kind=='stale-trace':
   p=target/'TRACE.json';data=p.read_bytes();p.unlink();p.write_bytes(data+b'\nSTALE_NEGATIVE_PROBE\n')
   changed={str(p.relative_to(target)) for p in target.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and sha(p)!=before[str(p.relative_to(target))]};assert changed=={'TRACE.json'}
  else:(grader/'manual-final-review.json').unlink()
  proc=subprocess.run([sys.executable,str(grader/'write_final_grading.py')],text=True,capture_output=True)
  expected='Fixed independent manual review stale' if kind=='stale-trace' else 'manual-final-review.json'
  ok=proc.returncode!=0 and expected in proc.stderr and not(target.parent/'grading.json').exists()
  rows.append({'control':kind,'rejected':ok,'returncode':proc.returncode,'stderr_tail':proc.stderr.splitlines()[-2:],'published_grading_created':(target.parent/'grading.json').exists(),'manual_auto_generated':not(grader/'manual-final-review.json').is_symlink() and(grader/'manual-final-review.json').exists()})
assert before=={str(p.relative_to(realout)):sha(p) for p in realout.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
assert all(x['rejected'] for x in rows);result={'same_assembler_controls':rows,'original_executor_outputs_unchanged':True,'all_rejected':True};(G/'grade-binding-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
