from pathlib import Path
import json,hashlib
import cv2,numpy as np
BASE=Path(__file__).resolve().parents[1];out=BASE/'iteration-1/eval-1-original-product/with_skill/run-1/outputs';d=BASE/'grader/generated-back-preflight';d.mkdir(exist_ok=True)
photo=cv2.imread(str(out/'images/back.png'));guide=cv2.imread(str(out/'model-fit/final/views/back.png'));gmask=cv2.imread(str(out/'model-fit/final/views/back-mask.png'),0)>0
h,w=photo.shape[:2];gh,gw=guide.shape[:2];assert abs((w/gw)/(h/gh)-1)<.002
hsv=cv2.cvtColor(photo,cv2.COLOR_BGR2HSV);seed=(hsv[:,:,1]>42).astype('uint8');seed=cv2.morphologyEx(seed,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8));count,labels,stats,_=cv2.connectedComponentsWithStats(seed,8);person=(labels==(1+np.argmax(stats[1:,cv2.CC_STAT_AREA]))).astype('uint8')
# Actual photograph segmentation via GrabCut, initialized from saturation rather than avatar edges.
gc=np.zeros((h,w),np.uint8);gc[person>0]=cv2.GC_PR_FGD;gc[cv2.erode(person,np.ones((7,7),np.uint8))>0]=cv2.GC_FGD;dil=cv2.dilate(person,np.ones((19,19),np.uint8))>0;gc[dil&(person==0)]=cv2.GC_PR_BGD
cv2.grabCut(photo,gc,None,np.zeros((1,65)),np.zeros((1,65)),5,cv2.GC_INIT_WITH_MASK);ref=(gc==1)|(gc==3);body=cv2.resize(gmask.astype('uint8'),(w,h),interpolation=cv2.INTER_NEAREST)>0
edge=body & ~cv2.erode(body.astype('uint8'),np.ones((3,3),np.uint8)).astype(bool);dist=cv2.distanceTransform((~ref).astype('uint8'),cv2.DIST_L2,5);outside=float((body&~ref).sum()/body.sum());p95=float(np.percentile(dist[edge],95));overlay=photo.copy().astype(float)
for m,c in [(body&ref,[40,190,40]),(body&~ref,[230,210,30]),(ref&~body,[190,50,210])]:overlay[m]=overlay[m]*.8+np.array(c)*.2
cv2.imwrite(str(d/'native-front-segmentation.png'),ref.astype('uint8')*255);cv2.imwrite(str(d/'fixed-guide-foreground.png'),body.astype('uint8')*255);cv2.imwrite(str(d/'fixed-guide-overlay.png'),overlay.astype('uint8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result={'phase':'INDEPENDENT_PREFLIGHT, not finalgrade','image_sha256':sha(out/'images/back.png'),'guide_sha256':sha(out/'model-fit/final/views/back.png'),'native_size':[w,h],'guide_size':[gw,gh],'fixed_uniform_scale':w/gw,'registration_refit':False,'segmentation':'Actual HSV-seeded GrabCut5 iterations, independent from model silhouette, no refit/warp','body_outside_fraction':outside,'body_contour_p95_px':p95,'body_contour_p95_fraction_height':p95/h,'containment_gate_pass':outside<=.08 and p95/h<=.02,'limits':'Garment/hair envelope only; anchors/manual samepose must separately pass.'};(d/'mask-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
