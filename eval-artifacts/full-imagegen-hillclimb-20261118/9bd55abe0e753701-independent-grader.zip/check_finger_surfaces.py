#!/usr/bin/env python3
from pathlib import Path
import sys,argparse,json,hashlib
import numpy as np
import vtk
from vtk.util.numpy_support import numpy_to_vtk
from independent_geometry import obj
from diagnose_candidate import interhand_contacts

def nearest_sample_surface(v,f,groups):
 distances=[]
 for source,target in [('L','R'),('R','L')]:
  faces=f[np.all(np.isin(f,groups[target]),axis=1)];poly=vtk.vtkPolyData();points=vtk.vtkPoints();points.SetData(numpy_to_vtk(v,deep=True));poly.SetPoints(points);cells=vtk.vtkCellArray()
  for face in faces:
   cells.InsertNextCell(3)
   for point in face:cells.InsertCellPoint(int(point))
  poly.SetPolys(cells);locator=vtk.vtkStaticCellLocator();locator.SetDataSet(poly);locator.BuildLocator()
  for point in v[groups[source]]:
   closest=[0.,0.,0.];cell=vtk.reference(0);sub=vtk.reference(0);squared=vtk.reference(0.);locator.FindClosestPoint(point,closest,cell,sub,squared);distances.append(float(squared)**.5)
 return min(distances) if distances else None

def audit(model,asset):
 a=json.loads(Path(asset).read_text());ids=np.array(a['bodyVertexIds']);skin=np.array(a['skinIndices']).reshape(-1,4)[ids];weight=np.array(a['skinWeights']).reshape(-1,4)[ids];weight/=weight.sum(1,keepdims=True);index={b['name']:i for i,b in enumerate(a['bones'])};v,f=obj(Path(model)/'posed.obj');result={}
 for side in ['L','R']:
  groups={}
  for digit,key in [(1,'L'),(2,'R')]:
   bone=index[f'finger{digit}-3.{side}'];groups[key]=np.where(((skin==bone)*weight).sum(1)>.4)[0]
  result[side]=interhand_contacts(v,f,groups);result[side]['nearest_vertex_to_opposite_terminal_triangle_cm']=nearest_sample_surface(v,f,groups);result[side]['distance_method']='Actual terminal vertex samples to opposite actual terminal triangles, both directions; upper bound on exact minimum surface distance, not helper point.';result[side]['method']='Independent VTK actual same-hand terminal thumb/index triangle-surface intersections';result[side]['limits']='Actual terminal body surfaces, not helper bone-tip anchors. A contact curve/overlap requires closeup review; not a claim about every finger/whole-hand collision.'
 return {'posed_sha256':hashlib.sha256((Path(model)/'posed.obj').read_bytes()).hexdigest(),'hands':result,'actual_terminal_surfaces_no_crossings':all(x['contact_pairs']==0 for x in result.values())}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--out',required=True);p.add_argument('--asset',default='web/human-studio/assets/human.json');a=p.parse_args();result=audit(a.model,a.asset);Path(a.out).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
