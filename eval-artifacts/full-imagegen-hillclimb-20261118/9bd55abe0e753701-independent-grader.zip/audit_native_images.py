from pathlib import Path
import json,hashlib
from PIL import Image
BASE=Path(__file__).resolve().parents[1];out=BASE/'iteration-1/eval-1-original-product/with_skill/run-1/outputs';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();data=json.loads((out/'generation-receipts.json').read_text());selected=json.loads((out/'generation-selection.json').read_text())['selected'];rows=[]
for record in data['images']:
 view=record['view'];assert record['tool']=='image_gen.imagegen';p=out/record['path'];native=Path(record['native_path']);assert str(p.resolve())==str(Path(record['output_path']).resolve());assert record['path']==selected[view];assert sha(p)==sha(native)==record['output_sha256']==record['native_sha256'];pixels=list(Image.open(p).size);assert pixels==record['native_pixels'];assert 'native' in record.get('transforms','').lower();refs=[]
 for ref in record['references']:
  rp=Path(ref['path']);assert sha(rp)==ref['sha256'];assert list(Image.open(rp).size)==ref['pixels'];refs.append({'path':str(rp),'sha256':ref['sha256'],'pixels':ref['pixels']})
 assert [r['path'] for r in record['references']]==record['actual_referenced_image_paths'];assert record['prompt']
 rows.append({'view':view,'path':record['path'],'native_path':str(native),'native_pixels':pixels,'native_and_delivered_sha256':sha(p),'reference_hashes_verified':refs,'independent_copy_identity':True,'prompt_and_actual_tool_hint_present':bool(record.get('actual_tool_output_hint'))})
assert {r['view'] for r in rows}=={'front','side','back','closeup','pose','depth'} and len(rows)==6 and len({r['native_path'] for r in rows})==6
actual_receipts=list((out/'images').rglob('*.receipt.json'));blocked=list((out/'images').rglob('*blocked-receipt.json'));result={'scope':'Actual six selected native independent ImageGen outputs; toolcall/provenance verification, not geometry by itself','selected':rows,'native_receipt_count_all_attempts':len(actual_receipts),'blocked_receipt_count':len(blocked),'six_unique_native_outputs':True,'all_selected_references_verified':True,'all_selected_full_resolution_png':True,'front_input_uses_fresh_final_model':any('/model-fit/final/views/front.png' in x['path'] for x in rows[0]['reference_hashes_verified'])};(BASE/'grader/native-image-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='selected'},indent=2))
