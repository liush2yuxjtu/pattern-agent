#!/usr/bin/env python3
"""Independent fixed-canvas visible-anchor consistency check; not latent3D proof."""
from pathlib import Path
import argparse,json,hashlib,math
import numpy as np
from PIL import Image

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def assess(data,resolve=Path('.'),verify_images=True):
 result={};total_observed=0
 for name,view in data['views'].items():
  image=resolve/view['image'];guide=resolve/view['guide'];errors=[];observed={};expected={};reasons=[]
  if verify_images:
   assert sha(image)==view['image_sha256'] and sha(guide)==view['guide_sha256'],'Stale actual image/guide bytes'
   w,h=Image.open(image).size;gw,gh=Image.open(guide).size
  else:w,h=view['image_size'];gw,gh=view['guide_size']
  # Only predefined guide-canvas to native scaling; no fitted affine/homography.
  sx=w/gw;sy=h/gh
  if abs(sx/sy-1)>.002:reasons.append('Guide/native aspect ratio differs; no uniform frozen canvas conversion')
  if view.get('posthoc_registration',False):reasons.append('Per-view image warp/refit forbidden')
  for point in view['anchors']:
   if point['visibility']!='visible':
    assert point.get('generated_xy') is None and point.get('reason'),'Unobserved points must remain null with reason'
    continue
   assert point.get('semantic') and point.get('guide_xy') is not None and point.get('generated_xy') is not None,'Missing actual semantic anchor coordinates'
   obs=np.array(point['generated_xy'],float);exp=np.array(point['guide_xy'],float)*[sx,sy];assert np.isfinite(obs).all() and np.isfinite(exp).all()
   error=float(np.linalg.norm(obs-exp)/h);errors.append(error);observed[point['id']]=obs;expected[point['id']]=exp
  angles=[]
  for a,b in view.get('limb_pairs',[]):
   if a not in observed or b not in observed:continue
   u=observed[b]-observed[a];v=expected[b]-expected[a];den=np.linalg.norm(u)*np.linalg.norm(v)
   angle=math.degrees(math.acos(np.clip(np.dot(u,v)/max(den,1e-12),-1,1)));angles.append({'pair':[a,b],'angle_deg':angle})
  count=len(errors);total_observed+=count;mean=float(np.mean(errors)) if errors else None;worst=max(errors) if errors else None
  if count<8:reasons.append('Fewer than8 observed distributed anchors')
  if mean is None or mean>.015:reasons.append('Mean observed anchor drift exceeds1.5% imageheight')
  if worst is None or worst>.025:reasons.append('One observed anchor drift exceeds2.5% imageheight')
  if not angles:reasons.append('No observed limb direction pairs')
  if any(x['angle_deg']>12 for x in angles):reasons.append('Observed limb direction exceeds12deg')
  result[name]={'observed_anchors':count,'mean_error_fraction_height':mean,'max_error_fraction_height':worst,'limb_angles':angles,'passed':not reasons,'reasons':reasons}
 return {'scope':'Visible fixed-guide projection consistency only; not exact latent3D/person truth','views':result,'total_observed_anchors':total_observed,'passed':set(result)=={'front','side','back'} and all(x['passed'] for x in result.values())}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--annotations',required=True);p.add_argument('--root',default='.');p.add_argument('--out',required=True);args=p.parse_args();data=json.loads(Path(args.annotations).read_text());result=assess(data,Path(args.root));Path(args.out).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
