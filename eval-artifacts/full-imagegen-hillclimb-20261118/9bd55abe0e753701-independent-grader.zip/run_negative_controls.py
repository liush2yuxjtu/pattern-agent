#!/usr/bin/env python3
"""Actual same-validator controls; preserves original executor files."""
from pathlib import Path
import copy,json,subprocess,sys,shutil
import numpy as np
from independent_geometry import obj,reconstruct
from diagnose_candidate import diagnose
from check_generated_annotations import assess
BASE=Path(__file__).resolve().parents[1];OUT=BASE/'grader/negative-controls';OUT.mkdir(exist_ok=True)
source=BASE/'solver-body/camera-torso-2';asset=Path('web/human-studio/assets/human.json');state=json.loads((source/'final-state.json').read_text());n,f=obj(source/'neutral.obj');v,_=obj(source/'posed.obj')
def write_obj(p,v,f):
 with p.open('w') as out:
  for x in v:out.write('v '+' '.join(format(float(q),'.10f') for q in x)+'\n')
  for face in f:out.write('f '+' '.join(str(int(q)+1) for q in face)+'\n')
def mutant(name,mutated):
 model=OUT/name;model.mkdir(exist_ok=True)
 for fn in ['neutral.obj','camera.json','final-state.json']:shutil.copy2(source/fn,model/fn)
 write_obj(model/'posed.obj',mutated,f);diagnose(model,model/'audit',asset)
 return json.loads((model/'audit/diagnostic.json').read_text())
original=BASE/'grader/body-camera-torso2/diagnostic.json';positive=json.loads(original.read_text());assert positive['region_gate_pass']
shift=v.copy();shift[n[:,1]<105,0]+=10;shiftresult=mutant('pelvis-plus10cm',shift)
shrink=v.copy();pick=n[:,1]<105;shrink[pick,0]*=.2;shrinkresult=mutant('narrow-pelvis-x20percent',shrink)
# Same actual annotation validator with an analytic fixed-canvas fixture.
anchors=[{'id':str(i),'guide_xy':[100+(i%2)*60,50+i*100],'generated_xy':[100+(i%2)*60,50+i*100],'visibility':'visible','semantic':'synthetic control anchor'} for i in range(10)]
view={'image':'unused','guide':'unused','image_size':[1000,1500],'guide_size':[1000,1500],'anchors':anchors,'limb_pairs':[['0','1'],['2','3'],['4','5'],['6','7']]}
data={'views':{k:copy.deepcopy(view) for k in ['front','side','back']}};good=assess(data,verify_images=False);assert good['passed']
bad=copy.deepcopy(data);bad['views']['side']['anchors'][3]['generated_xy'][0]+=90;badresult=assess(bad,verify_images=False)
result={'same_validator_controls':[
 {'id':'pelvis-actual-vertices-shift-plus10cm','positive_region_gate':positive['region_gate_pass'],'mutant_region_gate':shiftresult['region_gate_pass'],'rejected':not shiftresult['region_gate_pass'],'affected_regions':{k:x for k,x in shiftresult['regions'].items() if not x['passed']},'note':'Geometry-correspondence also fails, but target regional gate is independently evaluated and rejects; original pose source untouched.'},
 {'id':'pelvis-actual-vertices-narrow20percent','positive_region_gate':positive['region_gate_pass'],'mutant_region_gate':shrinkresult['region_gate_pass'],'rejected':not shrinkresult['region_gate_pass'],'scanline_failures':{k:x for k,x in shrinkresult['scanlines'].items() if not x['passed']},'note':'Inherited scanline width gate detects shrink-to-containment; not credited from unrelated wholemesh failure.'},
 {'id':'side-only-anchor-plus6percentH','positive_pass':good['passed'],'mutant_pass':badresult['passed'],'rejected':not badresult['passed'],'affected':badresult['views']['side'],'note':'Analytic annotation control, not a generated photo or detector result.'}
 ],'all_controls_reject':not shiftresult['region_gate_pass'] and not shrinkresult['region_gate_pass'] and not badresult['passed']}
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
