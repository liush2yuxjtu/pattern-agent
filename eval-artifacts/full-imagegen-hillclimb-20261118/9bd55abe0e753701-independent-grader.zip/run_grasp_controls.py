from pathlib import Path
import json,copy,shutil
import numpy as np
from independent_geometry import obj,reconstruct
from diagnose_candidate import diagnose
from check_finger_surfaces import audit as finger_audit
BASE=Path(__file__).resolve().parents[1];OUT=BASE/'grader/grasp-controls';OUT.mkdir(exist_ok=True);source=BASE/'solver-grip/body-merged-6';a=json.loads(Path('web/human-studio/assets/human.json').read_text());s=json.loads((source/'final-state.json').read_text());index={b['name']:i for i,b in enumerate(a['bones'])};ids=np.array(a['bodyVertexIds']);n,f=obj(source/'neutral.obj');v,_=obj(source/'posed.obj');positive=json.loads((BASE/'grader/body-merged6/diagnostic.json').read_text());assert positive['grasp_numeric_gate_pass'];asset=Path('web/human-studio/assets/human.json')
def write_obj(p,vertices):
 with p.open('w') as out:
  for x in vertices:out.write('v '+' '.join(format(float(q),'.10f') for q in x)+'\n')
  for face in f:out.write('f '+' '.join(str(int(q)+1) for q in face)+'\n')
def evaluate(name,state,vertices):
 d=OUT/name;d.mkdir(exist_ok=True);shutil.copy2(source/'neutral.obj',d/'neutral.obj');shutil.copy2(source/'camera.json',d/'camera.json');(d/'final-state.json').write_text(json.dumps(state,indent=2)+'\n');write_obj(d/'posed.obj',vertices);diagnose(d,d/'audit',asset);return json.loads((d/'audit/diagnostic.json').read_text())
def plane(j):
 w=j[index['wrist.L']];normal=np.cross(j[index['finger2-1.L']]-w,j[index['finger5-1.L']]-w);normal/=np.linalg.norm(normal);return normal
candidates=[]
for axis in range(3):
 for delta in [-90,90]:
  q=copy.deepcopy(s);q['poseDegrees']['wrist.L'][axis]+=delta;nn,vv,j=reconstruct(a,q,full=True);candidates.append((abs(plane(j)[1]),q,vv[ids],axis,delta))
best=max(candidates,key=lambda t:t[0]);up=evaluate('actual-wrist-supination',best[1],best[2])
# Actual body hand block translated anteriorly. State mismatch is separately visible; target clearance validator still must reject.
skin=np.array(a['skinIndices']).reshape(-1,4)[ids];weights=np.array(a['skinWeights']).reshape(-1,4)[ids];weights/=weights.sum(1,keepdims=True);hb=[i for i,b in enumerate(a['bones']) if b['name'].endswith('.L') and b['name'].startswith(('finger','wrist'))];hi=np.where((np.isin(skin,hb)*weights).sum(1)>.5)[0];far=v.copy();far[hi,2]+=15;front=evaluate('actual-hand-vertices-plus15cm',s,far)
# Choose a real thumb-base joint perturbation that opens the previously valid pinch.
candidates=[]
for axis in range(3):
 for delta in [-90,90]:
  q=copy.deepcopy(s);q['poseDegrees']['finger1-1.L'][axis]+=delta;nn,vv,j=reconstruct(a,q,full=True);tips=[]
  for digit in [1,2]:
   b=a['bones'][index[f'finger{digit}-3.L']];tips.append(vv[a['joints'][b['tail']]].mean(0))
  candidates.append((np.linalg.norm(tips[0]-tips[1]),q,vv[ids],axis,delta))
bestgap=max(candidates,key=lambda t:t[0]);opened=evaluate('actual-thumb-joint-open',bestgap[1],bestgap[2])
newf=finger_audit(source,asset);oldf=finger_audit(BASE/'solver-grip/body-merged-5',asset)
result={'positive_source':str(source),'positive_grasp_numeric_gate':True,'controls':[
 {'id':'actual-wrist-supination','joint':'wrist.L','axis':best[3],'delta_degrees':best[4],'positive_abs_normal_y':positive['hands']['L']['abs_normal_y'],'mutant_abs_normal_y':up['hands']['L']['abs_normal_y'],'rejected_by_same_palm_gate':up['hands']['L']['abs_normal_y']>.65,'geometry_correspondence':up['geometry']['passed']},
 {'id':'actual-hand-skin-plus15cm','positive_p05':positive['hands']['L']['p05_clearance_cm'],'mutant_p05':front['hands']['L']['p05_clearance_cm'],'rejected_by_same_clearance_gate':front['hands']['L']['p05_clearance_cm']>10,'geometry_correspondence':front['geometry']['passed'],'note':'Deliberately corrupted actual hand vertices, not a legitimate saved pose; local distance gate independently rejects rather than relying on mesh/state mismatch.'},
 {'id':'actual-thumb-joint-open','joint':'finger1-1.L','axis':bestgap[3],'delta_degrees':bestgap[4],'positive_helper_gap':positive['hands']['L']['thumb_index_tip_gap_cm'],'mutant_helper_gap':opened['hands']['L']['thumb_index_tip_gap_cm'],'rejected_by_same_gap_gate':opened['hands']['L']['thumb_index_tip_gap_cm']>2,'geometry_correspondence':opened['geometry']['passed']},
 {'id':'same-hand-skin-crossing-regression','positive_terminal_surface':newf,'bad_predecessor_terminal_surface':oldf,'rejected_by_surface_check':newf['actual_terminal_surfaces_no_crossings'] and not oldf['actual_terminal_surfaces_no_crossings'],'note':'Predecessor merged5 passes helper-gap/ray/region gates yet fails actual skin collision; useful discriminating counterexample.'}
 ]}
result['all_rejected']=all(row.get('rejected_by_same_palm_gate',row.get('rejected_by_same_clearance_gate',row.get('rejected_by_same_gap_gate',row.get('rejected_by_surface_check',False)))) for row in result['controls']);(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
