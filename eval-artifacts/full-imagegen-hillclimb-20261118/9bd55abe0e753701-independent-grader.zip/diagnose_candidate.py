#!/usr/bin/env python3
"""Independent actual-OBJ region/scanline, scalar morph/FK and grasp audit.
No executor runtime, fitting code, measurement exporter or submitted metrics imported.
"""
from pathlib import Path
import argparse, json, hashlib
import numpy as np, cv2
from independent_geometry import obj,reconstruct,masks,measure
import vtk
from vtk.util.numpy_support import numpy_to_vtk,vtk_to_numpy
BASE=Path(__file__).resolve().parents[1]

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def interhand_contacts(vertices,faces,groups):
 meshes=[];counts=[]
 for side in ['L','R']:
  selected=faces[np.all(np.isin(faces,groups[side]),axis=1)];points=vtk.vtkPoints();points.SetData(numpy_to_vtk(vertices,deep=True));cells=vtk.vtkCellArray()
  for face in selected:
   cells.InsertNextCell(3)
   for point in face:cells.InsertCellPoint(int(point))
  poly=vtk.vtkPolyData();poly.SetPoints(points);poly.SetPolys(cells);meshes.append(poly);counts.append(len(selected))
 flt=vtk.vtkCollisionDetectionFilter();identity=vtk.vtkMatrix4x4();identity.Identity()
 for i,mesh in enumerate(meshes):flt.SetInputData(i,mesh);flt.SetMatrix(i,identity)
 flt.SetCollisionModeToAllContacts();flt.SetBoxTolerance(0);flt.SetCellTolerance(0);flt.Update()
 contacts=flt.GetContactsOutput();contactpoints=vtk_to_numpy(contacts.GetPoints().GetData()) if contacts.GetPoints() is not None else np.empty((0,3));bounds={'min':contactpoints.min(0).tolist(),'max':contactpoints.max(0).tolist(),'span':np.ptp(contactpoints,axis=0).tolist()} if len(contactpoints) else None
 return {'contact_bbox_cm':bounds,'method':'VTK independent triangle surface-intersection query on actual two hand meshes; zero tolerance','vtk_version':vtk.vtkVersion.GetVTKVersion(),'triangles_L_R':counts,'contact_pairs':int(flt.GetNumberOfContacts()),'limits':'Reported contacts need anatomical/visual interpretation; this checks interhand surfaces only, not every self-intersection or cloth contact.'}

def diagnose(model,out,assetpath):
 model=Path(model);out=Path(out);out.mkdir(parents=True,exist_ok=True)
 statepath=next(p for p in [model/'final-state.json',model/'state.json'] if p.exists())
 state=read(statepath);a=read(assetpath);protocol=read(BASE/'protocol/acceptance-v1.json');reg=protocol['inherited_region_gate']
 n,f=obj(model/'neutral.obj');v,pf=obj(model/'posed.obj');fulln,fullv,joints=reconstruct(a,state,full=True);ids=np.array(a['bodyVertexIds']);neutralerr=np.linalg.norm(n-fulln[ids],axis=1).max();posederr=np.linalg.norm(v-fullv[ids],axis=1).max()
 cam=read(model/'camera.json');mask=masks(v,pf,cam)>0;ref=cv2.imread(str(BASE/'protocol/source-reference-mask.png'),0)>0
 assert mask.shape==ref.shape==(1276,1000)
 contour=mask & ~cv2.erode(mask.astype('uint8'),np.ones((3,3),np.uint8)).astype(bool);dist=cv2.distanceTransform((~ref).astype('uint8'),cv2.DIST_L2,5)
 regions={}
 for name,(x0,y0,x1,y1) in reg['regions'].items():
  roi=np.zeros_like(mask);roi[y0:y1,x0:x1]=True;body=mask&roi;edge=contour&roi;count=int(body.sum());outside=float((body&~ref).sum()/max(count,1));p95=float(np.percentile(dist[edge],95)) if edge.any() else None
  regions[name]={'body_pixels':count,'outside_fraction':outside,'p95_px':p95,'passed':count>=1000 and outside<=.08 and p95 is not None and p95<=25}
 scanlines={}
 for y in reg['scanlines']:
  bx=np.where(mask[y])[0];rx=np.where(ref[y])[0]
  if len(bx)<2 or len(rx)<2:scanlines[str(y)]={'passed':False,'reason':'No usable projected body/reference span'};continue
  bw=float(bx[-1]-bx[0]);rw=float(rx[-1]-rx[0]);error=abs(float(bx[0]+bx[-1]-rx[0]-rx[-1]))/2;ratio=bw/rw
  scanlines[str(y)]={'body_span':[int(bx[0]),int(bx[-1])],'reference_span':[int(rx[0]),int(rx[-1])],'center_error_px':error,'width_ratio':ratio,'passed':error<=45 and .55<=ratio<=1.15}
 cv2.imwrite(str(out/'independent-source-mask.png'),mask.astype('uint8')*255)
 # Actual torso-triangle +Z ray intersections via 2x2 inverse (not executor formula).
 tri=v[pf];nt=n[pf];keep=np.all((abs(nt[:,:,0])<22)&(nt[:,:,1]>95)&(nt[:,:,1]<140),axis=1);tri=tri[keep]
 o=tri[:,0,:2];basis=np.stack([tri[:,1,:2]-o,tri[:,2,:2]-o],axis=2);keep=abs(np.linalg.det(basis))>1e-9;tri=tri[keep];o=o[keep];inv=np.linalg.inv(basis[keep]);lo=tri[:,:,:2].min(1);hi=tri[:,:,:2].max(1)
 skin=np.array(a['skinIndices']).reshape(-1,4)[ids];weights=np.array(a['skinWeights']).reshape(-1,4)[ids];weights/=weights.sum(1,keepdims=True);index={b['name']:i for i,b in enumerate(a['bones'])};hands={};centres=[];hand_id_groups={}
 for side in ['L','R']:
  bones=[i for i,b in enumerate(a['bones']) if b['name'].endswith('.'+side) and b['name'].startswith(('finger','wrist'))];handids=np.where((np.isin(skin,bones)*weights).sum(1)>.5)[0];clear=[];inside=0;hand_id_groups[side]=handids
  for h in handids:
   xy=v[h,:2];cand=np.where(np.all((xy>=lo)&(xy<=hi),axis=1))[0]
   if not len(cand):continue
   uv=np.einsum('nij,nj->ni',inv[cand],xy-o[cand]);hit=(uv>=0).all(1)&(uv.sum(1)<=1);ii=cand[hit];uv=uv[hit];depths=tri[ii,0,2]+uv[:,0]*(tri[ii,1,2]-tri[ii,0,2])+uv[:,1]*(tri[ii,2,2]-tri[ii,0,2])
   if len(depths)<2 or depths.max()-depths.min()<1:continue
   z=v[h,2];clear.append(float(z-depths.max()));inside+=bool(depths.min()+.05<z<depths.max()-.05)
  wrist=joints[index['wrist.'+side]];u=joints[index['finger2-1.'+side]]-wrist;vv=joints[index['finger5-1.'+side]]-wrist;normal=np.cross(u,vv);normal/=max(np.linalg.norm(normal),1e-12)
  tips=[]
  for digit in [1,2]:
   b=a['bones'][index[f'finger{digit}-3.{side}']];tips.append(fullv[a['joints'][b['tail']]].mean(0))
  centre=np.mean(tips,axis=0);centres.append(centre);gap=float(np.linalg.norm(tips[0]-tips[1]));coverage=len(clear)/len(handids);insidefraction=inside/max(len(clear),1);p05=float(np.percentile(clear,5)) if clear else None
  hands[side]={'hand_vertices':len(handids),'covered':len(clear),'coverage_fraction':coverage,'inside':int(inside),'inside_fraction_covered':insidefraction,'min_clearance_cm':min(clear) if clear else None,'p05_clearance_cm':p05,'palm_normal':normal.tolist(),'abs_normal_y':abs(float(normal[1])),'thumb_index_tip_gap_cm':gap,'pinch_center_cm':centre.tolist(),'passed_numeric':coverage>=.8 and insidefraction<=.005 and p05 is not None and p05<=10 and abs(normal[1])<=.65 and gap<=2}
 gapcentres=float(np.linalg.norm(centres[0]-centres[1]));result={'scope':'Independent candidate diagnostic, not final13 semantic grade; manual original-action/3D review still required','fingerprints':{str(p):sha(p) for p in [statepath,model/'neutral.obj',model/'posed.obj',model/'camera.json',Path(assetpath),BASE/'protocol/acceptance-v1.json']},'geometry':{'neutral_max_delta_cm':float(neutralerr),'posed_max_delta_cm':float(posederr),'passed':neutralerr<=.002 and posederr<=.002},'regions':regions,'scanlines':scanlines,'region_gate_pass':all(x['passed'] for x in regions.values()) and all(x['passed'] for x in scanlines.values()),'hands':hands,'pinch_center_distance_cm':gapcentres,'grasp_numeric_gate_pass':all(h['passed_numeric'] for h in hands.values()) and gapcentres<=8,'model_measurements_cm':measure(n,a),'interhand_surface_contacts':interhand_contacts(v,pf,hand_id_groups),'manual_review':'PENDING; numeric pass does not imply grasp/semantic PASS'}
 (out/'diagnostic.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,default=lambda x:x.item())+'\n');print(json.dumps({k:result[k] for k in ['geometry','region_gate_pass','hands','pinch_center_distance_cm','grasp_numeric_gate_pass']},indent=2,default=lambda x:x.item()))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--out',required=True);p.add_argument('--asset',default='web/human-studio/assets/human.json');args=p.parse_args();diagnose(args.model,args.out,args.asset)
