from pathlib import Path
import json,hashlib,sys
import numpy as np
from independent_geometry import reconstruct
from check_generated_annotations import assess
BASE=Path(__file__).resolve().parents[1];o=BASE/'iteration-1/eval-1-original-product/with_skill/run-1/outputs';model=o/'model-fit/final';a=json.loads(Path('web/human-studio/assets/human.json').read_text());s=json.loads((model/'final-state.json').read_text());rest,posed,joints=reconstruct(a,s,full=True);index={b['name']:i for i,b in enumerate(a['bones'])};cam=json.loads((model/'views/camera.json').read_text());c=cam['views']['front'];scale=c['px_per_cm'];width,height=cam['width'],cam['height'];cx,cy=c['center_cm'];project=lambda p:[(p[0]-cx)*scale+width/2,-(p[1]-cy)*scale+height/2]
# Native generated-image observations independently digitized from actual viewed photo/crops.
manual={
 'eye_image_left':('eye.R',[461,186],'visible iris/eye centre, approximate head landmark'),
 'eye_image_right':('eye.L',[512,180],'visible iris/eye centre, approximate head landmark'),
 'elbow_image_left':('lowerarm01.R',[388,568],'visible sleeve-bend surface centre, approximate elbow under cloth; not detector/anatomical truth'),
 'elbow_image_right':('lowerarm01.L',[815,443],'visible sleeve-bend surface centre, approximate elbow under cloth; not detector/anatomical truth'),
 'wrist_image_left':('wrist.R',[479,554],'visible skin wrist/hand transition centre, approximate'),
 'wrist_image_right':('wrist.L',[681,542],'visible skin wrist/hand transition centre, approximate'),
 'ankle_image_left':('foot.R',[577,1370],'visible skin ankle centre at trouser hem, approximate'),
 'ankle_image_right':('foot.L',[734,1373],'visible skin ankle centre at trouser hem, approximate')}
anchors=[]
for name,(bone,xy,semantic) in manual.items():anchors.append({'id':name,'guide_xy':project(joints[index[bone]]),'generated_xy':xy,'visibility':'visible','semantic':semantic,'digitization':'Independent actual photo and coordinate crops; approximate4–8px observation, no fit/warp. Error gate does not subtract uncertainty.'})
for side,xy in [('R',[569,539]),('L',[596,545])]:
 tips=[]
 for digit in [1,2]:
  b=a['bones'][index[f'finger{digit}-3.{side}']];tips.append(posed[a['joints'][b['tail']]].mean(0))
 anchors.append({'id':'pinch_'+side,'guide_xy':project(np.mean(tips,axis=0)),'generated_xy':xy,'visibility':'visible','semantic':'visible pinched shirt-hem/thumb-index gap centre; guide helper centre used as contact-location proxy, not actual skin contact','digitization':'Independent actual photograph observed garment grip, about5px precision; no cloth-contact physics claim'})
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();image=o/'images/attempt-2/front.png';guide=model/'views/front.png';data={'scope':'front2 independent visible preflight; no finalgrade or side/back assumption','views':{'front':{'image':str(image),'guide':str(guide),'image_sha256':sha(image),'guide_sha256':sha(guide),'posthoc_registration':False,'anchors':anchors,'limb_pairs':[['elbow_image_left','wrist_image_left'],['elbow_image_right','wrist_image_right']]}}};folder=BASE/'grader/generated-front-attempt2';(folder/'anchors.json').write_text(json.dumps(data,indent=2)+'\n');result=assess(data,Path('.'));(folder/'anchor-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
