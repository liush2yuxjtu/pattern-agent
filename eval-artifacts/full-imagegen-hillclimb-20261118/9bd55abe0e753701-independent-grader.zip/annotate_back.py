from pathlib import Path
import json,hashlib
import cv2,numpy as np
from independent_geometry import reconstruct
from check_generated_annotations import assess
BASE=Path(__file__).resolve().parents[1];o=BASE/'iteration-1/eval-1-original-product/with_skill/run-1/outputs';model=o/'model-fit/final';a=json.loads(Path('web/human-studio/assets/human.json').read_text());s=json.loads((model/'final-state.json').read_text());rest,posed,joints=reconstruct(a,s,full=True);index={b['name']:i for i,b in enumerate(a['bones'])};cam=json.loads((model/'views/camera.json').read_text());c=cam['views']['back'];k=c['px_per_cm'];w,h=cam['width'],cam['height'];cx,cy=c['center_cm'];project=lambda p:[(-p[0]-cx)*k+w/2,-(p[1]-cy)*k+h/2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manual={'shoulder_image_left':('upperarm01.L',[352,324],'visible clothing shoulder shape centre, approximate underlying shoulder; not detector truth'),'shoulder_image_right':('upperarm01.R',[616,354],'visible clothing shoulder shape centre, approximate underlying shoulder; not detector truth'),'elbow_image_left':('lowerarm01.L',[216,452],'visible sleeve elbow-bend shape centre, approximate; not detector truth'),'elbow_image_right':('lowerarm01.R',[641,575],'visible sleeve elbow-bend shape centre, approximate; not detector truth')}
anchors=[]
for name,(bone,xy,semantic) in manual.items():anchors.append({'id':name,'guide_xy':project(joints[index[bone]]),'generated_xy':xy,'visibility':'visible','semantic':semantic,'digitization':'Independent actual back photograph viewed; approximate8px. Uncertainty is not subtracted from errors.'})
# Clearly visible projected silhouette anchors, not hidden hip/knee joints.
ref=cv2.imread(str(BASE/'grader/generated-back-preflight/native-front-segmentation.png'),0)>0;body=cv2.resize(cv2.imread(str(model/'views/back-mask.png'),0),(1024,1536),interpolation=cv2.INTER_NEAREST)>0
for side,which in [('left',0),('right',-1)]:
 bx=np.where(body[768])[0][which];rx=np.where(ref[768])[0][which];anchors.append({'id':'hip_silhouette_'+side,'guide_xy':[float(bx)*.75,576.0],'generated_xy':[int(rx),768],'visibility':'visible','semantic':'outer clothing/body silhouette at predeclared nativeY768 hip-height scanline, NOT femoral joint; surfacewidth constraint','digitization':'Deterministic actual silhouettes, frozen uniform mapping, no best-fit position'})
for side,xrange in [('left',(180,370)),('right',(371,540))]:
 coords=[]
 for mask in [body,ref]:
  yy,xx=np.where(mask[1340:,xrange[0]:xrange[1]]);yy+=1340;xx+=xrange[0];bottom=int(yy.max());near=xx[yy>=bottom-2];coords.append([float(np.median(near)),float(bottom)])
 anchors.append({'id':'foot_lowest_boundary_'+side,'guide_xy':(np.array(coords[0])*.75).tolist(),'generated_xy':coords[1],'visibility':'visible','semantic':'lowest visible bare-foot silhouette boundary centre; not hidden ankle/toe bone or physical support proof','digitization':'Deterministic lowerfoot silhouette extrema in frozen side ranges'})
# Hidden wrists/joints are explicitly absent, not filled to get extra passing points.
anchors.extend([{'id':'hidden_wrist_'+side,'guide_xy':project(joints[index['wrist.'+side]]),'generated_xy':None,'visibility':'NOT_OBSERVED','reason':'Hands/wrists occluded in front of torso in this back view','semantic':'unobserved anatomical wrist'} for side in ['L','R']])
image=o/'images/back.png';guide=model/'views/back.png';data={'scope':'back independent observable-body preflight; hidden3D not verified','views':{'back':{'image':str(image),'guide':str(guide),'image_sha256':sha(image),'guide_sha256':sha(guide),'posthoc_registration':False,'anchors':anchors,'limb_pairs':[['shoulder_image_left','elbow_image_left'],['shoulder_image_right','elbow_image_right']]}}};d=BASE/'grader/generated-back-preflight';(d/'anchors.json').write_text(json.dumps(data,indent=2)+'\n');result=assess(data,Path('.'));(d/'anchor-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
