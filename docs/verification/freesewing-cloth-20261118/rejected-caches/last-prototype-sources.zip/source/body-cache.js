/** Static-body query exclusion. A supplied certificate bounds all candidate
 * nearest-face planes, preserving the original projection heuristic as well
 * as geometric separation. All state is serialized for offline continuation.
 */
export class BodyContactCache {
 constructor(count,certify){this.points=new Float64Array(count*3);this.distances=new Float64Array(count);this.radii=new Float64Array(count);this.certify=certify;this.enabled=true;this.queries=0;this.skips=0;}
 query(x,y,z,id,margin,signedDistance){
  const k=id*3,dx=x-this.points[k],dy=y-this.points[k+1],dz=z-this.points[k+2],safe=this.radii[id];
  if(this.enabled&&safe>0&&dx*dx+dy*dy+dz*dz<safe*safe){this.skips++;return null;}
  const result=signedDistance(x,y,z);this.queries++;this.points[k]=x;this.points[k+1]=y;this.points[k+2]=z;this.distances[id]=result;this.radii[id]=this.enabled&&result>margin?this.certify(x,y,z,margin,result):0;return result;
 }
 snapshot(){return {enabled:this.enabled,points:Array.from(this.points),distances:Array.from(this.distances),radii:Array.from(this.radii)};}
 restore(state){
  if(state.points.length!==this.points.length||state.distances.length!==this.distances.length||state.radii.length!==this.radii.length)throw new Error('Saved body cache dimensions differ from the current source mesh');
  this.points.set(state.points);this.distances.set(state.distances);this.radii.set(state.radii);this.enabled=state.enabled;
 }
}
