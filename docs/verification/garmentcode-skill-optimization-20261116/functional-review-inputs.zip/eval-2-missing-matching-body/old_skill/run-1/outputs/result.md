# 无法生成 ABC 本人的物理预览

缺少与测量文件 `body.body_sample: ABC` 对应的人体网格 `ABC.obj`。本次已调用物理仿真命令，脚本在生成网格与启动求解器前停止，未使用平均人体替代。

要继续，需要提供 ABC 本人的匹配人体网格（OBJ），并保留该人的匹配测量 YAML；命令中以 `--body-mesh /实际路径/ABC.obj` 指定网格。数据集人体通常采用米单位，其他单位需要正确设置 `--body-scale`。现有 YAML 中的名字和围度不能替代人体表面几何。

本次输入是**合成测试夹具，不是下载的数据集条目**：纸样逐字节复制技能随附的官方示例；测量从 GarmentCode 的 `assets/bodies/mean_all.yaml` 复制，仅添加 `body.body_sample: ABC`。它用于验证缺失人体网格时的行为，不代表真实 ABC 的测量。

纸样检查返回 `0`：8 个布片、18 条缝合、`units_in_meter=100`。环境检查返回 `0`。物理仿真命令返回 `1`，标准输出为空，标准错误原文为：

```text
ERROR: ValueError: Random-body sample requires its matching --body-mesh and body measurements; refusing neutral-body substitution.
```

`run/` 为空，没有生成 `manifest.json`、OBJ、GLB 或预览页面，也没有本次仿真质量结论。完整命令、返回值及 stdout/stderr 见 [command.log](command.log)，逐项运行记录见 [execution.json](execution.json)，夹具来源见 [fixture/provenance.json](fixture/provenance.json)。
