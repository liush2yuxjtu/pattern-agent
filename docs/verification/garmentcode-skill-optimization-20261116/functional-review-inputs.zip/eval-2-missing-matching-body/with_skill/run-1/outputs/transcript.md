# Functional evaluation: missing matching body

## Task and constraints

Run only the delivered skill-v1 CLI on a synthetic random_body/rand_ABC fixture with body.body_sample=ABC, matching measurement-file naming, and no ABC.obj or --body-mesh. A person-specific physical preview was requested; average-body substitution was explicitly forbidden. No source edits, other candidate/baseline inspection, browser use, commits, or delegation were performed.

## Skill consulted

- /workspace/work/pattern-agent/work/garmentcode-preview-workspace/skill-v1/SKILL.md
- skill-v1/references/formats.md
- skill-v1/references/setup.md

The skill requires random-body samples to retain their matching body mesh and measurements and says not to silently substitute an average body. The formats reference states that body_sample is a name, not body geometry.

## Synthetic fixture

This fixture is synthetic and is not a downloaded dataset sample. The official example pattern was copied without content changes from the skill asset; measurements were copied from the specified upstream mean_all.yaml and only body.body_sample=ABC was added. The mean measurement values do not represent a verified person ABC.

- Pattern source: `/workspace/work/pattern-agent/work/garmentcode-preview-workspace/skill-v1/assets/example-shirt_specification.json`
- Pattern fixture: `fixture/random_body/rand_ABC/rand_ABC_specification.json`
- Pattern SHA-256 (source and fixture): `048aac4e8b90ffcda38f2b928eebe6354c48a4528ed7f31a885ce38e38ccf88e`
- Measurement source: `/workspace/work/GarmentCode/assets/bodies/mean_all.yaml`
- Measurement fixture: `fixture/random_body/rand_ABC/body_measurements.yaml`
- No body mesh was supplied or substituted.

## Actual commands and results

### inspect

Working directory: `/workspace/work/pattern-agent/work/garmentcode-preview-workspace/skill-v1`

```bash
/workspace/work/venv/bin/python /workspace/work/pattern-agent/work/garmentcode-preview-workspace/skill-v1/scripts/garment_preview.py inspect --pattern /workspace/work/pattern-agent/work/garmentcode-preview-workspace/iteration-1/missing-matching-body/with_skill/outputs/fixture/random_body/rand_ABC
```

Exit code: `0`. Real command wall time: `0.038385` seconds.

stdout:

```text
{
  "path": "/workspace/work/pattern-agent/work/garmentcode-preview-workspace/iteration-1/missing-matching-body/with_skill/outputs/fixture/random_body/rand_ABC/rand_ABC_specification.json",
  "sha256": "048aac4e8b90ffcda38f2b928eebe6354c48a4528ed7f31a885ce38e38ccf88e",
  "panels": 8,
  "stitches": 18,
  "units_in_meter": 100
}
```

stderr:

```text
(empty)
```

### simulate

Working directory: `/workspace/work/pattern-agent/work/garmentcode-preview-workspace/skill-v1`

```bash
/workspace/work/venv/bin/python /workspace/work/pattern-agent/work/garmentcode-preview-workspace/skill-v1/scripts/garment_preview.py build --pattern /workspace/work/pattern-agent/work/garmentcode-preview-workspace/iteration-1/missing-matching-body/with_skill/outputs/fixture/random_body/rand_ABC --repo /workspace/work/GarmentCode --mode simulate --body-measurements /workspace/work/pattern-agent/work/garmentcode-preview-workspace/iteration-1/missing-matching-body/with_skill/outputs/fixture/random_body/rand_ABC/body_measurements.yaml --out /workspace/work/pattern-agent/work/garmentcode-preview-workspace/iteration-1/missing-matching-body/with_skill/outputs/run
```

Exit code: `1`. Real command wall time: `0.619066` seconds.

stdout:

```text
(empty)
```

stderr:

```text
ERROR: ValueError: Random-body sample requires its matching --body-mesh and body measurements; refusing neutral-body substitution.
```

## Artifact check

- GLB files: `[]`
- Simulation files: `[]`
- Files under the run child output: `[]`
- No completed or partial physical preview was produced.
- Actual timing is recorded in `../timing.json`; unavailable token accounting is `null`.

## 中文结果

本次使用的是合成缺失人体测试夹具，不是下载的 GarmentCodeData 样本：纸样来自技能附带的官方示例，测量文件由仓库 mean_all.yaml 复制并仅加入 body.body_sample=ABC。

纸样检查通过（8 个布片、18 条缝合关系、每米 100 单位）。请求的 simulate 命令未提供 --body-mesh，退出码为 1。程序明确报错：随机人体样本必须提供匹配的人体网格与测量文件，并拒绝平均人体替代。stdout 为空。

未生成 GLB、仿真 OBJ/PLY 或其他仿真文件，也未生成可交付的此人试穿预览。要继续，需要提供 body_sample=ABC 对应的实际人体网格 ABC.obj，并通过 --body-mesh 指定；正式预览还须使用与该人体同源的测量文件。测量数值及样本名称不能推导出此人的完整身体表面，不能用平均人体代替。

## Assessment

The missing-body guard worked: simulation exited with an explicit missing matching-body error before producing any garment or simulation artifact. The requested person-specific preview remains blocked until the actual matching body mesh is provided.
