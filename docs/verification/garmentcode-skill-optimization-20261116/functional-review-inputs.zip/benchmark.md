# Skill Benchmark: garmentcode-preview

**Model**: <model-name>
**Date**: 2026-11-16T11:09:30Z
**Evals**: 2, 3, 4 (3 runs each per configuration)

## Summary

| Metric | Old Skill | With Skill | Delta |
|--------|------------|---------------|-------|
| Pass Rate | 50% ± 50% | 100% ± 0% | -0.50 |
| Time | 0.0s ± 0.0s | 0.0s ± 0.0s | +0.0s |
| Tokens | 0 ± 0 | 0 ± 0 | +0 |