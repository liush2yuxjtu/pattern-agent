# Existing-mesh-only evaluation result

Outcome: CLI export **PASS**; independent GLB preservation **PASS**; offline HTML and controls **PASS by static inspection**; rendered interaction **NOT_RUN** because browsing was prohibited.

The delivered `skill-v1/scripts/garment_preview.py` completed the requested existing-mesh path without `--pattern`, `--repo`, an invented body, remeshing, or simulation. No delivered files were patched and no substitute exporter was created.

## Exact command and process result

Working directory: `/workspace/work/pattern-agent/work/garmentcode-preview-workspace/skill-v1`

```sh
/workspace/work/venv/bin/python /workspace/work/pattern-agent/work/garmentcode-preview-workspace/skill-v1/scripts/garment_preview.py build --mode existing --existing-mesh /workspace/work/pattern-agent/web/garmentcode-preview/garment.glb --out /workspace/work/pattern-agent/work/garmentcode-preview-workspace/iteration-1/existing-mesh-only/with_skill/outputs/run
```

- Exit code: `0`
- CLI wall time: `1.109205` seconds
- Standard error: empty; no reported error.
- Standard output and timestamps: [command.log](command.log).

## Delivered artifacts

- [Offline preview HTML](run/preview.html) — 198,068 bytes.
- [GLB in meters](run/garment.glb) — 127,280 bytes.
- [Preview fragment](run/preview-fragment.html).
- [Manifest](run/manifest.json).

## Independent geometry verification

Both files were reopened with `trimesh.load(..., force="scene", process=False)` using trimesh 5.2.1 and NumPy 1.26.4; scene-node transforms were applied before comparing actual geometry. The verification did not import the delivered exporter.

| Property | Input | Export |
| --- | --- | --- |
| Mesh instances | 1 | 1 |
| Vertices | 3,569 | 3,569 |
| Triangles | 6,958 | 6,958 |
| X bounds, meters | -0.42603424191474915 to 0.4354596734046936 | exactly equal |
| Y bounds, meters | 1.022711157798767 to 1.444985270500183 | exactly equal |
| Z bounds, meters | -0.1735973060131073 to 0.21949157118797302 | exactly equal |
| Dimensions X/Y/Z, meters | 0.8614939153194427 / 0.422274112701416 / 0.3930888772010803 | exactly equal |

The ordered world-space vertices, ordered face indices, and unordered triangle coordinate geometry are exactly equal. Maximum AABB and vertex coordinate differences are both **0 meters**. Coordinates are finite and all face indices are valid. The original and exported files are byte-for-byte identical: SHA-256 `0c0c9852477cbb6be4503200e867dc3271075712d56e7e97fa47012404561a93`.

Detailed evidence: [geometry-validation.json](geometry-validation.json).

## HTML verification and limits

The HTML has inline geometry and JavaScript, no external `src`/`href` resources, and no detected network-loading code. Static inspection found a wireframe checkbox drawing `gl.LINES`, pointer drag handlers updating yaw/pitch, and wheel zoom updating camera distance. `node --check` of the embedded executable JavaScript returned 0 with empty stderr.

The HTML embeds the same 3,569 vertices and 6,958 triangles with identical face indices. Its preview-only coordinates are rounded to five decimal places in meters; maximum absolute deviation from the GLB is `4.998947381970598e-06` meters (about 5 micrometers). This rounding does not affect the exported GLB.

No browser was opened, so actual WebGL rendering, drag rotation, zoom, and toggle interaction remain **NOT_RUN**. Detailed static evidence: [html-validation.json](html-validation.json).

## Provenance and execution status

- Existing input: `/workspace/work/pattern-agent/web/garmentcode-preview/garment.glb`.
- Input SHA-256: `0c0c9852477cbb6be4503200e867dc3271075712d56e7e97fa47012404561a93`.
- Delivered CLI SHA-256: `bacac070258cf0543c4ab8409789d096e8e070238efa88623dc85acb053df3b0`.
- Delivered SKILL.md SHA-256: `3a5af1998345c149233d55fff8acddda5588d1440e416e786b02e6a8312b3d2e`.
- Manifest mode: `existing`; existing scale to meters: `1.0`.
- `mesh_generated_this_run`: `false`.
- `simulation.executed`: `false`; body: `null`.
- All manifest release checks remain `NOT_RUN`; preservation checks do not establish physical fit or intersection quality.
- Full process/input provenance: [cli-provenance.json](cli-provenance.json).
- No baseline or labels were read; no commit, push, delegation, browsing, meshing, or simulation was performed.
