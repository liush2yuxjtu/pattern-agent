# Existing mesh only — old skill functional evaluation

## Task constraints

Only the delivered skill snapshot was used. The user has an existing meter-based GLB and no pattern or upstream repository. No new meshing or simulation is authorized. No CLI repairs, source substitutes, custom exporters, browser checks, or additional agents were used.

## Instructions read

- `skill-snapshot/SKILL.md`
- `skill-snapshot/references/formats.md`
- `skill-snapshot/references/setup.md`

The skill documents `--mode existing --existing-mesh` and says GLB positions are in meters. The delivered `build --help` requires `--pattern PATTERN --repo REPO` and describes `--existing-scale` as “Existing OBJ/PLY units to meters; use 1 for GLB”. These missing inputs were not fabricated.

## Actual build invocation

```sh
/workspace/work/venv/bin/python /workspace/work/pattern-agent/work/garmentcode-preview-workspace/skill-snapshot/scripts/garment_preview.py build --mode existing --existing-mesh /workspace/work/pattern-agent/web/garmentcode-preview/garment.glb --existing-scale 1 --out /workspace/work/pattern-agent/work/garmentcode-preview-workspace/iteration-1/existing-mesh-only/old_skill/outputs/run
```

## Exact combined CLI output

```text
usage: garment_preview.py build [-h] --pattern PATTERN --repo REPO --out OUT
                                [--mode {mesh,simulate,existing}]
                                [--existing-mesh EXISTING_MESH]
                                [--existing-scale EXISTING_SCALE]
                                [--body-mesh BODY_MESH]
                                [--body-measurements BODY_MEASUREMENTS]
                                [--body-scale BODY_SCALE] [--smpl]
                                [--resolution RESOLUTION]
                                [--sim-config SIM_CONFIG]
                                [--max-frames MAX_FRAMES]
                                [--max-seconds MAX_SECONDS] [--source SOURCE]
garment_preview.py build: error: the following arguments are required: --pattern, --repo
```

Exit code: 2

CLI wall time: 0.035786 seconds.

The build failed. Evaluation stopped at this error; no retry, workaround, exporter, or output-dimension check was performed.
