# 实际结果：失败

用户仅提供已有 GLB，没有源纸样或 GarmentCode 仓库。本次只运行旧版技能自带 CLI，使用 `--mode existing`、`--existing-scale 1`，按要求省略 `--pattern` 和 `--repo`，没有重新网格化或物理仿真。

CLI 在参数检查阶段退出，退出码为 2。原始错误如下：

```text
usage: garment_preview.py build [-h] --pattern PATTERN --repo REPO --out OUT
                                [--mode {mesh,simulate,existing}]
                                [--existing-mesh EXISTING_MESH]
                                [--existing-scale EXISTING_SCALE]
                                [--body-mesh BODY_MESH]
                                [--body-measurements BODY_MEASUREMENTS]
                                [--body-scale BODY_SCALE] [--smpl]
                                [--resolution RESOLUTION]
                                [--sim-config SIM_CONFIG]
                                [--max-frames MAX_FRAMES]
                                [--max-seconds MAX_SECONDS] [--source SOURCE]
garment_preview.py build: error: the following arguments are required: --pattern, --repo
```

未交付离线旋转线框 HTML 或输出 GLB，无法验证输出是否保持米制尺寸。没有修复脚本、补造输入或绕过前置条件；失败后已停止。

记录：`command.log`、`transcript.md`；命令耗时见 `../timing.json`，tokens 为 null。
