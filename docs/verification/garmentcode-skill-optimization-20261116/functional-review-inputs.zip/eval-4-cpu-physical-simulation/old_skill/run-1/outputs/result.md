# 旧技能：真实 CPU 物理模拟功能评估

## 结论

原样执行旧技能的 bundled CLI，真实完成 CPU 布料求解并导出初始/最终 GLB、离线预览和 manifest。**执行成功，宽松阈值通过，严格零交叉不通过，合身未获证明。**

| 层次 | 本次实际结果 | 依据 |
| --- | --- | --- |
| 执行 | 通过 | simulate 命令退出码 0；GarmentCode Warp XPBD；device=cpu；232 帧；error=null |
| 旧版宽松质量门槛 | 通过 | static=true，body=0 ≤ 35，self=2 ≤ 300，quality_passed=true |
| 严格零交叉 | 不通过 | 末帧仍报告 self_intersections=2；人体交叉为 0 |
| 合身与可制造性 | 未证明 | 求解、静止和交叉计数不评价松量、压力、活动舒适性、人体动作、缝份或生产质量；本次也未进行浏览器或人工视觉评审 |

这里的“严格零交叉”仅比较旧求解器报告的末帧计数是否均为零。上游计数是 spring/mesh 相交检测，不构成独立、穷尽的碰撞证明。本次未独立重新求交。

## 输入、环境与原样执行

- 仅使用 `/workspace/work/pattern-agent/work/garmentcode-preview-workspace/skill-snapshot` 的旧技能。未访问候选技能，未修改技能脚本、求解器或 manifest schema。
- 纸样：旧技能 `assets/example-shirt_specification.json`，与上游 `assets/Patterns/shirt_mean_specification.json` 字节一致；来自官方仓库示例，非下载的数据集条目。8 个布片、18 组缝合，`units_in_meter=100`。
- 纸样 SHA-256：`048aac4e8b90ffcda38f2b928eebe6354c48a4528ed7f31a885ce38e38ccf88e`。
- 配套人体：官方 `mean_all.obj` 与 `mean_all.yaml`，显式传给 CLI，`body_scale=1.0`。人体网格高 1.719901 米，测量 height=171.99 厘米，量纲一致。
- Python：`/workspace/work/venv/bin/python`，3.11.17；GarmentCode commit：`d449629979028123a5c4dc9e732a2ec19b7fce31`。
- Warp：1.0.0-beta.6，来自 `/workspace/work/NvidiaWarp-GarmentCode`，commit `63baf6855efdd89b2834b74640f84b3bb0d86b50`；运行日志确认本构建无 CUDA，实际 device=cpu。
- 分辨率 1.5 厘米，最大 900 帧、600 秒；默认官方 `gui_sim_props.yaml`。先执行 inspect、doctor 和独立 mesh 模式，再在全新目录执行 simulate。
- simulate 命令总墙钟 116.008370 秒，manifest 的求解阶段计时 112.297 秒。总评估真实墙钟见 [timing.json](../../timing.json)，token 计数不可用，设为 null。

所有评估命令的精确参数、工作目录、环境覆盖、退出码、完整 stdout/stderr 均保留于 [transcript.md](transcript.md) 与 [command.log](command.log)；每个命令另有 `*.execution.json` 和独立日志。

## 静止与穿透门槛解释

旧 CLI 的 quality_passed 要求：无捕获错误、static=true、人体交叉不超过 35、自相交不超过 300。本次为人体 0、自相交 2，所以它原样输出“物理仿真结果 · 通过质量检查”。

静止检查使用逐顶点 L1 帧间位移阈值 0.03 厘米，并容许少于 1.5% 的顶点超过该阈值。本次 50/3569≈1.401% 顶点仍被记为 moving，因而 static=true 不表示所有顶点完全不动。旧技能自带的 CPU snapshot 修正被保留，manifest 中 `cpu_static_check_snapshot_fix=true`；评估未再补丁。

## 独立重读 GLB

使用单独的评估脚本，经 `trimesh.load_mesh(..., process=False)` 从磁盘重新加载两份导出 GLB。结果记录在 [glb-verification.json](glb-verification.json)，未写入原 manifest。

| 项目（米） | 初始 GLB | 最终 GLB |
| --- | --- | --- |
| 顶点 / 三角面 | 3569 / 6958 | 3569 / 6958 |
| X/Y/Z 尺寸 | 1.071470 / 0.459860 / 0.450000 | 0.861494 / 0.422274 / 0.393089 |
| X 范围 | -0.535735 ～ 0.535735 | -0.426034 ～ 0.435460 |
| Y 范围 | 0.945710 ～ 1.405570 | 1.022711 ～ 1.444985 |
| Z 范围 | -0.200000 ～ 0.250000 | -0.173597 ～ 0.219492 |
| 表面积（平方米） | 1.436619 | 0.644906 |
| 非有限顶点 / 非法索引 / 退化三角面 | 0 / 0 / 0 | 0 / 0 / 0 |
| 边界边 / Euler 数 | 184 / -2 | 184 / -2 |

两份 GLB 的顶点数量和三角面索引数组完全一致。按导出顶点顺序比较，平均位移 **0.165963 米**，中位数 0.161587 米，RMS 0.172335 米，最大 0.292777 米，最小 0.046653 米；全部 3569 个顶点位移均超过 1 厘米。它们确有形变，不能把初始网格替代为本次最终结果。

两份网格均法向绕序一致、非 watertight。衣服开口会形成边界，单凭非封闭不能判定坏网格。GLB 顶点顺序的这次对应检查不用于推断原始分割标签。原 manifest 的 `mesh.bounds_m` 是初始网格边界；最终尺寸以此次独立重读为准。

## 警告、预览与限制

- 粗分辨率下有短边仅采样为两个顶点的警告，已完整保留。
- 该示例没有 design_params.yaml，上游记录缺失警告；本次输入为有效的完整 sewing-pattern JSON，网格与模拟均完成。
- 默认附件标签 `lower_interface/right_collar/left_collar/strapless_top` 不在此 shirt 纸样中，上游已关闭 attachment；未补造标签或更改配置。
- [preview.html](drape/preview.html) 与 [preview-fragment.html](drape/preview-fragment.html) 已生成，内嵌几何，静态检查未发现外部脚本/样式/图片 URL。本任务明确禁止浏览器，因此没有声称模型可见、旋转、缩放、线框与切换交互已实际验证。
- 所有警告、上游 OBJ、运行输入和 CPU kernel cache 均保留。此次没有捕获异常、超时或崩溃，但严格零交叉检查失败并未被宽松通过结果覆盖。

## 主要产物

- [初始缝合网格 garment-initial.glb](drape/garment-initial.glb)
- [本次 CPU 模拟最终 garment.glb](drape/garment.glb)
- [离线预览 preview.html](drape/preview.html)
- [原始 manifest.json](drape/manifest.json)
- [实际 sim-config.yaml](drape/sim-config.yaml)
- [独立 GLB 检查](glb-verification.json)
- [人体输入检查](body-verification.json)
- [完整执行记录](transcript.md)
- [完整命令日志](command.log)

