# 官方 shirt／mean_all CPU 真实下垂执行结果

本次使用指定 skill 的原始 bundled CLI 实际完成了 CPU 物理求解与导出，CLI 退出码为 **0**。宽松配置检查通过，但仍有 **2 个上游自相交计数**，所以严格零自相交检查失败；不能称为零穿透合格服装或已验证实体合身。

## 输入、来源与实际命令

- 技能：`/workspace/work/pattern-agent/work/garmentcode-preview-workspace/skill-v1`，读取了 SKILL.md 及 formats、setup、simulation、evaluation、sources 参考文件；未访问 baseline 或预期标签，未浏览、委派、commit 或 push。
- 纸样：skill 的 `assets/example-shirt_specification.json`。它与官方 GarmentCode 的 `assets/Patterns/shirt_mean_specification.json` 字节哈希相同，SHA-256 为 `048aac4e8b90ffcda38f2b928eebe6354c48a4528ed7f31a885ce38e38ccf88e`；来源是官方仓库示例，不是下载的数据集条目。
- 纸样有 8 片裁片、18 组缝合，`units_in_meter=100`，内部为厘米。
- 配套人体：`/workspace/work/GarmentCode/assets/bodies/mean_all.obj` 与 `/workspace/work/GarmentCode/assets/bodies/mean_all.yaml`；人体按米读取，`scale_to_meters=1.0`，未替换为其他人体。非 SMPL 人体来源见官方 `assets/bodies/Readme.md`（GarmentMeasurements）。两份输入的哈希均保存在 manifest。
- GarmentCode commit：`d449629979028123a5c4dc9e732a2ec19b7fce31`；修改版 Warp commit：`63baf6855efdd89b2834b74640f84b3bb0d86b50`；Warp `1.0.0-beta.6`。日志确认 CUDA disabled、`device=cpu`。
- 分辨率 **1.5 cm**，最大 **900 帧／600 秒**；实际使用默认官方 GUI 配置，生效配置完整保存在 `simulation/sim-config.yaml`。

工作目录：`/workspace/work/pattern-agent/work/garmentcode-preview-workspace/skill-v1`。

```sh
CUDA_VISIBLE_DEVICES='' PYTHONUNBUFFERED=1 /workspace/work/venv/bin/python scripts/garment_preview.py build --pattern assets/example-shirt_specification.json --repo /workspace/work/GarmentCode --mode simulate --body-mesh /workspace/work/GarmentCode/assets/bodies/mean_all.obj --body-measurements /workspace/work/GarmentCode/assets/bodies/mean_all.yaml --resolution 1.5 --max-frames 900 --max-seconds 600 --out /workspace/work/pattern-agent/work/garmentcode-preview-workspace/iteration-1/cpu-physical-simulation/with_skill/outputs/cpu-shirt-20261116T110004Z/simulation
```

日志包装器只捕获命令和输出，不编辑或替换 skill、网格器或求解器。入口 `scripts/garment_preview.py` 的运行前后 SHA-256 均为 `bacac070258cf0543c4ab8409789d096e8e070238efa88623dc85acb053df3b0`。未重复生成一套 mesh 后再仿真；`simulate` 自行生成并保存初始网格。

## 执行、稳定、宽松阈值与严格门槛

实际运行 **232 帧**后达到了上游静止判定，没有耗尽帧数或时间上限；`executed=true`、`error=null`。manifest 记录的仿真时长为 **112.023 秒**；包含网格化和导出的 CLI 墙钟为 **116.086 秒**。

`static=true` 仍允许少量顶点运动：生效配置的 `static_threshold=0.03`（仿真坐标单位），`non_static_percent=1.5`。本次 50/3569（1.401%）顶点超过相邻帧 L1 位移阈值，低于允许比例。因此这里的“静止”是上游容差判定。

| 上游诊断 | 实测 | 宽松上限 |
| --- | ---: | ---: |
| 人体相交计数 | 0 | 35 |
| 自相交计数 | 2 | 300 |

`quality_passed=true` 与 `upstream_threshold_passed=true` 仅表示本次静止状态和 **35／300** 的宽松上限通过。严格零相交要求所有计数为零，本次整体不通过。

| manifest release 项 | 实际结果 |
| --- | --- |
| `simulation_execution` | `PASS` |
| `stability` | `PASS` |
| `upstream_threshold_check` | `PASS` |
| `strict_zero_body_intersections` | `PASS` |
| `strict_zero_self_intersections` | `FAIL` |
| `independent_full_geometry_audit` | `NOT_RUN` |
| `physical_fit` | `NOT_RUN` |

这些计数来自上游诊断，不是独立完整几何审计。独立 GLB 结构检查已执行，但完整独立相交审计和实体合身均维持 **NOT_RUN**。使用固定人体及未经过真实面料标定的研究参数，不能从静止、退出码或预览推断实体合体质量。

## 独立重新打开 GLB 的实测值

另用 `independent_glb_check.py` 和 trimesh **5.2.1** 从最终 GLB 字节读取，`process=False`，应用场景变换，没有调用 skill 的解析器或验证函数。验证命令退出码为 **0**。

| 指标 | 初始 GLB | 仿真后 GLB |
| --- | --- | --- |
| 顶点／三角形 | 3569／6958 | 3569／6958 |
| XYZ 尺寸（米） | 1.071470 × 0.459860 × 0.450000 | 0.861494 × 0.422274 × 0.393089 |
| 场景几何数／网格节点数 | 1／1 | 1／1 |
| 连通顶点分量 | 1 | 1 |
| 边界边 | 184 | 184 |
| 多于两面共享的边 | 0 | 0 |
| 零面积三角形（≤1e-14 m²） | 0 | 0 |

两者都具有有效 GLB v2 头、有限坐标与合法面索引；面片有序索引完全相同，未用 GLB 顶点序号推断裁片标签。两者均非封闭网格，绕序一致，无重复面或未引用顶点。开口的具体语义未另外审计。

在相同有序拓扑上，3569/3569 个顶点的初始到最终位移大于 1 μm。位移均值 **0.165963 m**，中位数 **0.161587 m**，P95 **0.248010 m**，最大 **0.292777 m**，最小 **0.046653 m**。这确认最终导出与初始几何不同；物理执行依据还包括实际 CPU 内核日志、帧数及求解状态。

## 预览、输出与保留的诊断

- [初始 GLB](simulation/garment-initial.glb)、[仿真后 GLB](simulation/garment.glb)。
- [离线预览](simulation/preview.html)、[聊天片段](simulation/preview-fragment.html)。预览展示的是已计算网格，操作视角不会重新求解。
- [原始 manifest](simulation/manifest.json)、[实际配置](simulation/sim-config.yaml)、[独立检查 JSON](independent-glb-check.json)。
- [完整执行 transcript](transcript.md)、[完整 command.log](command.log)、`logs/*.stdout`、`logs/*.stderr`、`logs/*.json`。文件内保留完整输出，未受工具界面的截断影响。

静态检查发现 HTML 无外部 script 或 stylesheet、无 fetch/XMLHttpRequest/WebSocket 调用。按任务禁止浏览的约束，没有打开浏览器，所以模型实际渲染、拖动旋转、缩放、线框、人体和初始／最终切换的交互效果均未验证。

CLI 的粗分辨率短边警告、缺少可选 design_params.yaml 的警告和缺少 attachment 标签导致附着关闭的警告均保留，未修改 skill 消除它们。

还保留了两次前期文件发现命令的失败，它们不属于 CPU 求解失败：

- `official-body-assets`：退出码 2。命令为 `rg --files assets/bodies assets/body_measurements`。
- `provenance-hashes`：退出码 1。命令为 `sha256sum assets/example-shirt_specification.json /workspace/work/GarmentCode/assets/Patterns/shirt_mean_specification.json /workspace/work/GarmentCode/assets/bodies/mean_all.obj /workspace/work/GarmentCode/assets/bodies/mean_all.yaml scripts/garment_preview.py scripts/cpu_snapshot.py`。

其中 `assets/body_measurements` 和 `scripts/cpu_snapshot.py` 均不存在；后续直接使用已确认存在的官方 mean_all.yaml，以及 CLI 内置的 SnapshotCloth 逻辑。没有补建这些路径或修改求解器。

本次有显式 UTC 采样的工作区间为 **329.667 秒**；最初一次 SKILL.md／AGENTS.md 读取发生在该计时区间前，详见 `timing.json` 的计时范围。计时同时写在 `../../timing.json`（with_skill/timing.json，即 outputs/../timing.json）。实际 token 用量不可取得，记录为 `null`。
