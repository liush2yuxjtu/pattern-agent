from playwright.sync_api import sync_playwright
from PIL import Image
import base64,io,json
with sync_playwright() as p:
 for name,extra,ignore in [('vulkan',[],[]),('compositor',[],['--disable-gpu-compositing']),('enabled',['--enable-gpu'],['--disable-gpu-compositing'])]:
  flags=['--no-sandbox','--enable-unsafe-webgpu','--enable-unsafe-swiftshader','--use-angle=swiftshader','--enable-features=Vulkan','--use-vulkan=swiftshader','--disable-vulkan-surface']+extra
  b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=flags,ignore_default_args=ignore);page=b.new_page();page.route('**/testgpu',lambda r:r.fulfill(body='<canvas width="256" height="256"></canvas>',content_type='text/html'));page.goto('http://127.0.0.1:8771/testgpu')
  try:
   data=page.evaluate('''async()=>{const c=document.querySelector('canvas');const a=await navigator.gpu.requestAdapter();const d=await a.requestDevice();const ctx=c.getContext('webgpu');ctx.configure({device:d,format:navigator.gpu.getPreferredCanvasFormat(),alphaMode:'opaque'});window.draw=()=>{const en=d.createCommandEncoder();const pass=en.beginRenderPass({colorAttachments:[{view:ctx.getCurrentTexture().createView(),clearValue:[1,0,0,1],loadOp:'clear',storeOp:'store'}]});pass.end();d.queue.submit([en.finish()]);};const tick=()=>{draw();requestAnimationFrame(tick);};tick();await d.queue.onSubmittedWorkDone();return c.toDataURL();}''');png=base64.b64decode(data.split(',')[1]);open('/workspace/work/webgpu-cloth-20261118/read-'+name+'.png','wb').write(png);page.screenshot(path='/workspace/work/webgpu-cloth-20261118/screen-'+name+'.png');print(name,Image.open(io.BytesIO(png)).getpixel((100,100)),Image.open('/workspace/work/webgpu-cloth-20261118/screen-'+name+'.png').getpixel((100,100)))
  except Exception as e:print(name,str(e)[:200])
  b.close()
