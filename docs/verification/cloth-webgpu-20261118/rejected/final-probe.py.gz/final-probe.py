from playwright.sync_api import sync_playwright
from pathlib import Path
import json
raw=Path('/workspace/work/pattern-agent/web/freesewing-webgpu.html').read_text()
# Use a temporary debug-only exposed renderer; source remains unchanged.
import re
# Minifier symbol names are discovered at the actual console payload via source sourcemap-free marker replacement.
pos=raw.index('version:"2.4.0"');start=raw.rfind('window.clothLab=',0,pos);ready=raw[start:pos];print('marker',ready[:130])
# We can inject by inspecting the readable final readColorBuffer function's renderer access symbol.
match=re.search(r'new Float32Array\(await (\w+)\.getArrayBufferAsync\((\w+)\.attributes.color\)\)',raw);r,g=match.groups();raw=raw[:start]+f'window.__renderer={r};window.__geometry={g};'+raw[start:]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-unsafe-webgpu','--use-angle=swiftshader','--enable-unsafe-swiftshader','--enable-features=Vulkan','--use-vulkan=swiftshader']);page=b.new_page();page.route('**/freesewing-webgpu.html',lambda route:route.fulfill(body=raw,content_type='text/html'));page.on('pageerror',lambda e:print('ERR',e));page.on('console',lambda m:print(m.type,m.text[:1000]) if m.type in ['warning','error'] else None);page.goto('http://127.0.0.1:8771/freesewing-webgpu.html');page.wait_for_function('window.clothLab?.ready',timeout=120000)
 for i in range(2):
  print(page.evaluate('({info:__renderer.info,lost:__renderer._isDeviceLost,initialized:__renderer.initialized,backend:clothLab.renderBackend(),size:[__renderer.domElement.width,__renderer.domElement.height]})'));page.get_by_role('button',name='Back',exact=True).click();page.wait_for_timeout(500)
 page.get_by_role('button',name='Strain',exact=True).click();print('buffer',len(page.evaluate('clothLab.readColorBuffer()')));page.screenshot(path='/workspace/work/webgpu-cloth-20261118/debug.png');b.close()
