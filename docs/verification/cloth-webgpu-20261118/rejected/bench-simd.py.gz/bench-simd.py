import os,json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
os.sched_setaffinity(0,[0,1,2,3])
flags=['--no-sandbox','--enable-unsafe-webgpu','--enable-unsafe-swiftshader','--use-angle=swiftshader','--enable-features=Vulkan','--use-vulkan=swiftshader','--use-gl=angle']
results={}
with sync_playwright() as pw:
 for mode in ['new-gpu','new-webgl']:
  b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=flags);p=b.new_page(viewport={'width':1440,'height':1100});p.on('pageerror',lambda e:print('ERROR',e));url='http://127.0.0.1:8771/'+('freesewing-free-waist.html' if mode=='old-webgl' else 'prewarm.html')+('?renderer=webgl' if mode=='new-webgl' else '?renderer=webgpu')
  if mode!='old-webgl':p.route('**/prewarm.html*',lambda r:r.fulfill(body=Path('/workspace/work/webgpu-cloth-20261118/simd.html').read_bytes(),content_type='text/html'))
  p.goto(url,wait_until='networkidle');p.wait_for_function('window.clothLab?.ready',timeout=120000)
  for view in ['Back','Front']:p.get_by_role('button',name=view,exact=True).click();p.screenshot(path='/workspace/work/webgpu-cloth-20261118/bench-'+mode+'-'+view+'.png')
  initial=p.evaluate('clothLab.stats().steps');p.get_by_role('button',name='Run drape',exact=True).click();p.wait_for_function('clothLab.stats().steps>='+str(initial+12),timeout=60000);p.get_by_role('button',name='Pause',exact=True).click();p.evaluate('clothLab.step(360-clothLab.stats().steps)');stats=p.evaluate('clothLab.stats()');results[mode]=stats;print(mode,stats['solver_ms_p50'],stats['solver_ms_p95'],stats['stepTiming_ms'],flush=True)
  if mode=='new-gpu':
   c=b.new_browser_cdp_session() if False else p.context.new_cdp_session(p);c.send('Profiler.enable');c.send('Profiler.start');p.evaluate('clothLab.step(16)');profile=c.send('Profiler.stop')['profile'];Path('/workspace/work/webgpu-cloth-20261118/cpu-profile.json').write_text(json.dumps(profile))
  b.close()
Path('/workspace/work/webgpu-cloth-20261118/bench-simd.json').write_text(json.dumps(results,indent=2))
