from pathlib import Path
import json,hashlib,sys,csv
from PIL import Image
import numpy as np
from audit_geometry import obj,measure,read
w=Path('work/full-imagegen-skill-evals-20261118');out=w/'iteration-1/eval-1-original-product/with_skill/run-1/outputs';g=w/'grader';a=read('web/human-studio/assets/human.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipts=read(out/'generation-receipts.json')['images'];rows=[]
for r in receipts:
 p=out/r['path'];native=Path(r['original_tool_path']);size=list(Image.open(p).size)
 rows.append({'view':r['view'],'native_path':str(native),'hash_matches':sha(p)==sha(native)==r['sha256'],'pixels_match':size==[r['width'],r['height']],'pixels':size,'reference_hashes_match':all(sha(k)==v for k,v in r['reference_sha256'].items())})
assert len({r['view'] for r in rows})==7 and all(r['hash_matches'] and r['pixels_match'] and r['reference_hashes_match'] for r in rows)
p=out/'model-fit';ed=p/'editor-probe';original,_=obj(ed/'initial-neutral.obj');edited,_=obj(ed/'edited-neutral.obj');original_sizes=measure(original,a);edited_sizes=measure(edited,a)
s0=read(p/'final/final-state.json');s1=read(ed/'edited-state.json');changed={k:[s0['poseDegrees'][k],s1['poseDegrees'][k]] for k in s0['poseDegrees'] if s0['poseDegrees'][k]!=s1['poseDegrees'][k]}
v=json.loads((p/'final/views/view-provenance.json').read_text());vs=read(p/'final/views/state.json');state_match={k:s0[k]==vs[k] for k in ['asset','dimensions','morphWeights','poseDegrees']};mesh=(p/'final/posed.obj').read_bytes()==(p/'final/views/posed.obj').read_bytes();ph=hashlib.sha256(json.dumps(vs['poseDegrees'],sort_keys=True).encode()).hexdigest()
viewcheck={k:row['state_sha256']==sha(p/'final/views/state.json') and row['pose_sha256']==ph and row['posed_mesh_sha256']==sha(p/'final/posed.obj') for k,row in v.items()}
f=read(p/'model-fit-freeze.json');freeze=all(sha(p/k)==h for k,h in f['sha256'].items())
result={'generation':rows,'six_distinct_native_outputs':len({r['original_tool_path'] for r in receipts if r['view']!='raw-pose-guide'})==6,'model_fit_freeze_intact':freeze,'final_vs_views_semantic_state_match':state_match,'final_vs_views_mesh_bytes_equal':mesh,'view_provenance_bound':viewcheck,'edited_vertex_delta_max_cm':float(np.linalg.norm(original-edited,axis=1).max()),'actual_editor_waist_change_cm':edited_sizes['waist']-original_sizes['waist'],'editor_primary_edited_values_match_obj':max(abs(edited_sizes[k]-read(ed/'edited-measurements.json')['measured_values_cm'][k]) for k in edited_sizes),'editor_saved_pose_changed':changed,'limits':'Editor download OBJ/JSON independently reopened; screenshots visually inspected. Same-view provenance is not evidence of raw-photo pose accuracy. Initial state is a prior avatar, not true person size.'}
(g/'final/artifact-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='generation'},indent=2))
