#!/usr/bin/env python3
"""Independent OBJ/measurement/sparse-morph/FK audit; imports no executor code."""
from pathlib import Path
import argparse, csv, hashlib, json, math
import numpy as np
from scipy.spatial.transform import Rotation
import cv2

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
def obj(p):
 v=[];f=[]
 for line in Path(p).read_text().splitlines():
  t=line.split()
  if not t: continue
  if t[0]=='v': v.append(list(map(float,t[1:4])))
  elif t[0]=='f': f.append([int(s.split('/')[0])-1 for s in t[1:]])
 v=np.asarray(v,float);f=np.asarray(f,int)
 assert np.isfinite(v).all() and f.shape[1]==3 and f.min()>=0 and f.max()<len(v)
 return v,f

def reconstruct(asset,state):
 rest=np.array(asset['vertices'],float).reshape(-1,3)
 for control,weight in zip(asset['controls'],state['morphWeights']):
  for row in control['incr' if weight>=0 else 'decr']:
   i=int(row[0]);rest[i]+=abs(weight)*np.array(row[1:])
 ids=np.asarray(asset['bodyVertexIds']);rest[:,1]-=rest[ids,1].min()
 bones=asset['bones'];n=len(bones);index={b['name']:i for i,b in enumerate(bones)}
 head=np.array([rest[asset['joints'][b['head']]].mean(0) for b in bones]);tail=np.array([rest[asset['joints'][b['tail']]].mean(0) for b in bones])
 frame=[]
 for a,b in zip(head,tail):
  y=b-a;y/=max(np.linalg.norm(y),1e-12)
  if np.linalg.norm(y)<.5:y=np.array([0.,1.,0.])
  x=np.cross(y,[0,0,1])
  if np.linalg.norm(x)<1e-8:x=np.cross(y,[0,1,0])
  x/=np.linalg.norm(x);frame.append(np.column_stack([x,y,np.cross(x,y)]))
 frame=np.asarray(frame);world_rot=[None]*n;world_pos=[None]*n
 def solve(i):
  if world_rot[i] is not None:return
  p=index.get(bones[i]['parent'],-1)
  local=Rotation.from_euler('XYZ',state['poseDegrees'][bones[i]['name']],degrees=True).as_matrix()
  if p<0:world_rot[i]=frame[i]@local;world_pos[i]=head[i]
  else:
   solve(p);world_rot[i]=world_rot[p]@frame[p].T@frame[i]@local
   world_pos[i]=world_pos[p]+world_rot[p]@frame[p].T@(head[i]-head[p])
 for i in range(n):solve(i)
 world_rot=np.asarray(world_rot);world_pos=np.asarray(world_pos)
 matrices=world_rot@frame.transpose(0,2,1);offset=world_pos-np.einsum('nij,nj->ni',matrices,head)
 skins=np.asarray(asset['skinIndices']).reshape(-1,4);weights=np.asarray(asset['skinWeights'],float).reshape(-1,4);weights/=weights.sum(1,keepdims=True)
 posed=np.zeros_like(rest)
 for k in range(4):posed+=weights[:,k,None]*(np.einsum('nij,nj->ni',matrices[skins[:,k]],rest)+offset[skins[:,k]])
 floor=posed[ids,1].min();posed[:,1]-=floor;world_pos[:,1]-=floor
 return rest[ids],posed[ids],world_pos

def measure(v,asset):
 mapping={i:j for j,i in enumerate(asset['bodyVertexIds'])};result={}
 for c in asset['controls']:
  path=[mapping[x] for x in c['path']]
  result[c['key']]=float(np.ptp(v[:,1])) if c['key']=='height' else sum(float(np.linalg.norm(v[j]-v[i])) for i,j in zip(path,path[1:]))
 return result

def masks(v,f,camera):
 h,w=camera['height'],camera['width'];m=np.array(camera['world_to_pixel_homogeneous'],float)
 xy=np.column_stack([v,np.ones(len(v))])@m.T;xy=xy[:,:2]/xy[:,2,None]
 out=np.zeros((h,w),np.uint8)
 for face in f:cv2.fillConvexPoly(out,np.rint(xy[face]).astype(np.int32),255)
 return out

def run(model,assetpath,out):
 model=Path(model);statepath=model/'final-state.json';state=read(statepath);asset=read(assetpath)
 neutral,nf=obj(model/'neutral.obj');posed,pf=obj(model/'posed.obj');rest,reposed,joints=reconstruct(asset,state)
 mapping={i:j for j,i in enumerate(asset['bodyVertexIds'])};ef=np.array([[mapping[x] for x in face] for face in np.array(asset['indices']).reshape(-1,3)])
 assert np.array_equal(nf,ef) and np.array_equal(pf,ef)
 values=measure(neutral,asset);measurementdir=next(p for p in [model,*model.parents] if (p/'measurements.model.json').exists());report=read(measurementdir/'measurements.model.json')
 csvpath=measurementdir/'measurements.model.csv'
 rows=list(csv.DictReader(csvpath.open()));jr={r['name']:r for r in report['measurements']};cr={r['name']:r for r in rows}
 assert len(jr)==len(cr)==12
 numerrors={k:abs(values[k]-report['measured_values_cm'][k]) for k in values}
 csv_errors={k:abs(values[k]-float(cr[k]['value_cm'])) for k in values}
 result={'implementation':'independent script; no exporter/runtime imports','state_sha256':sha(statepath),'asset_sha256':sha(assetpath),'asset_identity':state['asset']==sha(assetpath),'vertices':len(neutral),'triangles':len(nf),'topology_exact':True,'neutral_reconstruction_max_cm':float(np.linalg.norm(rest-neutral,axis=1).max()),'posed_reconstruction_max_cm':float(np.linalg.norm(reposed-posed,axis=1).max()),'actual_values_cm':values,'measurement_max_error_cm':max(numerrors.values()),'csv_max_error_cm':max(csv_errors.values()),'definitions_present':all(jr[k].get('definition') and jr[k]['unit']=='cm' for k in values),'pose_complete':set(state['poseDegrees'])=={b['name'] for b in asset['bones']},'measurements_not_person_accuracy':all(jr[k].get('person_accuracy_verified') is False for k in values),'fingerprints':{str(p):sha(p) for p in [statepath,model/'neutral.obj',model/'posed.obj',assetpath]}}
 camera=read(model/'camera.json');mask=masks(posed,pf,camera);out=Path(out);out.mkdir(parents=True,exist_ok=True);cv2.imwrite(str(out/'independent-photo-mask.png'),mask)
 # Nearby falsification probes use the same numeric/geometry validators.
 result['fault_controls']={'forged_waist_plus_10_rejected':abs(values['waist']-(report['measured_values_cm']['waist']+10))>.01,'wrong_neutral_posed_rejected':float(np.linalg.norm(rest-posed,axis=1).max())>.002,'moved_pelvis_mesh_rejected':float(np.linalg.norm((posed+np.array([10,0,0]))-reposed,axis=1).max())>.002}
 result['passed_numeric_geometry']=result['asset_identity'] and result['neutral_reconstruction_max_cm']<.002 and result['posed_reconstruction_max_cm']<.002 and result['measurement_max_error_cm']<.01 and result['csv_max_error_cm']<.01 and result['definitions_present'] and result['pose_complete']
 (out/'geometry-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--asset',default='web/human-studio/assets/human.json');p.add_argument('--out',required=True);a=p.parse_args();run(a.model,Path(a.asset),a.out)
