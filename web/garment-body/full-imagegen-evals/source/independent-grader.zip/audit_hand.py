from pathlib import Path
import json,sys
import numpy as np
from audit_geometry import obj,read
w=Path('work/full-imagegen-skill-evals-20261118');m=w/'iteration-1/eval-1-original-product/with_skill/run-1/outputs/model-fit/final';a=read('web/human-studio/assets/human.json')
n,f=obj(m/'neutral.obj');v,_=obj(m/'posed.obj');tri=v[f];nt=n[f];keep=np.all((abs(nt[:,:,0])<22)&(nt[:,:,1]>95)&(nt[:,:,1]<140),axis=1);tri=tri[keep]
# Ray/triangle test in XY uses 2x2 linear solves rather than the executor's barycentric expressions.
o=tri[:,0,:2];e1=tri[:,1,:2]-o;e2=tri[:,2,:2]-o;basis=np.stack([e1,e2],axis=2);det=np.linalg.det(basis);keep=abs(det)>1e-9;tri=tri[keep];o=o[keep];inverse=np.linalg.inv(basis[keep]);lo=tri[:,:,:2].min(1);hi=tri[:,:,:2].max(1)
ids=np.array(a['bodyVertexIds']);skin=np.array(a['skinIndices']).reshape(-1,4)[ids];weight=np.array(a['skinWeights']).reshape(-1,4)[ids];weight/=weight.sum(1,keepdims=True);result={}
for side in ['L','R']:
 bones=[i for i,b in enumerate(a['bones']) if b['name'].endswith('.'+side) and b['name'].startswith(('finger','wrist'))];hands=np.where((np.isin(skin,bones)*weight).sum(1)>.5)[0];clear=[];inside=0
 for h in hands:
  xy=v[h,:2];candidate=np.where(np.all((xy>=lo)&(xy<=hi),axis=1))[0]
  if not len(candidate):continue
  uv=np.einsum('nij,nj->ni',inverse[candidate],xy-o[candidate]);hit=(uv>=0).all(1)&(uv.sum(1)<=1);ii=candidate[hit];uv=uv[hit]
  depths=tri[ii,0,2]+uv[:,0]*(tri[ii,1,2]-tri[ii,0,2])+uv[:,1]*(tri[ii,2,2]-tri[ii,0,2])
  if len(depths)<2 or depths.max()-depths.min()<1:continue
  z=v[h,2];clear.append(float(z-depths.max()));inside+=bool(depths.min()+.05<z<depths.max()-.05)
 result[side]={'hand_vertices':len(hands),'covered':len(clear),'inside':int(inside),'min_clearance_cm':min(clear) if clear else None,'p05_clearance_cm':float(np.percentile(clear,5)) if clear else None}
(w/'grader/final/hand-audit.json').write_text(json.dumps({'implementation':'Independent actual OBJ and 2x2 inverse ray/triangle intersections; no executor imports','hands':result,'limits':'Only anterior rays intersecting open torso patch classify; uncovered is UNKNOWN, no cloth contact and no pinch success inferred'},indent=2)+'\n');print(result)
