# Actual run artifact contract

Both configurations receive identical original bytes, user prompt, generic M170 prior and generic Runtime. They must not receive private protocol/case annotation or oracle masks. No case-specific fitting solution is provided.

Save in outputs/: final-state.json, neutral.obj, posed.obj, camera.json, photo-render.png, final-mask.png, measurements.json, report.md, TRACE.md, input-provenance.json. The saved camera must include actual source width/height, world_to_pixel_homogeneous 3x4, and final=[scale,centerX,centerY,yaw,pitch,roll] if using the generic oblique orthographic renderer. Never stretch an exported PNG to mimic a different camera.

Save canonical views/ using Runtime.save(final_state, view_camera, outputs/views), providing views front/side/back. This creates views/state.json,camera.json,posed.obj,neutral.obj,joints.json,view-provenance.json, each PNG and each mask. Main state and canonical state must share all cm dimensions and full 163-bone poseDegrees. Also retain actual depth raw array and validity mask and actual projected pose points when generated geometrically.

Save initial state/camera/mask and parameter-block history. A different model per view is failure. Keep standard initial M dimensions unless actual bounded fit chooses supported conditional parameters; body dimensions are not measured person data.

Case A requests six independent Image Gen outputs in images/{front,side,back,closeup,pose,depth}.png, each with native tool receipt/input hashes/settings/native size and semantically correct garment details. These are generated hypotheses; not detector/Z-buffer outputs or true hidden anatomy. No collage crops presented as six native images. Optional extra pose annotation must be separately labelled. Case B and holdout pose-fit branches explicitly do not request fresh six-image generation; report NOT_RUN there without pretending full-six quality was tested.

Record all real tool calls/progress/errors in TRACE.md and process/source claims in report. Do not self-grade with the private grader, copy sibling candidate data, or inspect holdout data while developing the skill. Timing/token metadata only from actual available telemetry; unknown stays null.
