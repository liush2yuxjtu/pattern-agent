# Independent review contract

Read original inputs, actual output files and full TRACE.md/tool receipts. Do not grade by filename existence. Save a manual-review.json OUTSIDE the executor output directory. Bind `reviewed_artifact_sha256` to all reviewed final-state.json, posed.obj, camera.json, photo-render.png, canonical view PNGs and generated images (not a self-report metric file). Missing or stale manual evidence cannot pass.

Use `observations` list with `{id,verdict,evidence}`, verdict PASS/FAIL/UNKNOWN; IDs: source_and_prior, pose_action_3d, measurement_claims, generation_receipts, garment_fidelity. Only include generation IDs for the full-six case. For every PASS cite concrete files/visible features/tool events, and for uncertainty preserve its source.

3D action review must inspect source-camera + actual front/side/back, not only eyes/wrists. Check upper-arm/forearm directions, shoulder/torso/pelvis alignment, hand orientation/gesture and obvious limb/body intersections. Never demand observed coordinates for an occluded pocket wrist. Never call zero classified torso rays proof of collision-free hands. A positive limited skin interval check is not cloth simulation or contact verification.

Generation review must inspect all six actual native outputs plus original source and true call receipts. A picture count is insufficient. Wrong boatneck/collar, real long sleeves misread as short/three-quarter sleeves due styling, missing placket/darts, unlabelled invented back/depth or pose incompatibility are real failures. Original person centimetre accuracy and hidden depth are unidentifiable, not PASS.

If doing blind comparison, copy outputs to anonymous A/B paths with config/skill labels removed, preserve hashes, read comparator.md and never inspect the mapping until comparison.json is frozen. Grader/analyzer feedback on assertions is separate from model-quality judgments.
