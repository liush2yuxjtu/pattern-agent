"""Versioned grader fault injection. Never modifies actual functional output."""
import pathlib,json,sys,shutil,concurrent.futures,subprocess,hashlib,cv2,numpy as np
root=pathlib.Path(__file__).resolve().parents[3];sys.path.insert(0,str(root/'tools/skill_evals'))
import commerce_grade as grader
base=root/'work/commerce-skill-evals-20261118';source=base/'iteration-1/eval-2-everlane-pocket-pose/with_skill/run-1/outputs';dest=base/'grade-evidence/grader-controls-v1.1';dest.mkdir(parents=True,exist_ok=True)
controls=[]
assert grader.paired_intervals([0,0.0001,2,5,7])==[(0.0,2.0),(5.0,7.0)]
assert not any(lo<3<hi for lo,hi in grader.paired_intervals([0,2,5,7]))
assert grader.paired_intervals([0,2,5]) is None
controls.extend([dict(name='disjoint_skin_air_gap',passed=True,evidence='Crossings0,2,5,7 yield two intervals; point3 in air is not inside despite minmax hull.'),dict(name='odd_open_ray_unknown',passed=True,evidence='Three unique crossings return UNKNOWN, not collision-free.')])
for name in ['pixel_view_tamper','posed_obj_translation','camera_parameter_alias']:
 d=dest/name/'candidate'
 if d.exists():shutil.rmtree(d)
 d.mkdir(parents=True,exist_ok=True)
 for p in source.iterdir():
  q=d/p.name
  if q.is_symlink():q.unlink()
  if not q.exists():q.symlink_to(p,target_is_directory=p.is_dir())
 if name=='pixel_view_tamper':
  (d/'views').unlink();(d/'views').mkdir()
  for p in (source/'views').iterdir():(d/'views'/p.name).symlink_to(p)
  path=d/'views/side.png';im=cv2.imread(str(path));path.unlink();im[:100,:100]=[255,0,255];cv2.imwrite(str(path),im)
 elif name=='posed_obj_translation':
  p=d/'posed.obj';text=p.read_text();p.unlink();lines=[]
  for line in text.splitlines():
   if line.startswith('v '):v=list(map(float,line.split()[1:]));v[0]+=15;line='v '+' '.join(map(str,v))
   lines.append(line)
  p.write_text('\n'.join(lines)+'\n')
 else:
  p=d/'camera.json';data=json.loads(p.read_text());p.unlink();data['final']=[999,-999,888,777,666,555];data['final_definition']='Deliberately nonsensical non-authoritative alias; original authoritative 3x4 matrix preserved.';p.write_text(json.dumps(data))
def run(name):
 r=subprocess.run([sys.executable,str(root/'tools/skill_evals/commerce_grade.py'),'--candidate',str(dest/name/'candidate'),'--case',str(base/'protocol/cases/everlane-blue-shirt/case.json'),'--out',str(dest/name/'result')],capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stderr[-1000:])
 d=json.loads((dest/name/'result/grading.json').read_text())
 if name=='pixel_view_tamper':passed=d['view_integrity']['checks']['side']['verdict']=='FAIL';evidence=d['view_integrity']['checks']['side']
 elif name=='posed_obj_translation':passed=d['source_reconstruction']['posed_max_error_cm']>14.99 and not d['expectations'][1]['passed'];evidence=d['source_reconstruction']
 else:passed=d['view_integrity']['checks']['photo']['verdict']=='PASS';evidence=d['view_integrity']['checks']['photo']
 return dict(name=name,passed=passed,evidence=evidence,grading_sha256=grader.sha(dest/name/'result/grading.json'))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:controls.extend(pool.map(run,['pixel_view_tamper','posed_obj_translation','camera_parameter_alias']))
report=dict(grader_sha256=grader.sha(pathlib.Path(grader.__file__)),actual_source_state_sha256=grader.sha(source/'final-state.json'),controls=controls,all_passed=all(x['passed'] for x in controls),limits='These controls verify specific checker failure detection/invariance, not fitting quality. The real paired outcomes are independently graded and remain FAIL.')
(dest/'controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
