#!/usr/bin/env bash
set -euo pipefail
cd /workspace/work/pattern-agent
python work/commerce-skill-evals-20261118/iteration-1/eval-2-everlane-pocket-pose/old_skill/run-1/outputs/solve.py
python work/commerce-skill-evals-20261118/iteration-1/eval-2-everlane-pocket-pose/old_skill/run-1/outputs/export-normalized.py
python work/commerce-skill-evals-20261118/skill-v0/scripts/inspect_human_state.py --state work/commerce-skill-evals-20261118/iteration-1/eval-2-everlane-pocket-pose/old_skill/run-1/outputs/final-state.json --asset-json web/human-studio/assets/human.json --out work/commerce-skill-evals-20261118/iteration-1/eval-2-everlane-pocket-pose/old_skill/run-1/outputs/independent-neutral-check.json
