#!/bin/sh
set -eu
cd "$(dirname "$0")/../../../../../../.."
OUT=work/commerce-skill-evals-20261118/iteration-1/eval-2-everlane-pocket-pose/with_skill/run-1/outputs
python "$OUT/solve.py" > "$OUT/solver.log" 2>&1
python work/commerce-skill-evals-20261118/skill-v1/scripts/inspect_human_state.py --state "$OUT/final-state.json" --asset-json web/human-studio/assets/human.json --out "$OUT/independent-neutral-check.json"
python "$OUT/finalize.py"
