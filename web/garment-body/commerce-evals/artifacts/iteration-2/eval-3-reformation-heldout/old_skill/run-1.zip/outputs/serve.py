#!/usr/bin/env python3
"""Local adjustable real-mesh viewer; python serve.py --port 8773."""
import argparse,json,sys,os
from pathlib import Path
from http.server import HTTPServer,SimpleHTTPRequestHandler
ROOT=Path('/workspace/work/pattern-agent');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/human_fit/pose_guided'))
from runtime import Runtime
rt=Runtime()
class Handler(SimpleHTTPRequestHandler):
 def do_POST(self):
  if self.path!='/api/update':self.send_error(404);return
  try:
   s=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
   s['dimensions']={k:round(float(v),1) for k,v in s['dimensions'].items()}
   s['poseDegrees']={k:[round(float(v),1) for v in a] for k,a in s['poseDegrees'].items()}
   camera=json.loads((OUT/'views/camera.json').read_text());saved=rt.save(s,camera,OUT/'interactive')
   out=json.dumps(saved).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(out)
  except Exception as e:self.send_response(400);self.end_headers();self.wfile.write(str(e).encode())
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8773);a=p.parse_args();os.chdir(OUT)
 try:HTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
 finally:rt.close()
