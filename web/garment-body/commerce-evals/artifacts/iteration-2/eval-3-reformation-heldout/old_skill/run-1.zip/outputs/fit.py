#!/usr/bin/env python3
"""Independent single-photo bounded fit from shared neutral state, not person measurement."""
import sys,json,copy,time,hashlib,shutil,importlib.util,csv
from pathlib import Path
import numpy as np,cv2
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
ROOT=Path('/workspace/work/pattern-agent'); OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/human_fit/pose_guided'))
from runtime import Runtime,sha
import render_mesh
def dump(name,data): (OUT/name).write_text(json.dumps(data,indent=2)+'\n')
start=time.monotonic();rt=Runtime()
src=ROOT/'work/commerce-skill-evals-20261118/inputs/holdout-c-reformation'
shutil.copy(src/'original.jpg',OUT/'original.jpg');shutil.copy(src/'source.json',OUT/'source.json')
photo=cv2.imread(str(src/'original.jpg'));H,W=photo.shape[:2]
gen=cv2.imread(str(OUT/'images/pose.png'))
orb=cv2.ORB_create(nfeatures=6000);a,da=orb.detectAndCompute(photo,None);b,db=orb.detectAndCompute(gen,None)
matches=cv2.BFMatcher(cv2.NORM_HAMMING).knnMatch(db,da,k=2);good=[m for m,n in matches if m.distance<.73*n.distance]
gp=np.float32([b[m.queryIdx].pt for m in good]);op=np.float32([a[m.trainIdx].pt for m in good])
M,inl=cv2.estimateAffinePartial2D(gp,op,method=cv2.RANSAC,ransacReprojThreshold=4)
if M is None:raise RuntimeError('guide registration failed')
err=np.linalg.norm(gp@M[:,:2].T+M[:,2]-op,axis=1)
dump('guide-registration.json',{'generated_to_original_affine_2x3':M.tolist(),'matches':len(good),'inliers':int(inl.sum()),'inlier_mean_error_px':float(err[inl.ravel()>0].mean()),'source_sha256':sha(src/'original.jpg'),'guide_sha256':sha(OUT/'images/pose.png'),'native_size':[gen.shape[1],gen.shape[0]],'method':'ORB + RANSAC similarity; illustrative guide, anatomy manually checked'})
# Generated markers digitised at native resolution. Hidden pelvis/knees excluded.
marks={'upperarm01.R':[392,330],'upperarm01.L':[615,321],'lowerarm01.R':[389,531],'lowerarm01.L':[642,523],'wrist.R':[355,702],'wrist.L':[663,694],'neck01':[504,303],'foot.R':[498,1229],'foot.L':[620,1237]}
target={k:np.array(v)@M[:,:2].T+M[:,2] for k,v in marks.items()}
# Head of neck01 is neck base, not visible neckline; generation point approximates neck base.
dump('guide-points.json',{'points':[{'bone':k,'native_pixel':marks[k],'original_pixel':v.tolist(),'basis':'illustrative manually checked','weight':.5 if k.startswith('foot') else 1.0} for k,v in target.items()],'hidden_joints_used':False,'hidden_depth':'prior; unobservable'})
gcmask=np.zeros((H,W),np.uint8);bg=np.zeros((1,65));fg=np.zeros((1,65));cv2.grabCut(photo,gcmask,(180,55,370,958),bg,fg,5,cv2.GC_INIT_WITH_RECT)
ref=np.uint8((gcmask==1)|(gcmask==3))*255
# Exclude pale neutral studio background/shadow, retain skin and gingham dark checks.
hsv=cv2.cvtColor(photo,cv2.COLOR_BGR2HSV);gray=cv2.cvtColor(photo,cv2.COLOR_BGR2GRAY)
seed=np.uint8(((hsv[:,:,1]>18)|(gray<200))&(ref>0))*255
seed=cv2.morphologyEx(seed,cv2.MORPH_CLOSE,np.ones((11,11),np.uint8))
contours,_=cv2.findContours(seed,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
ref=np.zeros_like(ref);cv2.drawContours(ref,[max(contours,key=cv2.contourArea)],-1,255,-1)
cv2.imwrite(str(OUT/'reference-mask.png'),ref)
state=json.loads((ROOT/'work/commerce-skill-evals-20261118/fixtures/neutral-state.json').read_text())
state['limitations']=['M170 conditional generic prior, not observed person dimensions.']
initial=copy.deepcopy(state)
bones=['upperarm01.R','upperarm01.L','lowerarm01.R','lowerarm01.L','spine01','upperleg01.R','upperleg01.L']
# Pose uses complete 163-bone table. X/Y hidden rotations bounded/regularised.
camera0=np.array([5.15,375.,531.,0.,0.,0.])
def Rmat(c):return Rotation.from_euler('YXZ',c[3:],degrees=True).as_matrix()
def project(p,c):
 q=np.asarray(p)@Rmat(c).T;return np.column_stack([c[0]*q[:,0]+c[1],-c[0]*q[:,1]+c[2]+c[0]*85])
def parse(x,shape=False):
 s=copy.deepcopy(initial);c=x[:6];p=x[6:27].reshape(-1,3)
 for b,v in zip(bones,p):s['poseDegrees'][b]=v.tolist()
 if shape:
  for k,v in zip(['shoulders','upperArmLength','forearmLength'],x[27:]):s['dimensions'][k]=float(v)
 return s,c
def residual(x,shape=False):
 s,c=parse(x,shape);r=rt.evaluate(s,skin=False);uv=project(r['joints'],c);res=[]
 for k,v in target.items():res.extend((uv[rt.index[k]]-v)*(.5 if k.startswith('foot') else 1.))
 # Position of actual neutral top vertex constrains photo head top; hair is excluded.
 top=r['shape']['rest'][rt.ids];top=top[np.argmax(top[:,1])];res.extend((project([top],c)[0]-[366,76])*.6)
 res.extend(x[6:27]*.15)
 res.extend(c[3:]*.7)
 if shape:res.extend((x[27:]-[37,29,23])*2.)
 return np.array(res)
x0=np.r_[camera0,np.zeros(21)];lo=np.r_[[4.,330,470,-18,-8,-5],np.tile([-45,-50,-95],7)];hi=np.r_[[6.,430,580,18,8,5],np.tile([65,50,95],7)]
history=[]
# Block 1: source camera only.
opt=least_squares(lambda c:residual(np.r_[c,np.zeros(21)]),camera0,bounds=(lo[:6],hi[:6]),max_nfev=35,diff_step=.002)
x1=np.r_[opt.x,np.zeros(21)];history.append({'block':'camera','initial':x0.tolist(),'final':x1.tolist(),'cost':float(np.sum(residual(x1)**2)),'nfev':opt.nfev})
# Block 2: joint pose and bounded source camera.
opt=least_squares(residual,x1,bounds=(lo,hi),max_nfev=65,diff_step=.002,ftol=.002)
x2=opt.x;history.append({'block':'pose_camera','initial':x1.tolist(),'final':x2.tolist(),'cost':float(np.sum(residual(x2)**2)),'nfev':opt.nfev})
# Block 3: conditional supported lengths/shoulders, preserving M170 circumference priors.
x3=np.r_[x2,[37,29,23]];l3=np.r_[lo,[35,27,21]];h3=np.r_[hi,[39,32,26]]
opt=least_squares(lambda x:residual(x,True),x3,bounds=(l3,h3),max_nfev=28,diff_step=.002,ftol=.003)
final,camera=parse(opt.x,True);history.append({'block':'conditional_shape_pose_camera','initial':x3.tolist(),'final':opt.x.tolist(),'cost':float(np.sum(residual(opt.x,True)**2)),'nfev':opt.nfev})
final['poseDegrees']={k:[round(float(v),1) for v in vals] for k,vals in final['poseDegrees'].items()}
final['dimensions']={k:round(float(v),1) for k,v in final['dimensions'].items()}
dump('parameter-block-history.json',history)
def save_source(s,c,prefix):
 canonical=rt.canonical_state(s);r=rt.evaluate(canonical);R=Rmat(c);trans=r['posed']@R.T
 cam={'width':W,'height':H,'depth_range_cm':[-60,60],'views':{'photo':{'axis':'front','px_per_cm':float(c[0]),'center_cm':[(W/2-c[1])/c[0],85+(c[2]-H/2)/c[0]]}}}
 mask,im,dep,z=render_mesh.raster(trans,rt.faces,cam,'photo')
 # raster projection equals project(); world_to_pixel is on original cm world coordinates.
 P=np.zeros((3,4));P[0,:3]=c[0]*R[0];P[1,:3]=-c[0]*R[1];P[:,3]=[c[1],c[2]+85*c[0],1]
 cam.update({'world_to_pixel_homogeneous':P.tolist(),'projection':'oblique orthographic','final':c.tolist(),'coordinates':'Y up cm; u right, v down; pixel origin top left','rotation_matrix':R.tolist()})
 dump(prefix+'state.json',canonical);dump(prefix+'camera.json',cam)
 rt.write_obj(OUT/(prefix+'neutral.obj'),r['shape']['rest']);rt.write_obj(OUT/(prefix+'posed.obj'),r['posed'])
 cv2.imwrite(str(OUT/(prefix+'mask.png')),mask);cv2.imwrite(str(OUT/(prefix+'render.png')),im)
 return canonical,r,mask,im,z,cam
ini,ir,imask,iimg,iz,ic=save_source(initial,camera0,'initial-')
saved,r,mask,img,z,cam=save_source(final,camera,'final-')
shutil.copy(OUT/'final-state.json',OUT/'state.json');shutil.copy(OUT/'final-camera.json',OUT/'camera.json');shutil.copy(OUT/'final-neutral.obj',OUT/'neutral.obj');shutil.copy(OUT/'final-posed.obj',OUT/'posed.obj');shutil.copy(OUT/'final-render.png',OUT/'photo-render.png')
np.save(OUT/'rawdepth.npy',z.astype(np.float32));cv2.imwrite(str(OUT/'depth-valid.png'),np.isfinite(z).astype(np.uint8)*255)
valid=np.isfinite(z);dep=np.zeros((H,W),np.uint8);dep[valid]=1+np.clip((z[valid]+60)/120*253,0,253).astype(np.uint8);cv2.imwrite(str(OUT/'depth.png'),dep)
dump('depth-semantics.json',{'meaning':'rotated camera z coordinate; larger nearer, orthographic','units':'cm conditional avatar scale','range_cm':[-60,60],'background':'-Infinity raw, invalid mask zero','valid_pixels':int(valid.sum()),'finite_valid':bool(np.isfinite(z[valid]).all())})
dump('projected-pose.json',{'points':[{'name':n,'world_cm':r['joints'][i].tolist(),'pixel':project([r['joints'][i]],camera)[0].tolist(),'visibility':'not classified; hidden depth prior'} for i,n in enumerate(rt.names)]})
viewcam={'width':800,'height':1067,'depth_range_cm':[-80,80],'views':{v:{'axis':v,'px_per_cm':5.1,'center_cm':[0,85]} for v in ['front','side','back']}}
rt.save(saved,viewcam,OUT/'views')
def evidence(m,name):
 a=ref>0;b=m>0;over=photo.copy();over[a&b]=(over[a&b]*.5+[0,127,0]).astype(np.uint8);over[a&~b]=(over[a&~b]*.5+[127,0,127]).astype(np.uint8);over[b&~a]=(over[b&~a]*.5+[127,127,0]).astype(np.uint8)
 cv2.imwrite(str(OUT/(name+'overlay.png')),over)
 ca=cv2.Canny(ref,80,160)>0;cb=cv2.Canny(m,80,160)>0;da=cv2.distanceTransform(np.uint8(~ca),cv2.DIST_L2,5);db=cv2.distanceTransform(np.uint8(~cb),cv2.DIST_L2,5);dist=np.r_[da[cb],db[ca]]
 return {'iou':float((a&b).sum()/(a|b).sum()),'dice':float(2*(a&b).sum()/(a.sum()+b.sum())),'symmetric_contour_mean_px':float(dist.mean()),'symmetric_contour_p95_px':float(np.percentile(dist,95)),'limitation':'garment+hair+clutch vs bare avatar; not naked-body accuracy'}
metrics={'initial_camera_initial_state':evidence(imask,'initial-'),'final':evidence(mask,'final-')}
# Camera contribution separated: initial avatar rendered with final camera.
_,_,frozen,_,_,_=save_source(initial,camera,'initial-finalcamera-');metrics['initial_state_final_camera']=evidence(frozen,'initial-finalcamera-');dump('metrics.json',metrics)
measures=[]
for k,v in saved['measuredNeutral'].items():measures.append({'name':k,'value':v,'target':saved['dimensions'][k],'unit':'cm','basis':'mesh_parameter' if k in ['shoulders','upperArmLength','forearmLength'] else 'prior','mesh_checked':True,'definition':rt.data['measurementDefinition'],'limitations':['conditional M170 scale; single dressed image cannot measure real circumference']})
for k in ['underbust','bustPointDistance','shoulderSlope','frontWaistLength','backWaistLength','crotchArc']:measures.append({'name':k,'value':None,'basis':'unavailable','mesh_checked':False})
dump('measurements.json',{'measurements':measures,'source':'asset calibrated neutral surface tape/landmarks independently recomputed below','maximum_target_error_cm':saved['maximumTargetErrorCm']})
with (OUT/'measurements.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['name','value_cm','basis']);w.writerows([ [m['name'],m['value'],m['basis']] for m in measures])
dump('input-provenance.json',{'original':{'sha256':sha(src/'original.jpg'),'size':[W,H],'source':json.loads((src/'source.json').read_text())},'neutral_input_sha256':sha(ROOT/'work/commerce-skill-evals-20261118/fixtures/neutral-state.json'),'asset_sha256':sha(rt.asset),'runtime_sha256':sha(ROOT/'tools/human_fit/pose_guided/runtime.py'),'generated_guide':{'sha256':sha(OUT/'images/pose.png'),'native_size':[gen.shape[1],gen.shape[0]]},'six_images':'NOT_RUN; outside requested branch','mode':'prior_avatar','numerical_seconds':time.monotonic()-start,'tokens':None,'generation_seconds':None})
dump('geometry-check.json',{'vertices':len(rt.ids),'faces':len(rt.faces),'bones':len(saved['poseDegrees']),'finite_posed':bool(np.isfinite(r['posed']).all()),'finite_neutral':bool(np.isfinite(r['shape']['rest']).all()),'same_views_state_dimensions':json.loads((OUT/'views/state.json').read_text())['dimensions']==saved['dimensions'],'same_views_complete_pose':json.loads((OUT/'views/state.json').read_text())['poseDegrees']==saved['poseDegrees'],'severe_skin_overlap':'NOT_RUN; no independent collision test, linear blend skinning only'})
rt.close()
print(json.dumps({'elapsed_seconds':time.monotonic()-start,'final_camera':camera.tolist(),'metrics':metrics,'bones':len(saved['poseDegrees'])}))
