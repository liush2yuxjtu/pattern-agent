#!/usr/bin/env python3
"""Artifact reproducibility checks only; no photo fit grade."""
from pathlib import Path
import json,sys,importlib.util
import numpy as np,cv2
ROOT=Path('/workspace/work/pattern-agent');O=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/human_fit/pose_guided'))
from runtime import Runtime
from render_mesh import obj,raster
r=Runtime();state=json.loads((O/'final-state.json').read_text());g=r.evaluate(state);v,f=obj(O/'posed.obj');n,_=obj(O/'neutral.obj');cam=json.loads((O/'camera.json').read_text());P=np.array(cam['world_to_pixel_homogeneous']);uv=np.c_[v,np.ones(len(v))]@P.T;R=np.array(cam['rotation_matrix']);mask,im,dep,z=raster(v@R.T,f,cam,'photo');saved=cv2.imread(str(O/'final-mask.png'),0)
views=json.loads((O/'views/state.json').read_text());rows={'posed_vertex_reconstruction_max_cm':float(np.max(np.abs(v-g['posed'][r.ids]))),'neutral_vertex_reconstruction_max_cm':float(np.max(np.abs(n-g['shape']['rest'][r.ids]))),'source_camera_replay_mask_different_pixels':int(np.count_nonzero(mask!=saved)),'same_view_dimensions':views['dimensions']==state['dimensions'],'same_view_pose':views['poseDegrees']==state['poseDegrees'],'pose_bones':len(state['poseDegrees']),'world_to_pixel_shape':list(P.shape),'actual_source_size':[cam['width'],cam['height']],'source_sha256':__import__('hashlib').sha256((O/'original.jpg').read_bytes()).hexdigest(),'limits':'Checks exact saved-state/OBJ/camera replay only; no benchmark or photo fit judgment.'}
(O/'artifact-replay-check.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows));r.close()
