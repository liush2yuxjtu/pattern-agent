import sys,json,hashlib,platform
from pathlib import Path
import numpy as np,cv2
from scipy.spatial import cKDTree
ROOT=Path('/workspace/work/pattern-agent');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'tools/human_fit/pose_guided'))
from runtime import Runtime,sha
from render_mesh import obj
r=Runtime();s=json.loads((OUT/'final-state.json').read_text());ev=r.evaluate(s);v,f=obj(OUT/'posed.obj');nv,nf=obj(OUT/'neutral.obj');vs=json.loads((OUT/'views/state.json').read_text());z=np.load(OUT/'rawdepth.npy');cam=json.loads((OUT/'camera.json').read_text());P=np.array(cam['world_to_pixel_homogeneous']);j=json.loads((OUT/'projected-pose.json').read_text());q=np.c_[ev['joints'],np.ones(163)]@P.T
edges=np.sort(np.concatenate([f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]]),axis=1);ue,c=np.unique(edges,axis=0,return_counts=True)
out={'pose_bones':len(s['poseDegrees']),'vertices':len(v),'triangles':len(f),'finite_vertices':bool(np.isfinite(v).all()),'boundary_edges':int((c==1).sum()),'nonmanifold_edges':int((c>2).sum()),'posed_OBJ_replay_max_cm':float(abs(v-ev['posed'][r.ids]).max()),'neutral_OBJ_replay_max_cm':float(abs(nv-ev['shape']['rest'][r.ids]).max()),'same_views_dimensions':s['dimensions']==vs['dimensions'],'same_views_complete_pose':s['poseDegrees']==vs['poseDegrees'],'matrix_projection_max_px':float(abs(q[:,:2]-np.array([x['pixel'] for x in j['joints']])).max()),'raw_depth_valid_count':int(np.isfinite(z).sum()),'raw_depth_finite_range_cm':[float(z[np.isfinite(z)].min()),float(z[np.isfinite(z)].max())],'python':platform.python_version(),'opencv':cv2.__version__,'numpy':np.__version__,'limits':'Replay consistency and mesh topology only; no original-photo acceptance or full collision test.'}
# Hand-to-torso vertex proximity is coverage-limited, not a triangle penetration test.
weights=r.weight;skin=r.skin;torso_names=['spine01','spine02','spine03','spine04','spine05','pelvis.L','pelvis.R','root'];torso=np.isin(skin,[r.index[n] for n in torso_names]);torso=(weights*torso).sum(1)>.6;tree=cKDTree(ev['posed'][torso]);out['hand_surface_proximity']={}
for side in ['L','R']:
 ids=[i for i,n in enumerate(r.names) if n.endswith('.'+side) and ('finger' in n or 'wrist' in n or 'metacarpal' in n)];sel=(weights*np.isin(skin,ids)).sum(1)>.6;d,_=tree.query(ev['posed'][sel]);out['hand_surface_proximity'][side]={'vertices':int(sel.sum()),'minimum_vertex_distance_cm':float(d.min()),'median_cm':float(np.median(d)),'penetration':'UNKNOWN; nearest vertex does not detect intersections'}
(OUT/'evidence/replay-audit.json').write_text(json.dumps(out,indent=2));r.close()
files={str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file() and p.name!='artifact-hashes.json'};(OUT/'artifact-hashes.json').write_text(json.dumps(files,indent=2))
print(json.dumps(out))
