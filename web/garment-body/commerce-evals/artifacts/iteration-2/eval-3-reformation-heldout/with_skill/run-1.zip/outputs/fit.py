import sys,json,copy,time,hashlib,shutil
from pathlib import Path
import numpy as np,cv2
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
ROOT=Path('/workspace/work/pattern-agent');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'tools/human_fit/pose_guided'))
from runtime import Runtime,sha
from render_mesh import raster
W,H=800,1067
def write(p,x): (OUT/p).write_text(json.dumps(x,indent=2)+'\n')
r=Runtime();neutral=json.loads((ROOT/'work/commerce-skill-evals-20261118/fixtures/neutral-state.json').read_text())
photo=cv2.imread(str(OUT/'reference/original.jpg'))
# Manually observed on the original photograph, prior to fitting. Internal centers approximate.
obs={'neck01':([368,218],1.4),'upperarm01.R':([291,245],1),'lowerarm01.R':([286,398],1),'wrist.R':([263,540],1.5),'upperarm01.L':([455,241],1),'lowerarm01.L':([475,395],1),'wrist.L':([486,521],1.2),'foot.R':([365,930],.55),'foot.L':([450,925],.55),'upperleg01.R':([339,480],.12),'upperleg01.L':([408,480],.12)}
write('observations.json',{'source_sha256':sha(OUT/'reference/original.jpg'),'points':{n:{'pixel':p,'weight':w,'basis':'hidden coarse prior' if 'upperleg' in n else 'manual original anatomical approximation','uncertainty_px':35 if 'upperleg' in n else 8} for n,(p,w) in obs.items()},'visible_wrists':{'image_left':[263,540],'image_right':[486,521]},'hidden_knees':'not used','regions':{'shoulders':[265,210,480,300],'arms':[242,245,502,595],'torso':[298,275,451,407],'waist_hip':[277,390,475,540]},'center_scanlines_y':[285,325,365,400,450,500]})
names=list(obs);ids=[r.index[n] for n in names];targets=np.array([obs[n][0] for n in names]);weights=np.array([obs[n][1] for n in names])
mapping=[(b,a) for b in ['upperarm01.R','lowerarm01.R','upperarm01.L','lowerarm01.L'] for a in range(3)]+[('upperleg01.R',2),('upperleg01.L',2)]
def rot(c):return Rotation.from_euler('YXZ',c[3:],degrees=True).as_matrix()
def proj(v,c):q=v@rot(c).T;return np.column_stack((q[:,0]*c[0]+c[1],-q[:,1]*c[0]+c[2]))
def unpack(x,base):
 s=copy.deepcopy(base)
 for (b,a),v in zip(mapping,x[6:]):s['poseDegrees'][b][a]=float(v)
 return s,x[:6]
history=[]
def residual(x,base,regular=1):
 s,c=unpack(x,base);ev=r.evaluate(s,skin=False);j=ev['joints'];p=proj(j[ids],c)
 out=list(((p-targets)*weights[:,None]).ravel()/8)
 # Upright standing body: fixed spine/root, conservative camera, mild leg asymmetry.
 out+=list(x[6:]*.008*regular);out +=[c[4]/7,c[5]/4]
 for side in ['L','R']:
  sh=j[r.index['upperarm01.'+side]];el=j[r.index['lowerarm01.'+side]];wr=j[r.index['wrist.'+side]]
  out +=[max(0,el[2]-sh[2]-8)/4,max(0,sh[2]-el[2]-6)/4,max(0,el[1]-sh[1]+10)/4,max(0,wr[1]-el[1]+8)/4,max(0,abs(wr[2]-sh[2])-16)/4]
 return np.array(out)
initial_camera=np.array([5.2,371,958,0,0,0.])
write('initial-state.json',r.canonical_state(neutral));write('initial-camera.json',{'final':initial_camera.tolist(),'width':W,'height':H})
best=None;start=time.monotonic()
for k,yaw in enumerate([0,12]):
 x=np.r_[initial_camera,np.zeros(len(mapping))];x[3]=yaw
 lo=np.r_[[4.5,330,920,-22,-5,-5],np.full(12,-65),[-12,-12]];hi=np.r_[[5.8,420,1020,22,5,5],np.full(12,65),[12,12]]
 fit=least_squares(residual,x,args=(neutral,),bounds=(lo,hi),max_nfev=110,ftol=.0003,xtol=.0003)
 s,c=unpack(fit.x,neutral);cost=float(np.sum(residual(fit.x,neutral)**2));history.append({'block':k+1,'name':'front vs oblique camera and upper-limb pose','initial':x.tolist(),'final':fit.x.tolist(),'cost':cost,'nfev':fit.nfev,'mapping':[['camera',n] for n in ['scale','centerX','centerY','yaw','pitch','roll']]+mapping})
 write('candidate-%d-state.json'%k,r.canonical_state(s));write('candidate-%d-camera.json'%k,{'final':c.tolist()})
 if best is None or cost<best[0]:best=(cost,s,c)
cost,state,camera=best
# Conditional upper-limb length block: bounded weak prior, reoptimizing actual shape/FK.
xx=np.r_[camera,[state['poseDegrees'][b][a] for b,a in mapping],29.,23.]
def dimres(x):
 s=copy.deepcopy(state);s['dimensions']['upperArmLength']=float(x[-2]);s['dimensions']['forearmLength']=float(x[-1]);return np.r_[residual(x[:-2],s), (x[-2:]-[29,23])/.9]
fit=least_squares(dimres,xx,bounds=(np.r_[lo,[27,21]],np.r_[hi,[31,25]]),max_nfev=28,ftol=.001,xtol=.001,diff_step=.001)
state['dimensions']['upperArmLength']=float(fit.x[-2]);state['dimensions']['forearmLength']=float(fit.x[-1]);state,camera=unpack(fit.x[:-2],state)
history.append({'block':3,'name':'conditional arm lengths and pose/camera','initial':xx.tolist(),'final':fit.x.tolist(),'cost':float(np.sum(dimres(fit.x)**2)),'nfev':fit.nfev})
# Visible free hand relaxed; clutch hand slightly curled. Finger/hand depth remains a hypothesis.
for side in ['L','R']:
 for digit in range(2,6):
  for seg in range(1,4):state['poseDegrees'][f'finger{digit}-{seg}.{side}']=[12. if side=='L' else 5.,0.,0.]
state['dimensions']={k:round(v,1) for k,v in state['dimensions'].items()};state['poseDegrees']={k:[round(x,1) for x in v] for k,v in state['poseDegrees'].items()}
state=r.canonical_state(state);state['limitations']=['Generic M170 prior; not measured person dimensions.','Single original image; hidden hips/knees/hand depth uncertain.','Two visible wrist centers manually approximated; clutch partly occludes image-right hand.']
write('parameter-block-history.json',{'blocks':history,'numerical_seconds':time.monotonic()-start,'budget_seconds':600,'dimension_quantization_cm':.1,'pose_quantization_deg':.1})
write('final-state.json',state)
ev=r.evaluate(state);r.write_obj(OUT/'neutral.obj',ev['shape']['rest']);r.write_obj(OUT/'posed.obj',ev['posed'])
R=rot(camera);P=np.vstack((np.r_[camera[0]*R[0],camera[1]],np.r_[-camera[0]*R[1],camera[2]],[0,0,0,1]))
cam={'width':W,'height':H,'projection':'oblique orthographic','units':'cm','final':camera.tolist(),'world_to_pixel_homogeneous':P.tolist(),'depth_semantics':'rotated world Z in cm, larger nearer; background -inf','depth_range_cm':[-100,100],'views':{'source':{'axis':'front','px_per_cm':float(camera[0]),'center_cm':[(W/2-camera[1])/camera[0],(camera[2]-H/2)/camera[0]]}}};write('camera.json',cam)
def render_source(s,c,prefix):
 e=r.evaluate(s);M=rot(c);tmp={'width':W,'height':H,'depth_range_cm':[-100,100],'views':{'source':{'axis':'front','px_per_cm':float(c[0]),'center_cm':[(W/2-c[1])/c[0],(c[2]-H/2)/c[0]]}}}
 m,im,dep,z=raster(e['posed']@M.T,r.faces,tmp,'source');cv2.imwrite(str(OUT/(prefix+'mask.png')),m);cv2.imwrite(str(OUT/(prefix+'render.png')),im)
 return e,m,dep,z
_,imask,_,_=render_source(neutral,initial_camera,'initial-');_,ifrozen,_,_=render_source(neutral,camera,'initial-frozen-camera-');ev,m,dep,z=render_source(state,camera,'final-');shutil.copy(OUT/'final-render.png',OUT/'photo-render.png');np.save(OUT/'rawdepth.npy',z.astype('float32'));cv2.imwrite(str(OUT/'depth-valid.png'),np.isfinite(z).astype('uint8')*255);cv2.imwrite(str(OUT/'depth.png'),dep)
write('projected-pose.json',{'joints':[{'name':n,'world_cm':ev['joints'][i].tolist(),'pixel':proj(ev['joints'][i:i+1],camera)[0].tolist(),'in_frame':bool(np.all(proj(ev['joints'][i:i+1],camera)[0]>=0) and np.all(proj(ev['joints'][i:i+1],camera)[0]<[W,H])),'occlusion':'unclassified'} for i,n in enumerate(r.names)],'edges':[[b['parent'],b['name']] for b in r.bones if b['parent']]})
viewcam={'width':600,'height':900,'depth_range_cm':[-100,100],'views':{n:{'axis':n,'px_per_cm':4.7,'center_cm':[0,85]} for n in ['front','side','back']}}
r.save(state,viewcam,OUT/'views')
# Source segmentation at original resolution. GrabCut uses the pale background and foreground seeds.
outline=np.zeros((H,W),np.uint8)
polys=[[[357,67],[385,70],[410,93],[427,144],[440,212],[461,220],[475,242],[483,337],[489,393],[500,515],[498,554],[476,573],[474,622],[506,790],[476,799],[440,806],[340,806],[290,801],[249,790],[201,757],[224,679],[248,604],[251,585],[247,561],[254,514],[265,442],[274,395],[273,345],[269,281],[270,247],[286,225],[303,218],[303,167],[317,110],[336,80]],[[329,799],[371,802],[371,883],[379,944],[389,973],[377,990],[355,992],[342,979],[343,949],[352,923],[342,869]],[[439,799],[481,792],[477,855],[466,904],[476,932],[535,984],[535,995],[504,995],[450,974],[429,952],[431,924]]]
for poly in polys:cv2.fillPoly(outline,[np.array(poly,np.int32)],255)
kernel=np.ones((9,9),np.uint8);gm=np.where(cv2.dilate(outline,kernel)>0,cv2.GC_PR_BGD,cv2.GC_BGD).astype('uint8');gm[outline>0]=cv2.GC_PR_FGD;gm[cv2.erode(outline,kernel)>0]=cv2.GC_FGD
bg=np.zeros((1,65));fg=np.zeros((1,65));cv2.grabCut(photo,gm,None,bg,fg,3,cv2.GC_INIT_WITH_MASK);ref=((gm==1)|(gm==3)).astype('uint8')*255;cv2.imwrite(str(OUT/'reference-mask.png'),ref)
write('reference-segmentation.json',{'method':'manual original-photo polygon seeds + OpenCV GrabCut, 3 iterations','polygons':polys,'resolution':[W,H],'limitations':'manual silhouette seeds, shoes and hair included; garment not naked body'})
def metrics(mask):
 a=ref>0;b=mask>0;ca=cv2.Canny(ref,50,150)>0;cb=cv2.Canny(mask,50,150)>0;da=cv2.distanceTransform((~ca).astype('uint8'),cv2.DIST_L2,5);db=cv2.distanceTransform((~cb).astype('uint8'),cv2.DIST_L2,5);ds=np.r_[da[cb],db[ca]]
 return {'IoU':float((a&b).sum()/(a|b).sum()),'Dice':float(2*(a&b).sum()/(a.sum()+b.sum())),'symmetric_contour_mean_px':float(ds.mean()),'symmetric_contour_P95_px':float(np.percentile(ds,95)),'interpretation':'clothed silhouette comparison, not naked body accuracy'}
for name,mask in [('initial',imask),('initial-frozen-camera',ifrozen),('final',m)]:
 a=ref>0;b=mask>0;over=photo.copy();color=photo.copy();color[a&b]=[70,210,70];color[a&~b]=[200,70,220];color[b&~a]=[220,210,30];over=cv2.addWeighted(over,.55,color,.45,0);cv2.imwrite(str(OUT/(name+'-overlay.png')),over)
write('fit-metrics.json',{'initial':metrics(imask),'initial_frozen_final_camera':metrics(ifrozen),'final':metrics(m),'reference_sha256':sha(OUT/'reference/original.jpg'),'reference_mask_sha256':sha(OUT/'reference-mask.png'),'no_pass_claim':True})
write('measurements.json',{'units':'cm','mesh_sha256':sha(OUT/'neutral.obj'),'items':[{'name':k,'target':v,'value':state['measuredNeutral'][k],'definition':r.data['measurementDefinition'],'basis':'prior' if k not in ['upperArmLength','forearmLength'] else 'mesh_parameter','mesh_checked':True,'limitation':'M170 assumed scale; not actual person measurement; bounded conditional fit' if 'Length' in k else 'M170 prior under clothing'} for k,v in state['dimensions'].items()]+[{'name':k,'value':None,'basis':'unavailable','mesh_checked':False} for k in ['underbust','bust_point_distance','front_waist_length','back_waist_length','crotch_arc','shoulder_slope']]})
(OUT/'measurements.csv').write_text('name,target_cm,neutral_mesh_cm,basis\n'+'\n'.join(f'{k},{v},{state["measuredNeutral"][k]},prior' for k,v in state['dimensions'].items())+'\n')
write('bone-lengths.json',{'units':'cm','lengths':{b['name']:float(np.linalg.norm(ev['shape']['rest'][r.data['joints'][b['tail']]].mean(0)-ev['shape']['heads'][i])) for i,b in enumerate(r.bones)}})
write('input-provenance.json',{'source':json.loads((OUT/'reference/source.json').read_text()),'original_sha256':sha(OUT/'reference/original.jpg'),'prior_sha256':sha(ROOT/'work/commerce-skill-evals-20261118/fixtures/neutral-state.json'),'asset_sha256':sha(r.asset),'runtime_sha256':sha(ROOT/'tools/human_fit/pose_guided/runtime.py'),'fit_source_sha256':sha(OUT/'fit.py'),'generation_input_sha256':sha(OUT/'reference/original.jpg'),'generation_native_sha256':sha(OUT/'images/pose.png'),'timing_seconds':None,'tokens':None})
r.close();print(json.dumps({'camera':camera.tolist(),'cost':cost,'numerical_seconds':time.monotonic()-start,'dims':state['dimensions'],'pose':{k:v for k,v in state['poseDegrees'].items() if any(v)}}))
