import json,hashlib,sys,shutil,csv
from pathlib import Path
import numpy as np
from PIL import Image
P=Path(__file__).parent;R=Path('/workspace/work/pattern-agent')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(n,x):(P/n).write_text(json.dumps(x,indent=2)+'\n')
s=json.loads((P/'final-state.json').read_text());a=json.loads((R/'web/human-studio/assets/human.json').read_text());v=np.asarray(a['vertices'],float).reshape(-1,3)
for c,w in zip(a['controls'],s['morphWeights']):
 for index,x,y,z in c['incr' if w>=0 else 'decr']:v[index]+=abs(w)*np.array([x,y,z])
ids=a['bodyVertexIds'];v[:,1]-=v[ids,1].min();measures={'height':float(np.ptp(v[ids,1]))}
for c in a['controls'][1:]:measures[c['key']]=sum(float(np.linalg.norm(v[i]-v[j])) for i,j in zip(c['path'],c['path'][1:]))
ov=np.array([[float(x) for x in l.split()[1:]] for l in (P/'neutral.obj').read_text().splitlines() if l.startswith('v ')])
write('independent-neutral-reconstruction.json',dict(method='independent direct asset morph accumulation; tape path sums; OBJ vertex comparison',asset_sha256=sha(R/'web/human-studio/assets/human.json'),neutral_sha256=sha(P/'neutral.obj'),measured=measures,maximum_saved_measurement_difference_cm=max(abs(measures[k]-s['measuredNeutral'][k]) for k in measures),maximum_obj_coordinate_difference_cm=float(np.max(abs(v[ids]-ov))),full_pose_count=len(s['poseDegrees']),pose_step_limitation='Continuous optimized joint angles do not satisfy the old inspector 0.1 degree UI step. Runtime replay preserves exact floats; browser import snapping was not tested.'))
for n in ['front','side','back','pose','depth']:
 shutil.copy2(P/'views'/f'{n}.png',P/'generation-inputs'/f'{n}.png')
shutil.copy2(P/'reference/original.png',P/'generation-inputs/original.png')
shutil.copy2(P/'photo-render.png',P/'generation-inputs/photo-render.png')
for path in (P/'receipts').glob('*.json'):
 rec=json.loads(path.read_text());n=path.stem;im=P/'reference/pose-guide.png' if n=='pose-guide' else P/'images'/f'{n}.png';rec['native_size']=list(Image.open(im).size);rec['native_sha256']=sha(im);rec['input_hashes']={f:sha(f) for f in rec['arguments']['referenced_image_paths']};write(str(path.relative_to(P)),rec)
h=json.loads((P/'parameter-block-history.json').read_text());h['blocks'].sort(key=lambda x:x['block']);write('parameter-block-history.json',h)
z=np.load(P/'views/rawdepth.npy');valid=np.isfinite(z);write('geometric-depth-description.json',dict(path='views/rawdepth.npy',validity='views/depth-valid.png',finite_pixels=int(valid.sum()),valid_min_cm=float(z[valid].min()),valid_max_cm=float(z[valid].max()),semantics='canonical front Z coordinate in cm; maximum Z nearest; background negative infinity masked invalid; grayscale geometry PNG normalizes fixed [-60,60] cm',pose='views/view-provenance.json',generated_depth='images/depth.png is independent illustrative grayscale photo, not calibrated depth'))
with (P/'measurements.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['name','value_cm','basis','definition'])
 for k,val in measures.items():w.writerow([k,val,'conditional mesh parameter, M170 prior',a['measurementDefinition']])
write('run.json',dict(mode='prior_avatar',configuration='old_skill',timing=None,tokens=None,numerical_elapsed_seconds=h['numerical_elapsed_seconds'],generation_count=7,official_model_height_cm=None,prior_height_cm=170,scale_basis='authorized generic M170; not observed person',scores=None))
write('artifact-hashes.json',{str(f.relative_to(P)):sha(f) for f in P.rglob('*') if f.is_file() and f.name!='artifact-hashes.json'})
