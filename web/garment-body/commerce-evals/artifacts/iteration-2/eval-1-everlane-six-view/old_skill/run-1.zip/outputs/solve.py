import sys,json,copy,hashlib,time,importlib.util
from pathlib import Path
import numpy as np,cv2
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
ROOT=Path('/workspace/work/pattern-agent');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'tools/human_fit/pose_guided'))
from runtime import Runtime,sha
import render_mesh
def write(n,x): (OUT/n).write_text(json.dumps(x,indent=2)+'\n')
r=Runtime();base=json.load(open(ROOT/'work/commerce-skill-evals-20261118/fixtures/neutral-state.json'))
photo=cv2.imread(str(OUT/'reference/original.jpg'));H,W=photo.shape[:2]
# Register generated overlay back onto unchanged source, retaining raw correspondences.
guide=cv2.imread(str(OUT/'reference/pose-guide.png'));sift=cv2.SIFT_create();a,da=sift.detectAndCompute(cv2.cvtColor(guide,cv2.COLOR_BGR2GRAY),None);b,db=sift.detectAndCompute(cv2.cvtColor(photo,cv2.COLOR_BGR2GRAY),None)
matches=cv2.BFMatcher().knnMatch(da,db,k=2);good=[m for m,n in matches if m.distance<.7*n.distance];src=np.float32([a[m.queryIdx].pt for m in good]);dst=np.float32([b[m.trainIdx].pt for m in good]);M,inside=cv2.findHomography(src,dst,cv2.RANSAC,7)
err=np.linalg.norm(cv2.perspectiveTransform(src[:,None],M)[:,0]-dst,axis=1)
write('reference/registration.json',dict(method='SIFT ratio .7, RANSAC homography 7px',matrix=M.tolist(),source_points=src.tolist(),original_points=dst.tolist(),inliers=inside.ravel().tolist(),inlier_mean_px=float(err[inside.ravel()>0].mean()),warning='Generated shoulder points sit on garment edge; hips at waistband are not anatomical hip centres. Corrected manually against source below.'))
# Source image visual annotation, not detector ground truth. Occluded hips get weak weights.
names=['upperarm01.R','lowerarm01.R','wrist.R','upperarm01.L','lowerarm01.L','wrist.L','neck01','head','root']
target=np.array([[790,1020],[680,1780],[650,2470],[1590,1030],[1685,1790],[1730,2450],[1200,920],[1200,690],[1200,2380]],float)
weights=np.array([1,1,1,1,1,1,.35,.2,.18]);write('reference/landmarks.json',dict(names=names,pixels=target.tolist(),weights=weights.tolist(),basis='manually interpreted source and registered illustrative guide; hip/root/head centers inferred; not detector truth'))
small=cv2.resize(photo,(600,750));mask=np.full((750,600),cv2.GC_PR_BGD,np.uint8);mask[15:750,140:460]=cv2.GC_PR_FGD;mask[:10]=cv2.GC_BGD;mask[:,:70]=cv2.GC_BGD;mask[:,530:]=cv2.GC_BGD
cv2.grabCut(small,mask,None,np.zeros((1,65)),np.zeros((1,65)),6,cv2.GC_INIT_WITH_MASK);ref=cv2.resize(np.uint8((mask==1)|(mask==3))*255,(W,H),interpolation=cv2.INTER_NEAREST);cv2.imwrite(str(OUT/'reference-mask.png'),ref)
bones=['upperarm01.R','lowerarm01.R','wrist.R','upperarm01.L','lowerarm01.L','wrist.L','spine02','head']
# Camera scale, world center, yaw/pitch/roll, then local XYZ pose blocks.
x0=np.r_[28.,0.,118.,0.,0.,0.,np.zeros(24)]
lo=np.r_[20,-15,105,-18,-12,-9,np.tile([-65,-65,-80],8)];hi=np.r_[36,15,135,18,12,9,np.tile([65,65,80],8)]
def state(x,dimensions=None):
 s=copy.deepcopy(base)
 if dimensions:s['dimensions'].update(dimensions)
 for i,n in enumerate(bones):s['poseDegrees'][n]=list(x[6+3*i:9+3*i])
 return s
def rotation(x):return Rotation.from_euler('YXZ',[x[3],x[4],x[5]],degrees=True).as_matrix()
def project(p,x):
 p=p@rotation(x).T
 return np.c_[(p[:,0]-x[1])*x[0]+W/2,H/2-(p[:,1]-x[2])*x[0]]
def loss(x,dimensions=None):
 e=r.evaluate(state(x,dimensions),skin=False);p=e['joints'][[r.index[n] for n in names]];d=((project(p,x)-target)*weights[:,None]/35).ravel()
 # conservative small local rotations regularize invisible DOF; no invented hand gesture.
 return np.r_[d,x[6:]*.009,x[3:6]*.015]
t=time.monotonic();history=[]
sol=least_squares(loss,x0,bounds=(lo,hi),max_nfev=75,diff_step=.005);x=sol.x
history.append(dict(block='1 camera and full-arm FK',initial=x0.tolist(),final=x.tolist(),cost=float(sol.cost),nfev=sol.nfev))
keys=['shoulders','upperArmLength','forearmLength'];d0=np.array([base['dimensions'][k] for k in keys]);z0=np.r_[x,d0]
def loss2(z):return np.r_[loss(z[:30],dict(zip(keys,z[30:]))),(z[30:]-d0)/2]
sol2=least_squares(loss2,z0,bounds=(np.r_[lo,d0-[2,2,2]],np.r_[hi,d0+[2,2,2]]),max_nfev=32,diff_step=.003);x=sol2.x[:30];dims=dict(zip(keys,sol2.x[30:]));
def loss3(q):
 ev=r.evaluate(state(q,dims),skin=False);j=ev['joints'];depth=[]
 for side in ['R','L']:
  sh=j[r.index['upperarm01.'+side]];el=j[r.index['lowerarm01.'+side]];wr=j[r.index['wrist.'+side]]
  depth += [(el[2]-sh[2])/4,(wr[2]-sh[2]-2)/4]
 return np.r_[loss(q,dims),q[3:5]/3,q[24:27]/3,depth]
sol3=least_squares(loss3,x,bounds=(lo,hi),max_nfev=45,diff_step=.003)
history.append(dict(block='3 camera tilt, spine and limb-depth regularization',initial=x.tolist(),final=sol3.x.tolist(),cost=float(sol3.cost),nfev=sol3.nfev,depth_basis='weak anatomical prior, not observed depth'))
x=sol3.x;final=r.canonical_state(state(x,dims));final['limitations']=['Generic M170 conditional avatar; not real-person measurements. Single observed clothed view; side/back anatomy and all unseen legs are prior.']
history.append(dict(block='2 conditional cm shape and pose/camera refinement',dimension_keys=keys,initial=z0.tolist(),final=sol2.x.tolist(),cost=float(sol2.cost),nfev=sol2.nfev));write('parameter-block-history.json',dict(blocks=history,numerical_elapsed_seconds=time.monotonic()-t))
write('initial-state.json',base);write('final-state.json',final)
e=r.evaluate(final);r.write_obj(OUT/'neutral.obj',e['shape']['rest']);r.write_obj(OUT/'posed.obj',e['posed'])
def camera(x):
 rot=rotation(x);P=np.zeros((3,4));P[0,:3]=x[0]*rot[0];P[1,:3]=-x[0]*rot[1];P[0,3]=W/2-x[0]*x[1];P[1,3]=H/2+x[0]*x[2];P[2,3]=1
 return dict(width=W,height=H,source_width=W,source_height=H,type='oblique orthographic',final=x[:6].tolist(),world_to_pixel_homogeneous=P.tolist(),axes='Y up cm; camera sees maximum rotated Z',depth_semantics='rotated Z cm; larger nearer',depth_range_cm=[-50,50],views={'photo':dict(axis='front',px_per_cm=float(x[0]),center_cm=x[1:3].tolist())})
write('camera.json',camera(x));write('initial-camera.json',camera(x0))
def render(s,c,label):
 ev=r.evaluate(s);v=ev['posed']@rotation(c).T;ca=camera(c);m,im,dep,z=render_mesh.raster(v,r.faces,ca,'photo');cv2.imwrite(str(OUT/(label+'-render.png')),im);cv2.imwrite(str(OUT/(label+'-mask.png')),m)
 if label=='photo':np.save(OUT/'source-rawdepth.npy',z.astype('float32'));cv2.imwrite(str(OUT/'source-depth-valid.png'),np.uint8(np.isfinite(z))*255)
 overlap=(ref>0)&(m>0);re=(ref>0)&(m==0);mo=(ref==0)&(m>0);colors=photo.copy();colors[overlap]=[80,210,80];colors[re]=[170,60,240];colors[mo]=[240,220,40];cv2.imwrite(str(OUT/(label+'-overlay.png')),cv2.addWeighted(photo,.6,colors,.4,0))
 return m
render(base,x0,'initial');render(base,x,'initial-frozen-camera');fm=render(final,x,'photo');cv2.imwrite(str(OUT/'final-mask.png'),fm)
vc=dict(width=600,height=900,depth_range_cm=[-60,60],views={k:dict(axis='side' if k=='side' else 'back' if k=='back' else 'front',px_per_cm=4.8,center_cm=[0,85]) for k in ['front','side','back','pose','depth']});r.save(final,vc,OUT/'views')
pj=project(e['joints'],x);write('projected-pose.json',dict(joints=[dict(name=n,world_cm=p.tolist(),pixel=q.tolist(),in_frame=bool(0<=q[0]<W and 0<=q[1]<H),occlusion='not classified') for n,p,q in zip(r.names,e['joints'],pj)]))
write('measurements.json',dict(mesh_sha256=sha(OUT/'neutral.obj'),measurements=[dict(name=k,value=v,unit='cm',definition=r.data['measurementDefinition'],basis='prior' if k not in keys else 'mesh_parameter',mesh_checked=True,target=final['dimensions'][k],limitation='conditional model measurement, not photographed person') for k,v in final['measuredNeutral'].items()],unavailable_real_person=['underbust','bust_point_distance','front_back_waist_lengths','crotch_arc'],maximumTargetErrorCm=final['maximumTargetErrorCm']))
write('input-provenance.json',dict(source=json.load(open(ROOT/'work/commerce-skill-evals-20261118/inputs/everlane-boatneck/source.json')),hashes={str(p.relative_to(ROOT)):sha(p) for p in [r.asset,ROOT/'tools/human_fit/pose_guided/runtime.py',ROOT/'tools/human_fit/pose_guided/calibrate-worker.mjs',ROOT/'tools/human_fit/pose_guided/render_mesh.py',ROOT/'work/commerce-skill-evals-20261118/fixtures/neutral-state.json',OUT/'reference/original.jpg',OUT/'reference/pose-guide.png',Path(__file__)]},timing=None,tokens=None))
r.close()
