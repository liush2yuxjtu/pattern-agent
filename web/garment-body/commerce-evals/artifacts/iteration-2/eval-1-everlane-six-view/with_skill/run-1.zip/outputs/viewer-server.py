from pathlib import Path
import sys,json,os
from http.server import HTTPServer,SimpleHTTPRequestHandler
O=Path(__file__).resolve().parent;ROOT=Path('/workspace/work/pattern-agent');sys.path.insert(0,str(ROOT/'tools/human_fit/pose_guided'));from runtime import Runtime
r=Runtime();default=json.loads((O/'final-state.json').read_text())
def evaluate(s):
 if s.get('asset')!=default['asset'] or s.get('version')!=default['version']:raise ValueError('Incompatible asset/version')
 for c in r.data['controls']:
  v=s['dimensions'].get(c['key']);v=v if isinstance(v,(float,int)) and not isinstance(v,bool) else default['dimensions'][c['key']];s['dimensions'][c['key']]=round(max(c['min'],min(c['max'],v)),1)
 for n in r.names:
  p=s.get('poseDegrees',{}).get(n,[0,0,0]);s['poseDegrees'][n]=[round(max(-180,min(180,v)),1) if isinstance(v,(int,float)) and not isinstance(v,bool) else 0 for v in p]
 s=r.canonical_state(s);e=r.evaluate(s);return {'state':s,'vertices':e['posed'][r.ids].tolist(),'faces':r.body_faces.tolist(),'controls':[{k:c[k] for k in ['key','label','min','max']} for c in r.data['controls']]}
class Handler(SimpleHTTPRequestHandler):
 def do_POST(self):
  try:
   data=json.loads(self.rfile.read(int(self.headers['Content-Length'])));out=evaluate(data);body=json.dumps(out).encode();self.send_response(200)
  except Exception as e:body=json.dumps({'error':str(e)}).encode();self.send_response(400)
  self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(body)
os.chdir(O)
if __name__=='__main__':HTTPServer(('127.0.0.1',8877),Handler).serve_forever()
