from pathlib import Path
import sys,json,copy,hashlib,shutil,time
import numpy as np,cv2
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
ROOT=Path('/workspace/work/pattern-agent');O=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/human_fit/pose_guided'));from runtime import Runtime,sha
import render_mesh
D=ROOT/'work/commerce-skill-evals-20261118';r=Runtime();s=json.loads((D/'fixtures/neutral-state.json').read_text());initial=copy.deepcopy(s)
def dump(p,v): (O/p).write_text(json.dumps(v,indent=2)+'\n')
shutil.copy(D/'inputs/everlane-boatneck/original.jpg',O/'reference/original.jpg');shutil.copy(D/'inputs/everlane-boatneck/source.json',O/'reference/source.json')
photo=cv2.imread(str(O/'reference/original.jpg'));H,W=photo.shape[:2]
# Independently annotated original-image coordinates, not private case labels.
names=['upperarm01.R','lowerarm01.R','wrist.R','upperarm01.L','lowerarm01.L','wrist.L','neck01','head','root']
target=np.array([[794,1000],[684,1768],[650,2450],[1580,1017],[1702,1758],[1730,2402],[1204,895],[1220,515],[1200,2110]],float)
weights=np.array([1,0.7,1.5,1,0.7,1.5,.5,.6,.5])
dump('reference/landmarks.json',{'points':[{'bone':n,'pixel':p.tolist(),'basis':'visible wrist anatomical connection' if 'wrist' in n else 'coarse internal joint prior from visible clothing/body','weight':float(w)} for n,p,w in zip(names,target,weights)],'hidden_legs':'unobserved prior','uncertainty_px':{'wrist':35,'elbow':70,'shoulder':60,'pelvis':150}})
ann=photo.copy()
for n,p in zip(names,target):cv2.circle(ann,tuple(p.astype(int)),18,(0,0,255),5);cv2.putText(ann,n,tuple(p.astype(int)),cv2.FONT_HERSHEY_SIMPLEX,1,(0,0,255),2)
cv2.imwrite(str(O/'reference/landmarks.png'),ann)
# ImageGen is an illustrative annotation: estimate registration against untouched original.
g=cv2.imread(str(O/'reference/pose-guide.png'));small=cv2.resize(photo,(800,1000));gs=cv2.resize(g,(800,1000));sift=cv2.SIFT_create();ka,da=sift.detectAndCompute(gs,None);kb,db=sift.detectAndCompute(small,None);matches=cv2.BFMatcher().knnMatch(da,db,k=2);good=[a for a,b in matches if a.distance<.7*b.distance];a=np.float32([ka[m.queryIdx].pt for m in good]);b=np.float32([kb[m.trainIdx].pt for m in good]);hm,inside=cv2.findHomography(a,b,cv2.RANSAC,4);mapped=cv2.perspectiveTransform(a[:,None],hm)[:,0];err=np.linalg.norm(mapped-b,axis=1);raw=np.array([[355,458],[317,809],[302,1135],[760,477],[789,813],[813,1130]],float);native_to_small=np.diag([800/g.shape[1],1000/g.shape[0],1]);back=np.diag([3,3,1]);M=back@hm@native_to_small
mappedraw=cv2.perspectiveTransform(raw[None].astype(np.float32),M)[0];dump('reference/guide-registration.json',{'matrix_guide_native_to_original':M.tolist(),'method':'SIFT Lowe 0.7 homography RANSAC 4px at 800x1000','matches':len(good),'inliers':int(inside.sum()),'inlier_error_original_px':(err[inside[:,0]>0]*3).tolist(),'guide_raw_points':raw.tolist(),'mapped_points':mappedraw.tolist(),'semantic_review':'Illustrative shoulder points on shirt seam are not exact internal joint centers; pelvis marker is belt region not true hip; wrists roughly agree. Original visible skin connections override guide.'})
# Freeze broad clothing/person segmentation and anatomical region definitions before solving.
work=cv2.resize(photo,(600,750));mask=np.zeros((750,600),np.uint8);cv2.grabCut(work,mask,(120,10,355,740),None,None,5,cv2.GC_INIT_WITH_RECT);ref=cv2.resize(((mask==1)|(mask==3)).astype('uint8')*255,(W,H),interpolation=cv2.INTER_NEAREST);cv2.imwrite(str(O/'reference/reference-mask.png'),ref)
regions={'shoulders':[600,850,1850,1280],'right_arm':[500,1100,900,2950],'left_arm':[1480,1100,1900,2920],'torso':[800,1200,1600,2150],'waist_hips':[730,1850,1700,2850]};dump('reference/frozen-regions.json',{'regions_xyxy':regions,'scanlines_y':[1100,1450,1800,2100,2400],'reference_sha256':sha(O/'reference/original.jpg'),'mask_sha256':sha(O/'reference/reference-mask.png'),'segmentation_work_size':[600,750],'limitations':'Clothed person envelope including hair; not nude body ground truth.'})
# Explicit parameter map; spine held straight. Two bounded camera candidates, then arm/camera block.
params=[('upperarm01.R',0),('upperarm01.R',1),('upperarm01.R',2),('lowerarm01.R',0),('lowerarm01.R',2),('upperarm01.L',0),('upperarm01.L',1),('upperarm01.L',2),('lowerarm01.L',0),('lowerarm01.L',2),('neck01',2),('head',2)]
lo=np.array([-25,-45,-65,-30,-15,-25,-45,-65,-30,-15,-10,-10],float);hi=np.array([25,45,65,30,15,25,45,65,30,15,10,10],float)
def unpack(x):
 st=copy.deepcopy(s)
 for (n,ax),v in zip(params,x[6:]):st['poseDegrees'][n][ax]=float(v)
 return st

def rot(x):return Rotation.from_euler('YXZ',x[3:6],degrees=True).as_matrix()
def project(p,x):
 q=np.asarray(p)@rot(x).T
 return np.c_[x[0]*q[:,0]+x[1],x[2]-x[0]*q[:,1]]
def loss(x):
 e=r.evaluate(unpack(x),skin=False);j=e['joints'][[r.index[n] for n in names]];res=((project(j,x)-target)*weights[:,None]/50).ravel();reg=np.r_[x[3:6]/[15,10,8],x[6:]/60]*.2
 return np.r_[res,reg]
bounds=(np.r_[20,900,3800,-20,-10,-8,lo],np.r_[30,1450,5000,20,10,8,hi]);hist=[];candidates=[]
for yaw in [0,10]:
 x=np.r_[25,1200,4400,yaw,0,0,np.zeros(len(params))];fit=least_squares(loss,x,bounds=bounds,max_nfev=100,diff_step=.002);hist.append({'block':'camera and skeletal pose','yaw_initial':yaw,'initial':x.tolist(),'final':fit.x.tolist(),'cost_initial':float(np.sum(loss(x)**2)),'cost_final':float(np.sum(loss(fit.x)**2)),'nfev':fit.nfev,'explicit_pose_map':params});candidates.append(fit)
best=min(candidates,key=lambda f:np.sum(loss(f.x)**2));x=best.x.copy();x[6:]=np.round(x[6:],1);final=unpack(x)
for k in final['dimensions']:final['dimensions'][k]=round(final['dimensions'][k],1)
for n in final['poseDegrees']:final['poseDegrees'][n]=[round(v,1) for v in final['poseDegrees'][n]]
final=r.canonical_state(final);final['limitations']=['Generic M170 prior fitted to single clothed photo; not real-person measurements.','Lower body and hidden depth are hypotheses; LBS has no collision/tissue simulation.']
dump('final-state.json',final);dump('initial-state.json',initial);dump('parameter-block-history.json',hist)
e=r.evaluate(final);ei=r.evaluate(initial);R=rot(x);P=np.vstack([np.r_[x[0]*R[0],x[1]],np.r_[-x[0]*R[1],x[2]],np.r_[0,0,0,1]])
cam={'width':W,'height':H,'projection':'oblique orthographic','final':[float(x[0]),float(x[1]),float(x[2]),*map(float,x[3:6])],'world_to_pixel_homogeneous':P.tolist(),'units':'cm','depth_semantics':'rotated world Z, larger toward camera, cm','source_sha256':sha(O/'reference/original.jpg')};dump('camera.json',cam);dump('initial-camera.json',{'final':[25,1200,4400,0,0,0],'width':W,'height':H})
r.write_obj(O/'neutral.obj',e['shape']['rest']);r.write_obj(O/'posed.obj',e['posed']);r.write_obj(O/'initial.obj',ei['posed'])
# Raster from rotated real mesh, original native dimensions; no PNG stretching.
def render_source(vertices,x):
 v=vertices@rot(x).T;c={'width':W,'height':H,'depth_range_cm':[-40,40],'views':{'source':{'axis':'front','px_per_cm':float(x[0]),'center_cm':[(W/2-x[1])/x[0],(x[2]-H/2)/x[0]]}}};return render_mesh.raster(v,r.faces,c,'source')
m,im,dep,z=render_source(e['posed'],x);mi,imi,_,_=render_source(ei['posed'],x);cv2.imwrite(str(O/'photo-render.png'),im);cv2.imwrite(str(O/'final-mask.png'),m);cv2.imwrite(str(O/'initial-mask.png'),mi);cv2.imwrite(str(O/'initial-render.png'),imi);np.save(O/'source-depth.npy',z.astype('float32'));cv2.imwrite(str(O/'source-depth-valid.png'),np.isfinite(z).astype('uint8')*255);cv2.imwrite(str(O/'source-depth.png'),dep)
jp=project(e['joints'],x);dump('source-joints.json',{'joints':[{'name':n,'world_cm':p.tolist(),'pixel':uv.tolist(),'in_canvas':bool(0<=uv[0]<W and 0<=uv[1]<H),'occlusion':'unknown'} for n,p,uv in zip(r.names,e['joints'],jp)],'state_sha256':sha(O/'final-state.json')})
viewcam={'width':800,'height':1000,'depth_range_cm':[-50,50],'views':{n:{'axis':n if n in ['side','back'] else 'front','px_per_cm':5,'center_cm':[0,85]} for n in ['front','side','back','pose','depth']}}
r.save(final,viewcam,O/'views');render_mesh.render(O/'views/posed.obj',viewcam,O/'views',json.loads((O/'views/joints.json').read_text()))
measure=[]
for n,v in final['measuredNeutral'].items():measure.append({'name':n,'value':v,'target':final['dimensions'][n],'unit':'cm','basis':'prior','mesh_checked':True,'definition':r.data['measurementDefinition'],'limitations':'Generic conditional mannequin; no real-person accuracy established.'})
for n in ['underbust','bustPointDistance','shoulderSlope','frontWaistLength','backWaistLength','crotchArc']:measure.append({'name':n,'value':None,'unit':'cm','basis':'unavailable','mesh_checked':False})
dump('measurements.json',{'measurements':measure,'neutral_mesh_sha256':sha(O/'neutral.obj'),'maxTargetErrorCm':final['maximumTargetErrorCm']});(O/'measurements.csv').write_text('name,value,unit,basis\n'+'\n'.join(f"{v['name']},{v['value'] if v['value'] is not None else ''},cm,{v['basis']}" for v in measure))
for n in ['final-state.json','camera.json','photo-render.png']:shutil.copy(O/n,O/'generation-inputs'/n)
for n in ['front','side','back','pose','depth']:shutil.copy(O/'views'/f'{n}.png',O/'generation-inputs'/f'{n}.png')
dump('generation-inputs/manifest.json',{p.name:sha(p) for p in (O/'generation-inputs').iterdir() if p.is_file()})
dump('run.json',{'mode':'prior_avatar','scale_prior_cm':170,'timing':None,'tokens':None,'status':'geometry exported; generation pending','skill':'skill-v2 snapshot','fit_candidates':2,'dimensions_policy':'neutral M unchanged because clothing provides insufficient direct body girth evidence'})
dump('input-provenance.json',{str(p.relative_to(ROOT)):sha(p) for p in [D/'fixtures/neutral-state.json',D/'inputs/everlane-boatneck/original.jpg',D/'inputs/everlane-boatneck/source.json',D/'skill-v2/SKILL.md',ROOT/'tools/human_fit/pose_guided/runtime.py',ROOT/'tools/human_fit/pose_guided/calibrate-worker.mjs',ROOT/'tools/human_fit/pose_guided/render_mesh.py',r.asset]})
r.close();print(json.dumps({'final':x.tolist(),'landmark_rms_px':float(np.sqrt(np.mean((project(e['joints'][[r.index[n] for n in names]],x)-target)**2))),'state':str(O/'final-state.json')}))
