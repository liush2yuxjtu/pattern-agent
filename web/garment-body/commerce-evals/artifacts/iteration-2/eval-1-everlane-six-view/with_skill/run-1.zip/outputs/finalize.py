from pathlib import Path
import json,sys,hashlib,copy,importlib.util,csv
import numpy as np,cv2
O=Path(__file__).resolve().parent;ROOT=Path('/workspace/work/pattern-agent');sys.path.insert(0,str(ROOT/'tools/human_fit/pose_guided'));from runtime import Runtime,sha
from render_mesh import obj
# Exercise real viewer reconstruction without claiming browser/UI verification.
spec=importlib.util.spec_from_file_location('vs',O/'viewer-server.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
a=m.evaluate(copy.deepcopy(m.default));d=copy.deepcopy(m.default);d['dimensions']['height']+=1;b=m.evaluate(d);d=copy.deepcopy(m.default);d['poseDegrees']['lowerarm01.L'][0]+=10;c=m.evaluate(d);d=copy.deepcopy(m.default);d['dimensions']['height']=999;d['dimensions']['bust']='bad';d['poseDegrees']['wrist.L'][0]=.16;e=m.evaluate(d)
vc={'baseline_pose_exact':a['state']['poseDegrees']==m.default['poseDegrees'],'dimension_vertex_change_max_cm':float(np.max(abs(np.array(a['vertices'])-b['vertices']))),'elbow_vertex_change_max_cm':float(np.max(abs(np.array(a['vertices'])-c['vertices']))),'invalid_height_clamped':e['state']['dimensions']['height']==195,'invalid_type_defaults':e['state']['dimensions']['bust']==90,'pose_quantized':e['state']['poseDegrees']['wrist.L'][0]==.2,'browser_ui_test':'NOT_RUN','cache':'No browser cache; final state fetched on load','generation_backend':'NOT_CONNECTED'};(O/'evidence/viewer-check.json').write_text(json.dumps(vc,indent=2));m.r.close()
r=Runtime();state=json.loads((O/'final-state.json').read_text());e=r.evaluate(state);v,f=obj(O/'posed.obj');vn,fn=obj(O/'neutral.obj');vs=json.loads((O/'views/state.json').read_text());cam=json.loads((O/'camera.json').read_text());P=np.array(cam['world_to_pixel_homogeneous']);uv=np.c_[v,np.ones(len(v))]@P.T;mask=np.zeros((cam['height'],cam['width']),np.uint8)
for face in f:cv2.fillConvexPoly(mask,np.rint(uv[face,:2]).astype('int32'),255)
originalmask=cv2.imread(str(O/'final-mask.png'),0);edge={}
for row in f:
 for a,b in zip(row,np.roll(row,-1)):
  key=tuple(sorted([int(a),int(b)]));edge[key]=edge.get(key,0)+1
check={'pose_bones':len(state['poseDegrees']),'canonical_dimensions_identical':state['dimensions']==vs['dimensions'],'canonical_pose_identical':state['poseDegrees']==vs['poseDegrees'],'independent_obj_projection_mask_disagreement_pixels':int(np.count_nonzero(mask!=originalmask)),'posed_replay_max_cm':float(np.max(abs(v-e['posed'][r.ids]))),'neutral_replay_max_cm':float(np.max(abs(vn-e['shape']['rest'][r.ids]))),'surface_vertices':len(v),'triangles':len(f),'finite_vertices':bool(np.isfinite(v).all()),'boundary_edges':sum(n==1 for n in edge.values()),'nonmanifold_edges':sum(n>2 for n in edge.values()),'self_intersections':'NOT_RUN','collision_simulation':'NOT_RUN'}
for p in ['source-depth.npy','views/rawdepth.npy']:
 z=np.load(O/p);valid=np.isfinite(z);check[p]={'valid_pixels':int(valid.sum()),'finite_valid':bool(np.isfinite(z[valid]).all()),'min_cm':float(z[valid].min()),'max_cm':float(z[valid].max())}
(O/'evidence/replay-check.json').write_text(json.dumps(check,indent=2));r.close()
ref=cv2.imread(str(O/'reference/reference-mask.png'),0)>0;fin=originalmask>0;regions=json.loads((O/'reference/frozen-regions.json').read_text());local={}
for name,(x0,y0,x1,y1) in regions['regions_xyxy'].items():
 a=ref[y0:y1,x0:x1];b=fin[y0:y1,x0:x1];local[name]={'model_outside_clothed_envelope_fraction':float(np.count_nonzero(b&~a)/max(1,b.sum())),'clothed_silhouette_iou':float(np.count_nonzero(a&b)/max(1,np.count_nonzero(a|b)))}
scans=[]
for y in regions['scanlines_y']:
 a=np.flatnonzero(ref[y]);b=np.flatnonzero(fin[y]);scans.append({'y':y,'reference_extent':[int(a.min()),int(a.max())] if len(a) else None,'model_extent':[int(b.min()),int(b.max())] if len(b) else None,'center_delta_px':float((b.min()+b.max()-a.min()-a.max())/2) if len(a) and len(b) else None})
(O/'evidence/regional-diagnostics.json').write_text(json.dumps({'regions':local,'scanlines':scans,'acceptance':'NOT_ASSESSED; diagnostics only, no private scorer'},indent=2))
# Preserve native guide receipt metadata with hashes/native size.
p=O/'receipts/pose-guide.json';row=json.loads(p.read_text());im=cv2.imread(str(O/'reference/pose-guide.png'));row.update(output_sha256=sha(O/'reference/pose-guide.png'),native_size=[im.shape[1],im.shape[0]],input_hashes={str(O/'reference/original.jpg'):sha(O/'reference/original.jpg')});p.write_text(json.dumps(row,indent=2))
run=json.loads((O/'run.json').read_text());run.update(status='completed with explicit limitations',native_imagegen_calls=7,final_independent_generations=6);(O/'run.json').write_text(json.dumps(run,indent=2))
prov=json.loads((O/'input-provenance.json').read_text());prov['software_versions']={'python':sys.version,'numpy':np.__version__,'opencv':cv2.__version__};prov['skill_snapshot_files']={str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'work/commerce-skill-evals-20261118/skill-v2').rglob('*') if p.is_file()};(O/'input-provenance.json').write_text(json.dumps(prov,indent=2))
(O/'product-details.json').write_text(json.dumps({'observed':['white woven cotton shirt','wide boatneck','concealed front button placket','waist darts and fitted waist','long sleeves pushed up with cuffs','black trousers','no observed jewelry'],'source':'reference/source.json official details plus direct original inspection','unobserved':['back construction','side seam details','legs feet shoes','actual hidden body depths'],'generated_review':{'front':'retains observed product; posture partly regularized','side':'plausible inferred profile; sleeve cuff preserved','back':'inferred back dart construction; not source evidence','closeup':'retains boatneck cotton texture placket and waist darts','pose':'illustrative; arbitrary extra chest points not anatomical detector truth','depth':'illustrative grayscale; not registered actual depth'}},indent=2))
print(json.dumps(check));print(json.dumps(local))
