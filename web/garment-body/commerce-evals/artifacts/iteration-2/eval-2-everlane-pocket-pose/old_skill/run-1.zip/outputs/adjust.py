"""Actual cm calibration and FK/LBS adjustment, creates a NEW version directory.
Example: python adjust.py --out adjustments/taller --dimensions '{"height":172}' --pose '{"lowerarm01.R":[-30,0,5]}'
Run from the outputs directory. Never reuse original fit overlay for edited state.
"""
import argparse,json,sys
from pathlib import Path
ROOT=Path('/workspace/work/pattern-agent');sys.path.insert(0,str(ROOT/'tools/human_fit/pose_guided'))
from runtime import Runtime
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--dimensions',default='{}');p.add_argument('--pose',default='{}');a=p.parse_args();base=Path(__file__).parent
s=json.loads((base/'final-state.json').read_text());s['dimensions'].update(json.loads(a.dimensions));s['poseDegrees'].update(json.loads(a.pose));r=Runtime();r.save(s,json.loads((base/'views/camera.json').read_text()),base/a.out);r.close()
