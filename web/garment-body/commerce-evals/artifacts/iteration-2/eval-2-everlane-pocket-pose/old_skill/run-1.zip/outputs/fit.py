from pathlib import Path
import json,sys,copy,hashlib,time,shutil
import numpy as np,cv2
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
ROOT=Path('/workspace/work/pattern-agent');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'tools/human_fit/pose_guided'))
from runtime import Runtime,sha
import render_mesh
D=ROOT/'work/commerce-skill-evals-20261118';r=Runtime();initial=json.loads((D/'fixtures/neutral-state.json').read_text());state=copy.deepcopy(initial)
photo=cv2.imread(str(D/'inputs/everlane-blue-shirt/original.jpg'));guide=cv2.imread(str(OUT/'images/pose.png'));H,W=photo.shape[:2]
shutil.copy2(D/'inputs/everlane-blue-shirt/original.jpg',OUT/'original.jpg');shutil.copy2(D/'inputs/everlane-blue-shirt/source.json',OUT/'source.json')
def save(p,x): (OUT/p).write_text(json.dumps(x,indent=2)+'\n')
# Actual SIFT image registration, generated overlay is not measurement truth.
sift=cv2.SIFT_create(nfeatures=5000);a,da=sift.detectAndCompute(cv2.cvtColor(guide,cv2.COLOR_BGR2GRAY),None);b,db=sift.detectAndCompute(cv2.cvtColor(photo,cv2.COLOR_BGR2GRAY),None)
matches=cv2.BFMatcher().knnMatch(da,db,k=2);good=[m for m,n in matches if m.distance<.7*n.distance]
src=np.float32([a[m.queryIdx].pt for m in good]);dst=np.float32([b[m.trainIdx].pt for m in good]);T,inside=cv2.findHomography(src,dst,cv2.RANSAC,5)
err=np.linalg.norm(cv2.perspectiveTransform(src[:,None,:],T)[:,0,:]-dst,axis=1);save('guide-registration.json',{'generated_to_original':T.tolist(),'matches':len(good),'inliers':int(inside.sum()),'inlier_error_mean_px':float(err[inside[:,0]>0].mean()),'method':'SIFT ratio .7 RANSAC homography; illustrative semantic corrections below'})
# Guide points read from generated image, shoulder points corrected inward to anatomical joint, hips corrected below garment waist.
points={'neck01':[560,279],'head':[555,188],'upperarm01.R':[470,306],'upperarm01.L':[668,285],'lowerarm01.R':[433,491],'lowerarm01.L':[729,463],'wrist.R':[414,727],'wrist.L':[669,636],'upperleg01.R':[510,692],'upperleg01.L':[615,692],'lowerleg01.R':[513,977],'lowerleg01.L':[631,974],'foot.R':[516,1315],'foot.L':[667,1326]}
names=list(points);target=cv2.perspectiveTransform(np.array([points[n] for n in names],np.float32)[:,None,:],T)[:,0,:]
weight=np.array([1,1,1,1,.6,.75,1,.15,.2,.2,.15,.15,.55,.55]);save('guidance-points.json',{'points':[{'bone':n,'guide_px':points[n],'original_px':target[i].tolist(),'weight':float(weight[i]),'visibility':'occluded_inferred' if n in ['wrist.L','upperleg01.R','upperleg01.L','lowerleg01.R','lowerleg01.L'] else 'visible_or_clothed_direction','semantics':'anatomical manual interpretation of illustrative guide; not detector'} for i,n in enumerate(names)]})
cam0=np.array([16.1,1250.,2860.,0.,0.,0.]) # scale, pixel origin at world floor, Euler camera degrees
cam0[2]=2900
controls=['upperarm01.R','upperarm01.L','lowerarm01.R','lowerarm01.L','upperleg01.R','upperleg01.L','lowerleg01.R','lowerleg01.L','spine01','neck01','head','wrist.R','wrist.L']
# In neutral rig the upper arms are abducted; solver starts all local angles at zero.
angles=np.zeros((len(controls),3));history=[]
def project(p,cam):
 rot=Rotation.from_euler('yxz',cam[3:],degrees=True).as_matrix();q=np.asarray(p)@rot.T
 return np.c_[q[:,0]*cam[0]+cam[1],-q[:,1]*cam[0]+cam[2]]
def st(ang):
 s=copy.deepcopy(state)
 for n,v in zip(controls,ang):s['poseDegrees'][n]=v.tolist()
 return s
def residual(x,mode):
 global state
 if mode=='camera':ang=angles;c=x
 elif mode=='pose':ang=x.reshape(-1,3);c=cam
 else:ang=x[:-6].reshape(-1,3);c=x[-6:]
 e=r.evaluate(st(ang),skin=False);pred=project(e['joints'][[r.index[n] for n in names]],c)
 res=((pred-target)*np.sqrt(weight[:,None])/35).ravel().tolist()
 # Weak explicit depth / angle priors retain non-observable anatomy.
 res+=list((ang/70).ravel()*.14)
 res += [(c[3]/30)*.1,(c[4]/15)*.3,(c[5]/10)*.2]
 # shoulder/torso/hip centre cues from source, independent of guide waist belt semantics.
 for n,t,w in [('root',[1210,1420],.45),('spine01',[1220,1280],.15)]:
  res+=((project(e['joints'][[r.index[n]]],c)[0]-t)/100*w).tolist()
 return np.array(res)
cam=cam0.copy()
for block in ['camera','pose','joint']:
 start=time.monotonic()
 x=cam if block=='camera' else angles.ravel() if block=='pose' else np.r_[angles.ravel(),cam]
 if block=='camera': lo=[13,950,2600,-20,-10,-8];hi=[19,1450,3100,20,10,8]
 elif block=='pose':lo=np.full(x.size,-75);hi=np.full(x.size,75)
 else:lo=np.r_[np.full(angles.size,-75),[13,950,2600,-20,-10,-8]];hi=np.r_[np.full(angles.size,75),[19,1450,3100,20,10,8]]
 
 if block!='camera':
  for j,n in enumerate(controls):
   if n in ['spine01','neck01','head']:lo[j*3:j*3+3]=-7;hi[j*3:j*3+3]=7
   if n.startswith('lowerleg'):
    lo[j*3:j*3+3]=[0,-2,-2];hi[j*3:j*3+3]=[20,2,2]
   if n.startswith('upperleg'):
    lo[j*3:j*3+3]=[-8,-8,-12];hi[j*3:j*3+3]=[12,8,12]
 before=float(np.sum(residual(x,block)**2));opt=least_squares(lambda z:residual(z,block),x,bounds=(lo,hi),max_nfev=40 if block=='camera' else 65,diff_step=.002,ftol=.003,xtol=.003)
 if block=='camera':cam=opt.x
 elif block=='pose':angles=opt.x.reshape(-1,3)
 else:angles=opt.x[:-6].reshape(-1,3);cam=opt.x[-6:]
 record={'block':block,'initial_values':x.tolist(),'final_values':opt.x.tolist(),'objective_before':before,'objective_after':float(np.sum(opt.fun**2)),'nfev':opt.nfev,'elapsed_seconds':time.monotonic()-start,'dimensions_policy':'All 12 neutral M170 dimensions fixed; single clothed photograph gives no trustworthy circumference update'};history.append(record);print(record['block'],record['objective_before'],record['objective_after'],flush=True)
 save('parameter-block-history.json',history)
angles=np.round(angles,1);final=r.canonical_state(st(angles));save('final-state.json',final);save('initial-state.json',initial)
# Camera affine matrix; renderer consumes transformed world coordinates without resizing output.
rot=Rotation.from_euler('yxz',cam[3:],degrees=True).as_matrix();matrix=np.zeros((3,4));matrix[0,:3]=cam[0]*rot[0];matrix[1,:3]=-cam[0]*rot[1];matrix[0,3]=cam[1];matrix[1,3]=cam[2];matrix[2,3]=1
camera={'width':W,'height':H,'projection':'oblique_orthographic','world_to_pixel_homogeneous':matrix.tolist(),'final':[float(cam[0]),float(cam[1]),float(cam[2]),float(cam[3]),float(cam[4]),float(cam[5])],'final_semantics':'[px_per_cm,origin_pixel_x,origin_pixel_y,yaw_y,pitch_x,roll_z], scipy extrinsic yxz degrees','rotation_matrix':rot.tolist(),'units':'cm','depth_semantics':'maximum camera-rotated Z cm; larger means toward observer; invalid -inf','state_sha256':sha(OUT/'final-state.json')};save('camera.json',camera)
e=r.evaluate(final);r.write_obj(OUT/'neutral.obj',e['shape']['rest']);r.write_obj(OUT/'posed.obj',e['posed'])
# Generic raster is applied to rigidly rotated vertices, with exact recorded source camera.
rc={'width':W,'height':H,'depth_range_cm':[-100,100],'views':{'photo':{'axis':'front','px_per_cm':cam[0],'center_cm':[(W/2-cam[1])/cam[0],(cam[2]-H/2)/cam[0]]}}}
for label,s in [('initial',initial),('final',final)]:
 ev=r.evaluate(s);m,img,dep,z=render_mesh.raster(ev['posed']@rot.T,r.faces,rc,'photo');cv2.imwrite(str(OUT/(label+'-mask.png')),m);cv2.imwrite(str(OUT/(label+'-render.png')),img)
 if label=='final':cv2.imwrite(str(OUT/'photo-render.png'),img);np.save(OUT/'rawdepth.npy',z.astype('float32'));cv2.imwrite(str(OUT/'depth-valid.png'),np.isfinite(z).astype('uint8')*255);cv2.imwrite(str(OUT/'depth.png'),dep)
# Save initial camera and pre-optimization mask as separate camera contribution.
save('initial-camera.json',{'final':cam0.tolist(),'width':W,'height':H});ri=Rotation.from_euler('yxz',cam0[3:],degrees=True).as_matrix();ic=copy.deepcopy(rc);ic['views']['photo']['px_per_cm']=cam0[0];ic['views']['photo']['center_cm']=[(W/2-cam0[1])/cam0[0],(cam0[2]-H/2)/cam0[0]];m,*_=render_mesh.raster(r.evaluate(initial)['posed']@ri.T,r.faces,ic,'photo');cv2.imwrite(str(OUT/'initial-unfitted-mask.png'),m)
vc={'width':800,'height':1100,'depth_range_cm':[-70,70],'views':{n:{'axis':n,'px_per_cm':5.7,'center_cm':[0,88]} for n in ['front','side','back']}};r.save(final,vc,OUT/'views')
# Actual original foreground segmentation: GrabCut at 600x750 with source background color seeds.
small=cv2.resize(photo,(600,750));g=np.full((750,600),cv2.GC_PR_BGD,np.uint8);g[15:735,205:425]=cv2.GC_PR_FGD;g[:12]=0;g[-8:]=0;g[:,:170]=0;g[:,455:]=0;g[35:110,273:320]=1;g[300:690,264:350]=1
cv2.grabCut(small,g,None,np.zeros((1,65)),np.zeros((1,65)),4,cv2.GC_INIT_WITH_MASK);ref=cv2.resize(np.isin(g,[1,3]).astype('uint8')*255,(W,H),interpolation=cv2.INTER_NEAREST);cv2.imwrite(str(OUT/'reference-mask.png'),ref)
metrics={}
for label in ['initial','final']:
 m=cv2.imread(str(OUT/(label+'-mask.png')),0)>0;rr=ref>0;inter=m&rr;union=m|rr;over=photo.copy();over[inter]=(over[inter]*.4+np.array([40,220,60])*.6).astype('uint8');over[rr&~m]=(over[rr&~m]*.4+np.array([190,40,220])*.6).astype('uint8');over[m&~rr]=(over[m&~rr]*.4+np.array([220,220,30])*.6).astype('uint8');cv2.imwrite(str(OUT/(label+'-overlay.png')),over)
 edges=[cv2.morphologyEx(x.astype('uint8'),cv2.MORPH_GRADIENT,np.ones((3,3),np.uint8))>0 for x in [m,rr]];d=[cv2.distanceTransform((~x).astype('uint8'),cv2.DIST_L2,3) for x in edges];dist=np.r_[d[0][edges[1]],d[1][edges[0]]];metrics[label]={'iou':float(inter.sum()/union.sum()),'dice':float(2*inter.sum()/(m.sum()+rr.sum())),'symmetric_contour_mean_px':float(dist.mean()),'symmetric_contour_p95_px':float(np.percentile(dist,95)),'nude_outside_clothed_envelope_fraction':float((m&~rr).sum()/m.sum())}
save('metrics.json',{'reference_sha256':sha(OUT/'original.jpg'),'reference_mask_sha256':sha(OUT/'reference-mask.png'),'camera_sha256':sha(OUT/'camera.json'),'segmentation':'GrabCut 600x750 restored by nearest-neighbour; clothes/hair are envelope, not naked silhouette','metrics':metrics})
rows=[]
for k,v in final['measuredNeutral'].items():rows.append({'name':k,'value':v,'target_cm':final['dimensions'][k],'unit':'cm','basis':'prior','mesh_checked':True,'definition':r.data['measurementDefinition'],'source':'generic M170 neutral fixture; independent saved coefficient reconstruction required','limitation':'Not retailer model measurements; hidden by loose clothing or perspective'})
for k in ['underbust','bust_point_distance','crotch_arc','front_waist_length','back_waist_length','shoulder_slope']:rows.append({'name':k,'value':None,'unit':'cm','basis':'unavailable','mesh_checked':False,'limitation':'Not observable from source'})
save('measurements.json',{'measurements':rows,'neutral_mesh_sha256':sha(OUT/'neutral.obj'),'standing_height_prior_cm':170})
(OUT/'measurements.csv').write_text('name,value_cm,basis\n'+'\n'.join(f"{x['name']},{x['value'] if x['value'] is not None else ''},{x['basis']}" for x in rows)+'\n')
projected=project(e['joints'],cam);save('pose-joints.json',{'joints':[{'name':n,'world_cm':e['joints'][i].tolist(),'pixel':projected[i].tolist(),'in_frame':bool(0<=projected[i,0]<W and 0<=projected[i,1]<H),'visibility':'not independently detected; wrist.L occluded in original'} for i,n in enumerate(r.names)],'edges':[[b['parent'],b['name']] for b in r.bones if b['parent']]})
save('input-provenance.json',{'source':json.loads((OUT/'source.json').read_text()),'original_sha256':sha(OUT/'original.jpg'),'neutral_fixture_sha256':sha(D/'fixtures/neutral-state.json'),'asset_sha256':sha(r.asset),'runtime_sha256':sha(ROOT/'tools/human_fit/pose_guided/runtime.py'),'fit_code_sha256':sha(__file__),'mode':'prior_avatar','unknown_total_elapsed_seconds':None,'tokens':None})
save('run.json',{'mode':'prior_avatar','six_image_generation':'NOT_RUN: prompt explicitly excludes full six branch','actual_imagegen_pose_calls':1,'tokens':None,'total_time_seconds':None,'numeric_seconds':sum(h['elapsed_seconds'] for h in history)})
r.close();print('DONE',metrics,flush=True)
