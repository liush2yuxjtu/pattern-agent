from pathlib import Path
import sys,json,copy,hashlib,time,shutil
import cv2,numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
ROOT=Path('/workspace/work/pattern-agent');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/human_fit/pose_guided'))
from runtime import Runtime,sha
from render_mesh import raster
r=Runtime();base=json.loads((ROOT/'work/commerce-skill-evals-20261118/fixtures/neutral-state.json').read_text())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
# Manually inspected original photo observations in 600x750 coordinates; no oracle.
obs=[('head',[297,80],1),('neck01',[294,128],.7),('upperarm01.R',[253,155],.6),('upperarm01.L',[354,146],.6),('lowerarm01.R',[226,277],.25),('lowerarm01.L',[387,253],.45),('wrist.R',[222,401],1),('wrist.L',[361,343],.12),('root',[306,328],.35),('upperleg01.R',[280,333],.15),('upperleg01.L',[333,333],.15),('foot.R',[264,716],.2),('foot.L',[365,718],.2)]
save(OUT/'observations.json',{'coordinate_system':'original pixels','working_transform':[[.25,0,0],[0,.25,0],[0,0,1]],'points':[{'bone':n,'pixel':[4*x for x in xy],'weight':w,'status':'hidden coarse front-pocket prior, NOT visible wrist' if n=='wrist.L' else 'anatomical hypothesis under clothing' if w<.8 else 'manually inspected cue; head rig point approximate'} for n,xy,w in obs],'visible_wrist_R':[888,1604],'hidden_wrist_L':None})
params=[(n,a) for n in ['upperarm01.R','upperarm01.L','lowerarm01.R','lowerarm01.L','wrist.R','wrist.L'] for a in range(3)]+[('root',2)]
lo=[-65,-80,-65]*2+[-100,-60,-55]*2+[-65,-85,-65]*2+[-7]
hi=[65,80,65]*2+[100,60,55]*2+[65,85,65]*2+[7]
def unpack(x,s):
 s=copy.deepcopy(s)
 for (n,a),v in zip(params,x[6:]):s['poseDegrees'][n][a]=float(v)
 return s
def rotation(x):return Rotation.from_euler('YXZ',x[3:6],degrees=True).as_matrix()
def project(p,x):
 q=p@rotation(x).T
 return np.c_[q[:,0]*x[0]+x[1],-q[:,1]*x[0]+x[2]]
def objective(x,s):
 e=r.evaluate(unpack(x,s),skin=False);js=e['joints'];xy=project(js,x);res=[]
 for n,t,w in obs:res.extend((xy[r.index[n]]-t)*np.sqrt(w))
 # Standing frame with hidden depths weakly regularized, not measured.
 res.extend(x[6:24]*.06);res.extend(x[4:6]*.4)
 for side in ['L','R']:
  w=js[r.index['wrist.'+side]];el=js[r.index['lowerarm01.'+side]];pel=js[r.index['upperleg01.'+side]]
  res.append(max(0,pel[2]+2-w[2])*1.7 if side=='L' else (w[2]-pel[2]-2)*.35)
  res.append(max(0,el[2]-w[2]-3)*.6)
 return np.array(res)
x0=np.array([4.05,300,725,0,0,0]+[0.]*len(params));history=[];candidates=[]
start=time.monotonic()
for k,(yaw,lengths) in enumerate([(0,None),(12,None),(-8,(30.,24.))]):
 s=copy.deepcopy(base)
 if lengths:s['dimensions'].update(upperArmLength=lengths[0],forearmLength=lengths[1])
 x=x0.copy();x[3]=yaw
 sol=least_squares(lambda xx:objective(xx,s),x,bounds=([3.5,270,680,-30,-6,-6]+lo,[4.6,340,765,30,6,6]+hi),max_nfev=100,ftol=1e-5)
 state=unpack(sol.x,s);loss=float(np.mean(objective(sol.x,s)**2));candidates.append((loss,state,sol.x))
 save(OUT/f'candidate-{k+1}.json',{'state':state,'camera_working':sol.x[:6].tolist(),'loss':loss,'nfev':sol.nfev,'elapsed_seconds':time.monotonic()-start})
 history.append({'block':k+1,'initial':{'dimensions':s['dimensions'],'poseDegrees':base['poseDegrees'],'camera':x[:6].tolist()},'final':{'dimensions':state['dimensions'],'poseDegrees':state['poseDegrees'],'camera':sol.x[:6].tolist()},'loss':loss,'nfev':sol.nfev})
 print('candidate',k+1,loss,sol.nfev,flush=True)
loss,state,x=min(candidates,key=lambda v:v[0]);state['dimensions']={k:round(float(v),1) for k,v in state['dimensions'].items()};state['poseDegrees']={k:[round(float(v),1) for v in a] for k,a in state['poseDegrees'].items()}
state=r.canonical_state(state);state['limitations']=['M170 generic prior, conditional limb dimensions; not person measurements','Single original front image; hidden left wrist and leg/hip pose are priors','All dimensions/angles quantized to editor 0.1 step before final rebuild']
save(OUT/'final-state.json',state);save(OUT/'parameter-block-history.json',history)
e=r.evaluate(state);r.write_obj(OUT/'neutral.obj',e['shape']['rest']);r.write_obj(OUT/'posed.obj',e['posed'])
x=x.copy();x[:3]*=4;R=rotation(x);P=np.zeros((3,4));P[0,:3]=x[0]*R[0];P[0,3]=x[1];P[1,:3]=-x[0]*R[1];P[1,3]=x[2];P[2,3]=1
cam={'width':2400,'height':3000,'projection':'oblique orthographic','final':x[:6].tolist(),'world_to_pixel_homogeneous':P.tolist(),'units':'cm','depth_semantics':'rotated world Z, larger nearer, cm; not camera distance','depth_range_cm':[-70,70]};save(OUT/'camera.json',cam)
def render_source(s,c,prefix):
 ee=r.evaluate(s);v=ee['posed']@rotation(c).T
 camera={'width':2400,'height':3000,'depth_range_cm':[-70,70],'views':{'photo':{'axis':'front','px_per_cm':c[0],'center_cm':[(1200-c[1])/c[0],(c[2]-1500)/c[0]]}}}
 mask,img,dep,z=raster(v,r.faces,camera,'photo');cv2.imwrite(str(OUT/(prefix+'render.png')),img);cv2.imwrite(str(OUT/(prefix+'mask.png')),mask)
 return mask,z,ee
finalmask,z,e=render_source(state,x,'photo-');shutil.copy(OUT/'photo-mask.png',OUT/'final-mask.png');np.save(OUT/'rawdepth.npy',z.astype('float32'));cv2.imwrite(str(OUT/'depth-valid.png'),np.isfinite(z).astype('uint8')*255)
initial= r.canonical_state(base);save(OUT/'initial-state.json',initial);xi=x0.copy();xi[:3]*=4;save(OUT/'initial-camera.json',{'width':2400,'height':3000,'final':xi[:6].tolist()});initialmask,_,_=render_source(initial,xi,'initial-');fixed,_,_=render_source(initial,x,'initial-fixed-camera-')
viewcamera={'width':720,'height':900,'depth_range_cm':[-70,70],'views':{n:{'axis':n,'px_per_cm':4.6,'center_cm':[0,85]} for n in ['front','side','back']}}
r.save(state,viewcamera,OUT/'views')
save(OUT/'projected-joints.json',{'state_sha256':sha(OUT/'final-state.json'),'joints':[{'name':n,'world_cm':e['joints'][i].tolist(),'pixel':project(e['joints'],x)[i].tolist(),'inside_canvas':bool(0<=project(e['joints'],x)[i,0]<2400 and 0<=project(e['joints'],x)[i,1]<3000),'occlusion':'unknown'} for i,n in enumerate(r.names)]})
# GrabCut actual original-photo foreground; clothing silhouette is envelope, not bare body.
photo=cv2.imread(str(ROOT/'work/commerce-skill-evals-20261118/inputs/everlane-blue-shirt/original.jpg'));small=cv2.resize(photo,(600,750));gc=np.zeros((750,600),np.uint8);bg=np.zeros((1,65));fg=np.zeros((1,65));cv2.grabCut(small,gc,(200,12,224,727),bg,fg,5,cv2.GC_INIT_WITH_RECT);ref=cv2.resize(((gc==1)|(gc==3)).astype('uint8')*255,(2400,3000),interpolation=cv2.INTER_NEAREST);cv2.imwrite(str(OUT/'reference-mask.png'),ref)
def metrics(m,prefix):
 a=ref>0;b=m>0;inter=a&b;union=a|b;overlay=photo.copy();overlay[inter]=(.5*photo[inter]+.5*np.array([40,220,50])).astype('uint8');overlay[a&~b]=(.5*photo[a&~b]+.5*np.array([220,40,220])).astype('uint8');overlay[b&~a]=(.5*photo[b&~a]+.5*np.array([220,220,40])).astype('uint8');cv2.imwrite(str(OUT/(prefix+'overlay.png')),overlay)
 ca=cv2.morphologyEx(a.astype('uint8'),cv2.MORPH_GRADIENT,np.ones((3,3),np.uint8));cb=cv2.morphologyEx(b.astype('uint8'),cv2.MORPH_GRADIENT,np.ones((3,3),np.uint8));da=cv2.distanceTransform(1-ca,cv2.DIST_L2,5);db=cv2.distanceTransform(1-cb,cv2.DIST_L2,5);d=np.r_[da[cb>0],db[ca>0]]
 return {'IoU':float(inter.sum()/union.sum()),'Dice':float(2*inter.sum()/(a.sum()+b.sum())),'symmetric_contour_mean_px':float(d.mean()),'symmetric_contour_p95_px':float(np.percentile(d,95)),'reference_sha256':sha(OUT/'reference-mask.png'),'resolution':[2400,3000]}
save(OUT/'metrics.json',{'initial_own_camera':metrics(initialmask,'initial-'),'initial_fixed_final_camera':metrics(fixed,'initial-fixed-camera-'),'final':metrics(finalmask,'final-'),'limitations':'clothing envelope comparison, not bare body recovery; GrabCut at 600x750 nearest-neighbour expanded; pixel metrics at native frame'})
measures=[{'name':k,'value':state['measuredNeutral'][k],'target_cm':v,'unit':'cm','basis':'prior' if v==base['dimensions'][k] else 'mesh_parameter','mesh_checked':True,'definition':'standing_height' if k=='height' else 'landmark_distance' if k in ['shoulders','upperArmLength','forearmLength','thighLength'] else 'surface_tape_path','limitations':'conditional avatar, not observed person; single clothed image'} for k,v in state['dimensions'].items()]
measures += [{'name':k,'value':None,'unit':'cm','basis':'unavailable','mesh_checked':False} for k in ['bust_point_distance','underbust','shoulder_slope','front_waist_length','back_waist_length','crotch_arc']]
save(OUT/'measurements.json',{'state_sha256':sha(OUT/'final-state.json'),'mesh_sha256':sha(OUT/'neutral.obj'),'measurements':measures});(OUT/'measurements.csv').write_text('name,value,unit,basis,definition\n'+'\n'.join(f"{m['name']},{m['value'] if m['value'] is not None else ''},cm,{m['basis']},{m.get('definition','unavailable')}" for m in measures)+'\n')
save(OUT/'numerical-run.json',{'elapsed_seconds':time.monotonic()-start,'selected_loss':loss,'candidate_count':3,'timing_tokens':None});r.close()
