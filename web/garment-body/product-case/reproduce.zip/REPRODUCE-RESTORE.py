#!/usr/bin/env python3
import hashlib,json,pathlib,shutil
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'REPRODUCE-MANIFEST.json').read_text())
def target(name):
 p=(root/name).resolve()
 if root not in p.parents:raise ValueError('Unsafe archive path')
 return p
for alias,canonical in manifest['aliases'].items():
 source=target(canonical);dest=target(alias)
 if hashlib.sha256(source.read_bytes()).hexdigest()!=manifest['files'][alias]:raise ValueError('Bad canonical bytes')
 dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
for name,sha in manifest['files'].items():
 if hashlib.sha256(target(name).read_bytes()).hexdigest()!=sha:raise ValueError('Hash mismatch: '+name)
print(json.dumps({'verdict':'PASS','files':len(manifest['files']),'restored_aliases':len(manifest['aliases'])}))
