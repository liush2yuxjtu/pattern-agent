import importlib.util,json,numpy as np,cv2,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('fit',P/'fit-generated.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
cal=json.loads((P/'camera.json').read_text());source=json.loads((P/'iteration-1/camera.json').read_text());points=json.loads((P.parent/'images/landmarks.json').read_text())['points'];state=json.loads((P/'final-state.json').read_text());p=np.array([state['poseDegrees'][j][a] for j,a in zip(m.JOINTS,m.AXES)]);report={}
for view in ['front','side','back']:
 report[view]={};ref=cv2.imread(str(P/'fit'/f'{view}-reference-mask.png'),0)
 for label,camera,par in [('source_camera_neutral',source,np.zeros(len(m.JOINTS))),('calibrated_camera_neutral',cal,np.zeros(len(m.JOINTS))),('calibrated_camera_fitted_pose',cal,p)]:
  m.CAM=camera;v,w=m.deform(par);mask=m.silhouette(v,view);c=camera['views'][view];errors=[]
  for point in points:
   if point['view']!=view:continue
   q=w[m.NI[point['joint']]];horizontal=q[2] if c['axis']=='side' else q[0]*(-1 if c['axis']=='back' else 1);pixel=[(horizontal-c['center_cm'][0])*c['px_per_cm']+384,512-(q[1]-c['center_cm'][1])*c['px_per_cm']];errors.append({'joint':point['joint'],'observed_pixel':point['pixel'],'projected_pixel':pixel,'error_px':float(np.linalg.norm(np.array(pixel)-point['pixel']))})
  report[view][label]={'full_clothed_envelope':m.metrics(ref,mask),'manual_landmarks':errors,'mean_manual_landmark_error_px':float(np.mean([r['error_px'] for r in errors]))}
report['protocol']={'source':'same immutable photos, same masks, same768x1024 resolution','contributions':'source camera neutral -> calibrated camera neutral isolates registration; calibrated neutral -> calibrated fitted pose isolates actual skeletal pose change','shape':'fixed170/90/72/96/37cm prior throughout','back':'camera independently calibrated using neck+ankle heights and horizontal neck, but all back wrist/ankle pose evaluation excluded from training','calibrated_camera_sha256':hashlib.sha256((P/'camera.json').read_bytes()).hexdigest(),'interpretation':'Manual-anchor internal generated-image reprojection; not real-person recovered shape or physical camera calibration'}
(P/'fit/camera-pose-contributions.json').write_text(json.dumps(report,indent=2));print(json.dumps({v:{stage:round(values['mean_manual_landmark_error_px'],3) for stage,values in r.items()} for v,r in report.items() if v!='protocol'},indent=2))
