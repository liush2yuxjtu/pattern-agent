"""Independent pose diagnostic; does not replace shared-pose heldout protocol."""
import importlib.util,json,cv2,numpy as np,subprocess,hashlib
from pathlib import Path
from scipy.optimize import least_squares
P=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('fit',P/'fit-generated.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);base=json.loads((P/'final-state.json').read_text());observed=json.loads((P.parent/'images/landmarks.json').read_text())['points'];out=P/'view-specific';out.mkdir(exist_ok=True)
keys=[(joint,axis) for joint,value in base['poseDegrees'].items() for axis in range(3) if value[axis] or joint in ['upperarm01.L','upperarm01.R','lowerarm01.L','lowerarm01.R']];m.JOINTS=[j for j,a in keys];m.AXES=[a for j,a in keys];start=np.array([base['poseDegrees'][j][a] for j,a in keys]);variable=[i for i,(j,a) in enumerate(keys) if j in ['upperarm01.L','upperarm01.R','lowerarm01.L','lowerarm01.R'] and a in [0,2]]
def project(w,view,name):
 c=m.CAM['views'][view];q=w[m.NI[name]];horizontal=q[2] if view=='side' else -q[0];return np.array([(horizontal-c['center_cm'][0])*c['px_per_cm']+384,512-(q[1]-c['center_cm'][1])*c['px_per_cm']])
summary={}
for view in ['side','back']:
 dest=out/view;dest.mkdir(exist_ok=True);points=[p for p in observed if p['view']==view];selected=[p for p in points if p['joint'].startswith('wrist')]
 def pose(x):
  values=start.copy();values[variable]=x;return values
 def residual(x):
  _,w=m.deform(pose(x));return np.r_[np.concatenate([(project(w,view,p['joint'])-p['pixel'])/10 for p in selected]),(x-start[variable])*.007]
 delta=np.array([22 if keys[i][0].startswith('upperarm') else 45 for i in variable]);result=least_squares(residual,start[variable],bounds=(start[variable]-delta,start[variable]+delta),max_nfev=90,ftol=1e-8,xtol=1e-7);values=np.round(pose(result.x),1);state=json.loads(json.dumps(base))
 for (j,a),value in zip(keys,values):state['poseDegrees'][j][a]=float(value)
 (P/(view+'-state.json')).write_text(json.dumps(state,indent=2));(dest/'state.json').write_text(json.dumps(state,indent=2));subprocess.run(['node',str(P/'export-pose.mjs'),str(dest/'state.json'),str(dest/'posed'),'--glb'],check=True,stdout=subprocess.DEVNULL)
 camera=json.loads(json.dumps(m.CAM));camera['views']={view:camera['views'][view]};(dest/'camera.json').write_text(json.dumps(camera,indent=2));subprocess.run(['python',str(P.parents[1]/'anatomical-skill-evals-20261117/fixtures/render_mesh.py'),'--mesh',str(dest/'posed.obj'),'--camera',str(dest/'camera.json'),'--joints',str(dest/'posed-joints.json'),'--out',str(dest/'renders')],check=True)
 ref=cv2.imread(str(P/'fit'/f'{view}-reference-mask.png'),0);photo=cv2.resize(cv2.imread(str(P.parent/'images'/f'{view}.png')),(768,1024));metrics={};ims=[]
 for label,params in [('shared',start),('view_specific',values)]:
  v,w=m.deform(params);mask=m.silhouette(v,view);metrics[label]={'clothed_envelope':m.metrics(ref,mask),'manual_joint_errors_px':[{'joint':p['joint'],'error_px':float(np.linalg.norm(project(w,view,p['joint'])-p['pixel']))} for p in points]};image=photo.copy();edge=cv2.morphologyEx(mask,cv2.MORPH_GRADIENT,np.ones((3,3),np.uint8))>0;image[edge]=[255,220,0]
  for point in points:
   pred=tuple(np.rint(project(w,view,point['joint'])).astype(int));obs=tuple(point['pixel']);cv2.circle(image,pred,5,(255,220,0),2);cv2.circle(image,obs,6,(255,0,255),2);cv2.line(image,pred,obs,(255,0,255),1)
  cv2.rectangle(image,(0,0),(768,45),(245,245,245),-1);cv2.putText(image,f'{view} {label}',(15,30),cv2.FONT_HERSHEY_SIMPLEX,.7,(20,20,20),1,cv2.LINE_AA);cv2.imwrite(str(dest/(label+'-overlay.png')),image);ims.append(image)
 cv2.imwrite(str(dest/'before-after.png'),np.concatenate(ims,axis=1));metrics['protocol']={'mode':'view_specific_pose diagnostic, not heldout evaluation','body_shape_unchanged':state['morphWeights']==base['morphWeights'],'camera_unchanged':True,'optimized_landmarks':'manual visible wrist centers only','objective':'joint reprojection with regularization toward shared pose; no clothing silhouette or dimensions optimization','reference_sha256':hashlib.sha256((P.parent/'images'/f'{view}.png').read_bytes()).hexdigest(),'solver_nfev':result.nfev,'shared_default_preserved':True};(dest/'metrics.json').write_text(json.dumps(metrics,indent=2));summary[view]=metrics
(out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({v:{mode:[round(x['error_px'],2) for x in data[mode]['manual_joint_errors_px']] for mode in ['shared','view_specific']} for v,data in summary.items()},indent=2))
