import importlib.util,json,cv2,numpy as np,subprocess,shutil,hashlib
from pathlib import Path
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
P=Path(__file__).resolve().parent;out=P/'original-reference';archive=out/'iteration-1';archive.mkdir(exist_ok=True)
for f in list(out.iterdir()):
 if f.name=='iteration-1':continue
 if f.is_dir():shutil.copytree(f,archive/f.name,dirs_exist_ok=True)
 else:shutil.copy2(f,archive/f.name)
s=importlib.util.spec_from_file_location('fit',P/'fit-generated.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);state=json.loads((archive/'state.json').read_text());camera=json.loads((out/'camera.json').read_text());c=camera['views']['front'];w,h=camera['width'],camera['height'];shapehash=hashlib.sha256(json.dumps(state['morphWeights']).encode()).hexdigest();points=json.loads((archive/'manual-landmarks.json').read_text())['points'];points += [{'joint':'eye.L','pixel':[343,163],'source':'fresh manual visible left-anatomical eye center'},{'joint':'eye.R','pixel':[258,158],'source':'fresh manual visible right-anatomical eye center'},{'vertex':201,'pixel':[292,218],'source':'fresh manual visible nose tip; actual MakeHuman central most-anterior nose vertex201'}]
keys=[('spine02',1),('spine02',2)]+[(j,a) for j in ['neck01','head','upperarm01.L','upperarm01.R','lowerarm01.L','lowerarm01.R'] for a in range(3)];m.JOINTS=[j for j,a in keys];m.AXES=[a for j,a in keys];start=np.array([state['poseDegrees'][j][a] for j,a in keys]);lower=[];upper=[]
for j,a in keys:
 if j=='spine02':b=(-12,12)
 elif j=='neck01':b=((-25,30),(-35,35),(-22,22))[a]
 elif j=='head':b=((-35,35),(-55,55),(-22,22))[a]
 elif j.startswith('upperarm'):b=((-85,90),(-85,85),(-65,65))[a]
 elif j.endswith('.L'):b=((-85,85),(-85,85),(-145,20))[a]
 else:b=((-85,85),(-85,85),(-20,145))[a]
 lower.append(b[0]);upper.append(b[1])
def forward(p):
 angles=np.zeros((len(m.B),3))
 for (j,a),v in zip(keys,p):angles[m.NI[j],a]=v
 LR=m.R0@Rotation.from_euler('XYZ',angles,degrees=True).as_matrix();G=np.zeros_like(m.Q);world=np.zeros_like(m.H)
 for i in m.ORDER:
  parent=m.P[i];G[i]=G[parent]@LR[i] if parent>=0 else LR[i];world[i]=world[parent]+G[parent]@m.L[i] if parent>=0 else m.L[i]
 M=G@m.Q.transpose(0,2,1);offset=world-np.einsum('nij,nj->ni',M,m.H);nose=sum(m.SW[201,k]*(M[m.SK[201,k]]@m.V[201]+offset[m.SK[201,k]]) for k in range(4));return world,nose

def project(q):return np.array([(q[0]-c['center_cm'][0])*c['px_per_cm']+w/2,h/2-(q[1]-c['center_cm'][1])*c['px_per_cm']])
count=0

def residual(p):
 global count;count+=1;world,nose=forward(p);rows=[]
 for point in points:
  q=nose if 'vertex' in point else world[m.NI[point['joint']]];weight=.45 if point.get('joint','').startswith(('upperarm','lowerarm')) else 1.25 if point.get('joint','').startswith('wrist') else 1.;rows.extend(weight*(project(q)-point['pixel'])/12)
 regular=np.array([.016 if j=='spine02' else .007 if j in ['neck01','head'] else .002 for j,a in keys]);return np.r_[rows,(p-start)*regular]
result=least_squares(residual,start,bounds=(lower,upper),max_nfev=250,ftol=1e-9,xtol=1e-9,gtol=1e-9);selected=np.round(result.x,1)
for (j,a),v in zip(keys,selected):state['poseDegrees'][j][a]=float(v)
(out/'state.json').write_text(json.dumps(state,indent=2));(out/'manual-landmarks.json').write_text(json.dumps({'native_pixels':[w,h],'points':points,'source':'Fresh manual visible eyes/nose added; hidden shoulder/elbow centers retain explicit uncertainty. Bone-eye centers and actual mesh nose vertex201 are projected.','shape_unchanged':True},indent=2));subprocess.run(['node',str(P/'export-pose.mjs'),str(out/'state.json'),str(out/'posed'),'--glb'],check=True,stdout=subprocess.DEVNULL);subprocess.run(['python',str(P.parents[1]/'anatomical-skill-evals-20261117/fixtures/render_mesh.py'),'--mesh',str(out/'posed.obj'),'--camera',str(out/'camera.json'),'--joints',str(out/'posed-joints.json'),'--out',str(out/'renders')],check=True)
photo=cv2.imread(str(P.parent/'reference/original-product.jpg'));ref=cv2.imread(str(out/'reference-mask.png'),0);m.CAM=camera;metrics={};ims=[]
for label,p in [('previous_candidate',start),('refined_head_and_arms',selected)]:
 v,world=m.deform(p);worldfast,nose=forward(p);mask=m.silhouette(v,'front',(w,h));image=photo.copy();edge=cv2.morphologyEx(mask,cv2.MORPH_GRADIENT,np.ones((3,3),np.uint8))>0;image[edge]=[255,220,0];errors=[]
 for point in points:
  q=nose if 'vertex' in point else world[m.NI[point['joint']]];pred=project(q);obs=np.array(point['pixel']);name='nose_vertex201' if 'vertex' in point else point['joint'];errors.append({'landmark':name,'error_px':float(np.linalg.norm(pred-obs))});cv2.circle(image,tuple(np.rint(pred).astype(int)),6,(255,220,0),2);cv2.circle(image,tuple(obs),7,(255,0,255),2);cv2.line(image,tuple(np.rint(pred).astype(int)),tuple(obs),(255,0,255),1)
 cv2.rectangle(image,(0,0),(w,50),(245,245,245),-1);cv2.putText(image,'ORIGINAL '+label,(15,32),cv2.FONT_HERSHEY_SIMPLEX,.75,(20,20,20),1,cv2.LINE_AA);cv2.imwrite(str(out/(label+'-overlay.png')),image);ims.append(image);metrics[label]={'manual_joint_errors_px':errors,'cropped_clothed_envelope':m.metrics(ref,mask)}
cv2.imwrite(str(out/'before-after.png'),np.concatenate(ims,axis=1));metrics['protocol']={'separate_from_generated_validation':True,'same_shape_as_main_final':state['morphWeights']==json.loads((P/'final-state.json').read_text())['morphWeights'],'camera_unchanged':True,'native_evaluation_resolution':[w,h],'optimized':'bounded actual spine02 yaw/roll, neck/head XYZ, shoulders/upperarm XYZ and elbow XYZ; no shape edits','objective_calls':count,'solver_nfev':result.nfev,'pose_bounds_deg':[{ 'joint':j,'axis':a,'min':lo,'max':hi} for (j,a),lo,hi in zip(keys,lower,upper)],'selected_pose_degrees':{j:state['poseDegrees'][j] for j in state['poseDegrees'] if any(state['poseDegrees'][j])},'landmarks':'Manual visible eye/nose/wrist and uncertain clothing-occluded shoulder/elbow centers; eye bone centers and actual nose meshvertex201','limits':['Original crop has oblique perspective, different face identity, hair and garment gathering.','Camera anchor neck and manually estimated occluded joints are not independent real-person body validation.','Low2Dreprojection error alone does not identify true3Dpose or tissue/cloth fit.','Main generation2 finalshape/pose/camera/renders remain unchanged.']};(out/'metrics.json').write_text(json.dumps(metrics,indent=2));print(json.dumps(metrics,indent=2))
