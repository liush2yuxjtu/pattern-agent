#!/usr/bin/env python3
"""Actual MakeHuman LBS fit. Frozen generated photos constrain pose/clothed limb silhouettes.
No garment silhouette is treated as naked torso circumference. Back is held out.
"""
import cv2,numpy as np,json,hashlib,sys,importlib.util
from pathlib import Path
from scipy.spatial.transform import Rotation
from scipy.optimize import minimize
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[2]
D=json.loads((ROOT/'web/human-studio/assets/human.json').read_text()); STATE=json.loads((HERE/('shape-source-state.json' if (HERE/'shape-source-state.json').exists() else 'initial-state.json')).read_text()); CAM=json.loads((HERE/'camera.json').read_text())
V=np.array(D['vertices'],float).reshape(-1,3)
for c,w in zip(D['controls'],STATE['morphWeights']):
 for row in c['incr' if w>=0 else 'decr']:V[int(row[0])]+=np.array(row[1:])*abs(w)
IDS=np.array(D['bodyVertexIds']);V[:,1]-=V[IDS,1].min();F=np.array(D['indices']).reshape(-1,3)
B=D['bones']; NI={b['name']:i for i,b in enumerate(B)}; P=[NI.get(b['parent'],-1) for b in B]
H=np.array([V[D['joints'][b['head']]].mean(0) for b in B]); T=np.array([V[D['joints'][b['tail']]].mean(0) for b in B]);Q=[]
for h,t in zip(H,T):
 y=t-h;y/=max(np.linalg.norm(y),1e-12)
 if np.linalg.norm(y)<.5:y=np.array([0.,1,0])
 x=np.cross(y,[0,0,1])
 if np.linalg.norm(x)<1e-8:x=np.cross(y,[0,1,0])
 x/=np.linalg.norm(x);z=np.cross(x,y);Q.append(np.column_stack([x,y,z]))
Q=np.array(Q);R0=np.array([Q[p].T@Q[i] if p>=0 else Q[i] for i,p in enumerate(P)]);L=np.array([Q[p].T@(H[i]-H[p]) if p>=0 else H[i] for i,p in enumerate(P)])
SK=np.array(D['skinIndices']).reshape(-1,4);SW=np.array(D['skinWeights']).reshape(-1,4);SW/=np.maximum(SW.sum(1,keepdims=True),1e-12)
ORDER=[]
def visit(i):
 if i in ORDER:return
 if P[i]>=0:visit(P[i])
 ORDER.append(i)
for i in range(len(B)):visit(i)
JOINTS=['upperarm01.L','upperarm01.R','lowerarm01.L','lowerarm01.R','upperleg01.L','upperleg01.R','upperleg01.L','upperleg01.R','lowerleg01.L','lowerleg01.R']
# Local axis matches Human Studio XYZ rotations. Z shoulders/hips; X elbow/knee flexion.
AXES=[2,2,0,0,2,2,0,0,0,0]
def deform(params):
 angles=np.zeros((len(B),3))
 for j,a,v in zip(JOINTS,AXES,params):angles[NI[j],a]=v
 LR=R0@Rotation.from_euler('XYZ',angles,degrees=True).as_matrix(); G=np.zeros_like(Q); W=np.zeros_like(H)
 for i in ORDER:
  p=P[i];G[i]=G[p]@LR[i] if p>=0 else LR[i];W[i]=W[p]+G[p]@L[i] if p>=0 else L[i]
 M=G@Q.transpose(0,2,1);offset=W-np.einsum('nij,nj->ni',M,H)
 out=np.zeros_like(V)
 for k in range(4):out+=SW[:,k,None]*(np.einsum('nij,nj->ni',M[SK[:,k]],V)+offset[SK[:,k]])
 floor=out[IDS,1].min();out[:,1]-=floor;W[:,1]-=floor
 return out,W

def silhouette(v,view,size=(768,1024)):
 c=CAM['views'][view];w,h=size;s=c['px_per_cm']*w/CAM['width'];cx,cy=c['center_cm'];horizontal=v[:,2] if c['axis']=='side' else v[:,0]*(-1 if c['axis']=='back' else 1)
 xy=np.column_stack([(horizontal-cx)*s+w/2,h/2-(v[:,1]-cy)*s]);m=np.zeros((h,w),np.uint8)
 for face in F:cv2.fillConvexPoly(m,np.rint(xy[face]).astype('int32'),255)
 return m

def segment(path):
 im=cv2.imread(str(path));im=cv2.resize(im,(768,1024),interpolation=cv2.INTER_AREA)
 # Near-white studio background; largest foreground component excludes detached shadows.
 lab=cv2.cvtColor(im,cv2.COLOR_BGR2LAB);dist=np.linalg.norm(lab.astype(float)-np.median(np.concatenate([lab[:35].reshape(-1,3),lab[-35:].reshape(-1,3)]),axis=0),axis=2)
 initial=np.full(im.shape[:2],cv2.GC_PR_BGD,np.uint8);initial[dist>28]=cv2.GC_PR_FGD;initial[dist>70]=cv2.GC_FGD;initial[:20]=cv2.GC_BGD;initial[-20:]=cv2.GC_BGD;initial[:,:18]=cv2.GC_BGD;initial[:,-18:]=cv2.GC_BGD
 cv2.grabCut(im,initial,None,np.zeros((1,65)),np.zeros((1,65)),4,cv2.GC_INIT_WITH_MASK);m=np.isin(initial,[1,3]).astype('uint8')*255
 n,labels,stats,_=cv2.connectedComponentsWithStats(m);i=1+np.argmax(stats[1:,cv2.CC_STAT_AREA]);m=(labels==i).astype('uint8')*255
 return im,m

def metrics(a,b,roi=None):
 a=a>0;b=b>0
 if roi is not None:a&=roi;b&=roi
 inter=(a&b).sum();un=(a|b).sum();edges=[]
 for m in [a,b]:edges.append(cv2.morphologyEx(m.astype('uint8'),cv2.MORPH_GRADIENT,np.ones((3,3),np.uint8))>0)
 distances=np.concatenate([cv2.distanceTransform((~edges[0]).astype('uint8'),cv2.DIST_L2,5)[edges[1]],cv2.distanceTransform((~edges[1]).astype('uint8'),cv2.DIST_L2,5)[edges[0]]])
 return {'iou':float(inter/max(un,1)),'dice':float(2*inter/max(a.sum()+b.sum(),1)),'symmetric_contour_mean_px':float(distances.mean()),'symmetric_contour_p95_px':float(np.percentile(distances,95))}

def main():
 images=Path(sys.argv[1]); out=HERE/'fit';out.mkdir(exist_ok=True);refs={};manifest={'camera_sha256':hashlib.sha256((HERE/'camera.json').read_bytes()).hexdigest(),'source_model_state_sha256':hashlib.sha256((HERE/'initial-state.json').read_bytes()).hexdigest()}
 for view in [v for v in ['front','side','back'] if (images/(v+'.png')).exists()]:
  p=images/(view+'.png');frozen=HERE/'references-generation-2'/(view+'-reference-mask.png');im=cv2.resize(cv2.imread(str(p)),(768,1024));m=cv2.imread(str(frozen),0) if frozen.exists() else segment(p)[1];cv2.imwrite(str(out/(view+'-reference-mask.png')),m);cv2.imwrite(str(out/(view+'-segmentation.png')),np.where(m[:,:,None]>0,im,(im*.3).astype('uint8')));refs[view]=m;manifest[view]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mask_sha256':hashlib.sha256(m.tobytes()).hexdigest()}
 (out/'frozen-references.json').write_text(json.dumps(manifest,indent=2))
 # Limb-region garment envelope constrains skeletal pose only. Covered torso/head excluded; this is not a bare-body silhouette.
 yy,xx=np.mgrid[:1024,:768];roi=(yy>640)&(yy<900) | ((yy>360)&(yy<515)&((xx<245)|(xx>525)))
 cv2.imwrite(str(out/'pose-fit-roi.png'),roi.astype('uint8')*255)
 small={v:cv2.resize(m,(384,512),interpolation=cv2.INTER_NEAREST)>0 for v,m in refs.items()};rsmall=cv2.resize(roi.astype('uint8'),(384,512),interpolation=cv2.INTER_NEAREST)>0
 landmarks_path=images/'landmarks.json';landmarks=json.loads(landmarks_path.read_text())['points'] if landmarks_path.exists() else []
 if landmarks_path.exists():
  (out/'frozen-landmarks.json').write_text(landmarks_path.read_text())
  manifest['manual_landmarks_sha256']=hashlib.sha256(landmarks_path.read_bytes()).hexdigest()
  (out/'frozen-references.json').write_text(json.dumps(manifest,indent=2))
 history=[]
 def landmark_errors(world):
  rows=[]
  for point in landmarks:
   if point['view'] not in ['front','side']:continue
   c=CAM['views'][point['view']];v=world[NI[point['joint']]];horizontal=v[2] if c['axis']=='side' else v[0];u=(horizontal-c['center_cm'][0])*c['px_per_cm']+384;vv=512-(v[1]-c['center_cm'][1])*c['px_per_cm'];rows.append(float(np.linalg.norm(np.array([u,vv])-point['pixel'])))
  return rows
 def objective(p):
  v,world=deform(p);loss=0
  for view in ['front','side']:
   m=silhouette(v,view,(384,512))>0;ref=small[view];loss+=.10*np.logical_xor(m,ref)[rsmall].mean()
  errs=landmark_errors(world)
  if errs:loss+=np.mean(np.square(np.array(errs)/50))
  loss+=.000004*np.square(p).sum();history.append({'parameters_degrees':list(map(float,p)),'loss':float(loss)});return loss
 bounds=[(-14,14),(-14,14),(-28,28),(-28,28),(-10,10),(-10,10),(-12,12),(-12,12),(-15,5),(-15,5)]
 result=minimize(objective,np.zeros(len(JOINTS)),method='Powell',bounds=bounds,options={'maxiter':7,'xtol':.15,'ftol':.00005,'maxfev':520})
 best=min(history,key=lambda x:x['loss']);p=np.round(np.array(best['parameters_degrees']),1);v,joints=deform(p);state=json.loads(json.dumps(STATE))
 for name,axis,value in zip(JOINTS,AXES,p):state['poseDegrees'][name][axis]=round(float(value),1)
 (HERE/'final-state.json').write_text(json.dumps(state,indent=2));metricsout={}
 for view in refs:
  metricsout[view]={}
  for label,par in [('initial',np.zeros(len(JOINTS))),('final',p)]:
   mesh,_=deform(par);m=silhouette(mesh,view);ref=refs[view];cv2.imwrite(str(out/(view+'-'+label+'-mask.png')),m)
   overlay=np.full((1024,768,3),245,np.uint8);overlay[(ref>0)&(m>0)]=[65,170,65];overlay[(ref>0)&(m==0)]=[190,80,230];overlay[(ref==0)&(m>0)]=[220,205,40];cv2.imwrite(str(out/(view+'-'+label+'-overlay.png')),overlay)
   metricsout[view][label]={'full_clothed_envelope_comparison':metrics(ref,m),'clothed_limb_pose_roi':metrics(ref,m,roi)}
 metricsout['protocol']={'optimized_views':['front','side'],'held_out_view':'back','shape':'fixed prior; no garment-to-barebody circumference inference','pose_parameters':JOINTS,'camera':'camera calibration separately recorded in camera-calibration.json, then frozen model/camera.json for initial/final pose comparison','mask_resolution':[768,1024],'fit_search_resolution':[384,512],'reference_type':'AI generated, internal consistency only','manual_landmark_count':len(landmarks),'initial_manual_landmark_errors_px':landmark_errors(deform(np.zeros(len(JOINTS)))[1]),'final_manual_landmark_errors_px':landmark_errors(joints),'optimization_evaluations':len(history),'initial_loss':history[0]['loss'],'best_loss':best['loss']}
 (out/'metrics.json').write_text(json.dumps(metricsout,indent=2));(out/'optimization-history.json').write_text(json.dumps(history,indent=2));print(json.dumps(metricsout,indent=2))
if __name__=='__main__':main()
