#!/usr/bin/env python3
import json,struct,hashlib,sys
from pathlib import Path
from collections import Counter
import numpy as np
P=Path(__file__).resolve().parent;root=P.parents[2];prefix=sys.argv[1] if len(sys.argv)>1 else 'initial'
asset=root/'web/human-studio/assets/human.json';data=json.loads(asset.read_text());state=json.loads((P/(prefix+'-state.json')).read_text());v=[];f=[]
for l in (P/(prefix+'-neutral.obj')).read_text().splitlines():
 t=l.split()
 if t and t[0]=='v':v.append(list(map(float,t[1:])))
 if t and t[0]=='f':f.append([int(i)-1 for i in t[1:]])
v=np.array(v);f=np.array(f);edges=Counter(tuple(sorted((int(a),int(b)))) for tri in f for a,b in zip(tri,np.roll(tri,-1)))
raw=(P/(prefix+'-posed.glb')).read_bytes();n,kind=struct.unpack_from('<II',raw,12);g=json.loads(raw[20:20+n]);bn,bk=struct.unpack_from('<II',raw,20+n);binary=raw[28+n:28+n+bn]
def readacc(i):
 a=g['accessors'][i];b=g['bufferViews'][a['bufferView']];dt={5126:'<f4',5123:'<u2',5125:'<u4'}[a['componentType']];k={'VEC3':3,'VEC4':4,'MAT4':16,'SCALAR':1}[a['type']];return np.frombuffer(binary,dtype=dt,count=a['count']*k,offset=b.get('byteOffset',0)+a.get('byteOffset',0)).reshape(a['count'],k)
prim=g['meshes'][0]['primitives'][0];pos=readacc(prim['attributes']['POSITION']);skin=g['skins'][0];inv=readacc(skin['inverseBindMatrices']);scales=[node.get('scale') if node.get('scale') else np.linalg.norm(np.array(node['matrix']).reshape(4,4,order='F')[:3,:3],axis=0).tolist() for node in g['nodes'] if node.get('scale') or node.get('matrix')]
report={'verdict':'PASS' if np.isfinite(v).all() and len(v)==13380 and len(f)==26756 and max(edges.values())<=2 and state['asset']==hashlib.sha256(asset.read_bytes()).hexdigest() and len(skin['joints'])==163 and any(np.allclose(scale,[.01,.01,.01]) for scale in scales) else 'FAIL','vertices':len(v),'triangles':len(f),'boundary_edges':sum(n==1 for n in edges.values()),'nonmanifold_edges':sum(n>2 for n in edges.values()),'finite_surface':bool(np.isfinite(v).all()),'obj_bounds_cm':{'min':v.min(0).tolist(),'max':v.max(0).tolist()},'glb_actual_skin_joints':len(skin['joints']),'glb_position_vertices':len(pos),'glb_node_scales_distinct':sorted({tuple(round(v,8) for v in scale) for scale in scales}),'glb_world_scale_to_m':.01,'glb_scale_is_present':any(np.allclose(s,[.01,.01,.01]) for s in scales),'glb_actual_inverse_bind_count':len(inv),'asset_sha256':state['asset'],'limits':['Topology check allows anatomical openings; does not claim closed watertight solid.','No physical tissue, joint collision or cloth validation.']}
(P/(prefix+'-geometry-audit.json')).write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
