"""Actual depth-aware original-photo pose diagnostic. Main final untouched."""
import importlib.util,json,cv2,numpy as np,subprocess,shutil
from pathlib import Path
from scipy.spatial.transform import Rotation
from scipy.optimize import least_squares
P=Path(__file__).resolve().parent;out=P/'original-reference';old=out/'iteration-2';old.mkdir(exist_ok=True)
s=importlib.util.spec_from_file_location('body',P/'fit-generated.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);state=json.loads((old/'state.json').read_text());camera=json.loads((out/'camera.json').read_text());c=camera['views']['front'];W,H=camera['width'],camera['height'];points=json.loads((out/'manual-landmarks.json').read_text())['points'];baseangles=np.array([state['poseDegrees'][b['name']] for b in m.B]);keys=[(j,a) for j in ['upperarm01.L','upperarm01.R','lowerarm01.L','lowerarm01.R','wrist.L','wrist.R'] for a in range(3)];start=np.array([state['poseDegrees'][j][a] for j,a in keys]);lower=[];upper=[]
for j,a in keys:
 if j.startswith('wrist'):bounds=(-60,60)
 elif j.startswith('upperarm'):bounds=((-85,90),(-105,105),(-70,70))[a]
 elif j.endswith('.L'):bounds=((-100,100),(-110,110),(-145,25))[a]
 else:bounds=((-100,100),(-110,110),(-25,145))[a]
 lower.append(bounds[0]);upper.append(bounds[1])

def forward(p,angles_override=None):
 angles=baseangles.copy() if angles_override is None else angles_override.copy()
 if angles_override is None:
  for (j,a),v in zip(keys,p):angles[m.NI[j],a]=v
 LR=m.R0@Rotation.from_euler('XYZ',angles,degrees=True).as_matrix();G=np.zeros_like(m.Q);world=np.zeros_like(m.H)
 for i in m.ORDER:
  parent=m.P[i];G[i]=G[parent]@LR[i] if parent>=0 else LR[i];world[i]=world[parent]+G[parent]@m.L[i] if parent>=0 else m.L[i]
 return world,G,angles

def vertices(world,G):
 matrices=G@m.Q.transpose(0,2,1);offset=world-np.einsum('nij,nj->ni',matrices,m.H);v=np.zeros_like(m.V)
 for k in range(4):v+=m.SW[:,k,None]*(np.einsum('nij,nj->ni',matrices[m.SK[:,k]],m.V)+offset[m.SK[:,k]])
 return v

def project(q):return np.array([(q[0]-c['center_cm'][0])*c['px_per_cm']+W/2,H/2-(q[1]-c['center_cm'][1])*c['px_per_cm']])
world,G,_=forward(start);v=vertices(world,G);arm_names=[i for i,b in enumerate(m.B) if b['name'].startswith(('upperarm','lowerarm','wrist','finger','metacarpal'))];armweight=np.isin(m.SK,arm_names)*m.SW;torsofaces=m.F[np.all(armweight.sum(1)[m.F]<.3,axis=1)]
spec=importlib.util.spec_from_file_location('raster',P.parents[1]/'anatomical-skill-evals-20261117/fixtures/render_mesh.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r);gridcam={'width':280,'height':200,'depth_range_cm':[-60,80],'views':{'front':{'axis':'front','px_per_cm':4,'center_cm':[0,115]}}};_,_,_,depth=r.raster(v,torsofaces,gridcam,'front');np.save(out/'torso-front-depth-cm.npy',depth.astype('float32'));cv2.imwrite(str(out/'torso-front-depth-valid.png'),np.isfinite(depth).astype('uint8')*255)
def frontdepth(q):
 x=int(round(q[0]*4+140));y=int(round(100-(q[1]-115)*4));x=np.clip(x,0,279);y=np.clip(y,0,199);d=depth[y,x]
 if not np.isfinite(d):
  row=depth[y];d=np.max(row[np.isfinite(row)]) if np.isfinite(row).any() else 10.
 return float(d)

def palminfo(world,side):
 wrist=world[m.NI['wrist.'+side]];mid=world[m.NI['finger3-1.'+side]];a=world[m.NI['finger2-1.'+side]]-wrist;b=world[m.NI['finger5-1.'+side]]-wrist;normal=np.cross(a,b);normal/=max(np.linalg.norm(normal),1e-12);direction=mid-wrist;direction/=max(np.linalg.norm(direction),1e-12);return wrist,mid,normal,direction
forward_depth={}
for side in ['L','R']:
 shoulder=world[m.NI['upperarm01.'+side]];ep=next(p['pixel'] for p in points if p.get('joint')=='lowerarm01.'+side);wp=next(p['pixel'] for p in points if p.get('joint')=='wrist.'+side)
 ex=(ep[0]-W/2)/c['px_per_cm']+c['center_cm'][0];ey=c['center_cm'][1]-(ep[1]-H/2)/c['px_per_cm'];wx=(wp[0]-W/2)/c['px_per_cm']+c['center_cm'][0];wy=c['center_cm'][1]-(wp[1]-H/2)/c['px_per_cm']
 l1=np.linalg.norm(m.H[m.NI['lowerarm01.'+side]]-m.H[m.NI['upperarm01.'+side]]);l2=np.linalg.norm(m.H[m.NI['wrist.'+side]]-m.H[m.NI['lowerarm01.'+side]])
 ez=shoulder[2]+np.sqrt(max(l1*l1-(ex-shoulder[0])**2-(ey-shoulder[1])**2,0));forward_depth[side]=ez+np.sqrt(max(l2*l2-(wx-ex)**2-(wy-ey)**2,0))
limbpoints=[p for p in points if p.get('joint','').startswith(('wrist','lowerarm','upperarm'))];count=0

def residual(p):
 global count;count+=1;world,G,angles=forward(p);rows=[]
 for point in limbpoints:
  weight=1.0 if point['joint'].startswith('wrist') else 1.0 if point['joint'].startswith('lowerarm') else .18;rows.extend((project(world[m.NI[point['joint']]])-point['pixel'])/18*weight)
 mids=[]
 for side in ['L','R']:
  wrist,mid,normal,direction=palminfo(world,side);mids.append(mid);target=np.array([(-1 if side=='L' else 1),(-.1 if side=='L' else .1),(.6 if side=='L' else -.6)]);target/=np.linalg.norm(target);rows.extend((direction-target)*2);normal_target=np.array([0.,0.,1 if side=='L' else -1]);normal_target-=np.dot(normal_target,target)*target;normal_target/=np.linalg.norm(normal_target);rows.extend((normal-normal_target)*1.1);rows.append((wrist[2]-forward_depth[side])/3)
  for name in ['wrist.','finger2-1.','finger3-1.','finger4-1.','finger5-1.','finger3-2.','finger3-3.']:
   q=world[m.NI[name+side]];d=frontdepth(q);rows.append(max(d+1.5-q[2],0)/3)
  # Forearm segment cannot run into the torso. Exceeding front depth is allowed; no inferred physical contact.
  elbow=world[m.NI['lowerarm01.'+side]]
  for alpha in [.25,.5,.75]:
   q=elbow*(1-alpha)+wrist*alpha
   if abs(q[0])<22:rows.append(max(frontdepth(q)+1-q[2],0)/3)
   else:rows.append(0.)
  rows.append(max(wrist[2]-frontdepth(wrist)-30,0)/20);wrist_degrees=angles[m.NI['wrist.'+side]];rotation_angle=Rotation.from_euler('XYZ',wrist_degrees,degrees=True).magnitude()*180/np.pi;rows.append(max(rotation_angle-60,0)/12)
 # Both hands must meet in3D, not merely overlap in2D at unrelated depths.
 rows.append((mids[0][2]-mids[1][2])/8);rows.append(max(np.linalg.norm(mids[0]-mids[1])-12,0)/6);rows.append(max(5-np.linalg.norm(mids[0]-mids[1]),0)/3)
 regular=np.array([.018 if j.startswith('wrist') else .002 for j,a in keys]);rows.extend((p-start)*regular);return rows
best=None
for seed_id,seed in enumerate([start,np.clip(start+np.array([0,25,0,0,-25,0,20,20,0,-20,-20,0,0,0,0,0,0,0]),lower,upper)]):
 result=least_squares(residual,seed,bounds=(lower,upper),max_nfev=180,ftol=1e-7,xtol=1e-7);loss=float(np.square(residual(result.x)).sum())
 if best is None or loss<best[0]:best=(loss,result)
params=np.round(best[1].x,1);world,G,angles=forward(params)
# Curl fingers mildly toward the abdomen in actual world-space hinge planes.
for side in ['L','R']:
 for finger in [2,3,4,5]:
  for segment,deg in [(1,6),(2,12),(3,6)]:
   world,G,_=forward(params,angles);name=f'finger{finger}-{segment}.{side}';i=m.NI[name];direction=G[i][:,1];axis=np.cross(direction,np.array([0,0,-1.]));axis/=max(np.linalg.norm(axis),1e-12);local_axis=G[i].T@axis;angles[i]=Rotation.from_rotvec(local_axis*np.deg2rad(deg)).as_euler('XYZ',degrees=True)
 # Thumb lightly opposes rather than a precision grasp, which is unobservable.
 for segment,deg in [(1,5),(2,10),(3,5)]:
  world,G,_=forward(params,angles);i=m.NI[f'finger1-{segment}.{side}'];direction=G[i][:,1];axis=np.cross(direction,[0,0,-1]);axis/=max(np.linalg.norm(axis),1e-12);angles[i]=Rotation.from_rotvec((G[i].T@axis)*np.deg2rad(deg)).as_euler('XYZ',degrees=True)
angles=np.round(angles,1);world,G,_=forward(params,angles);candidate=json.loads(json.dumps(state));candidate['poseDegrees']={b['name']:angles[i].tolist() for i,b in enumerate(m.B)};(out/'state.json').write_text(json.dumps(candidate,indent=2));subprocess.run(['node',str(P/'export-pose.mjs'),str(out/'state.json'),str(out/'posed'),'--glb'],check=True,stdout=subprocess.DEVNULL)
# Actual front andbothside views. Right-facing side shows camera-axis depth explicitly.
cam=json.loads(json.dumps(camera));cam['views']['side']={'axis':'side','px_per_cm':c['px_per_cm'],'center_cm':[10,c['center_cm'][1]]};cam['views']['back']={'axis':'back','px_per_cm':c['px_per_cm'],'center_cm':[c['center_cm'][0],c['center_cm'][1]]};(out/'inspection-camera.json').write_text(json.dumps(cam,indent=2));subprocess.run(['python',str(P.parents[1]/'anatomical-skill-evals-20261117/fixtures/render_mesh.py'),'--mesh',str(out/'posed.obj'),'--camera',str(out/'inspection-camera.json'),'--joints',str(out/'posed-joints.json'),'--out',str(out/'renders')],check=True)
# Quantify actual hand surface vs actual torso z-buffer; point error is supplementary.
v=vertices(world,G);checks={};hand_ids={}
for side in ['L','R']:
 handbones=[i for i,b in enumerate(m.B) if b['name'].startswith(('wrist.'+side,'finger')) and b['name'].endswith('.'+side)];ids=np.intersect1d(m.IDS,np.where((np.isin(m.SK,handbones)*m.SW).sum(1)>.55)[0]);hand_ids[side]=ids;clearance=np.array([q[2]-frontdepth(q) for q in v[ids]]);wrist,mid,n,d=palminfo(world,side);checks[side]={'hand_surface_vertices':len(ids),'hand_surface_torso_front_clearance_cm_min':float(clearance.min()),'hand_surface_torso_front_clearance_cm_p05':float(np.percentile(clearance,5)),'hand_surface_fraction_in_front_of_torso':float(np.mean(clearance>0)),'wrist_world_cm':wrist.tolist(),'palm_center_world_cm':mid.tolist(),'palm_direction_world':d.tolist(),'palm_cross_normal_world':n.tolist(),'wrist_euler_degrees':candidate['poseDegrees']['wrist.'+side]}
photo=cv2.imread(str(P.parent/'reference/original-product.jpg'));ref=cv2.imread(str(out/'reference-mask.png'),0);m.CAM=camera;im=photo.copy();mask=m.silhouette(v,'front',(W,H));edge=cv2.morphologyEx(mask,cv2.MORPH_GRADIENT,np.ones((3,3),np.uint8))>0;im[edge]=[255,220,0];errors=[]
for point in points:
 q=v[point['vertex']] if 'vertex' in point else world[m.NI[point['joint']]];pred=project(q);obs=np.array(point['pixel']);name='nose_vertex201' if 'vertex' in point else point['joint'];errors.append({'landmark':name,'error_px':float(np.linalg.norm(pred-obs))});cv2.circle(im,tuple(np.rint(pred).astype(int)),6,(255,220,0),2);cv2.circle(im,tuple(obs),7,(255,0,255),2);cv2.line(im,tuple(np.rint(pred).astype(int)),tuple(obs),(255,0,255),1)
cv2.rectangle(im,(0,0),(W,50),(245,245,245),-1);cv2.putText(im,'ORIGINAL depth-constrained hands',(15,33),cv2.FONT_HERSHEY_SIMPLEX,.8,(20,20,20),1,cv2.LINE_AA);cv2.imwrite(str(out/'depth-constrained-hands-overlay.png'),im);before=cv2.imread(str(old/'refined_head_and_arms-overlay.png'));cv2.imwrite(str(out/'before-after.png'),np.concatenate([before,im],axis=1));metrics=json.loads((old/'metrics.json').read_text());metrics['previous_candidate']=metrics['refined_head_and_arms'];metrics['refined_head_and_arms']={'manual_joint_errors_px':errors,'cropped_clothed_envelope':m.metrics(ref,mask),'actual_hand_surface_depth':checks};metrics['protocol'].update(previous_phase_key='previous_candidate',selected_phase_key='refined_head_and_arms',phase_label='Forward-IK branch iteration5 diagnostic, original photo only',objective_calls_iteration3=count,solver_nfev_iteration3=best[1].nfev,same_shape_as_main_final=candidate['morphWeights']==json.loads((P/'final-state.json').read_text())['morphWeights'],actual_torso_depth='Source-skinned torso-only triangles rasterized to torso-front-depth-cm.npy; joints and actual hand surfaces compared against its front envelope',finger_pose='Mild actual joint flexion into abdomen direction; approximate grasp only, no cloth/contact simulation',pose_status='PENDING visual review of actual front/side hand shape and depth',selected_pose_degrees={j:a for j,a in candidate['poseDegrees'].items() if any(a)});(out/'metrics.json').write_text(json.dumps(metrics,indent=2));(out/'hand-depth-check.json').write_text(json.dumps({'checks':checks,'both_palms_distance_cm':float(np.linalg.norm(palminfo(world,'L')[1]-palminfo(world,'R')[1])),'objective_calls':count,'visual_review_required':True},indent=2));print(json.dumps({'checks':checks,'joint_errors':errors},indent=2))
