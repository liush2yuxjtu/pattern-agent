# Real anatomical body and actual generated-photo fit

The selected candidate is an actual CC0 MakeHuman adult-female surface with13,380 vertices,26,756 triangles and163 bones, built using existing Human Studio `body-engine.js` and the matching asset `a75b6a2d59b2fa60ea29393e380182174627ba66d0993c649c8c571a6ccecda6`. It is not a synthetic loft or primitive proxy.

Body shape remains the user-authorized prior: height170 / bust90 / waist72 / hips96 / shoulders37cm. All12 dimension controls remain editable, as do all163 bone rotations. Independently reconstructed neutral measurements match those targets with maximum residual0.00004044cm. These are model dimensions, not recovered measurements of the photographed woman. Red long sleeves and loose trousers conceal the bare-body boundary.

## Actual resources and exports

- `final-state.json`: Human Studio-compatible complete state,12 dimensions, exact morph coefficients,163 pose entries, version/asset fingerprint. Import it in Human Studio to adjust real geometry.
- `final-neutral.obj`: actual compact neutral surface in centimetres, Y up, for neutral measurement.
- `final-posed.obj`: actual source-compatible four-weight linear-blend skinned surface, centimetres.
- `final-posed.glb`: actual skin/163-bone rig; explicit0.01 world matrix converts cm to metres.
- `final-posed-joints.json`: actual posed world bone heads.
- `final-renders/`: normal-color actual triangle renders front/side/back/upper-body closeup; front-camera skeleton projection; real Z-buffer/rawdepth.npy, depth-valid.png, masks and projected joint metadata. All768×1024; these geometry outputs are separate from illustrative generated pose/depth photographs.
- `neutral-measurements.csv`, `final-independent-check.json`, `final-geometry-check.json`, `final-geometry-audit.json`: independent measurements/export checks.

`initial-*` preserves the original neutral model. `initial-renders/` uses the original generation-guidance camera4.7px/cm centerY85cm. `calibrated-initial-renders/` and `final-renders/` use the same final frozen cameras for fair before/after pose comparison. `camera.json` records those cameras; `iteration-1/camera.json` preserves the original camera. Pose/depth use the calibrated front camera. The generic rasterizer's side mapping is explicitly horizontalZ, depthX; do not infer a calibrated physical photographic camera from it.

## Frozen photographic evidence and annotations

Fresh front/side/back images are1086×1448 native pixels. OpenCV GrabCut ran on uniformly resized768×1024 copies. The images, masks, hashes and resolution are recorded in `fit/frozen-references.json`. Person, clothes, hair and gaps were visually checked; detached floor shadow is excluded. All three final masks are byte-identical to the original iteration1 masks, including held-out back. No references were regenerated or altered to improve scores.

Visible wrist/ankle centers were manually annotated on the actual generated photographs at768×1024. Cuffs and near-side identity introduce uncertainty. `fit/frozen-landmarks.json` records all10 points:6 front/side training points,4 held-out back points. No pose detector ran. `camera-calibration.json` separately records approximate manual neck-base and ankle-height anchors, including uncertainty under hair/collars/cuffs. `fit/*-reference-landmarks-roi.png` shows exact evaluation regions, magenta wrist/ankle points and yellow camera anchors. Annotation precision is not a real-person measurement error bound.

Front+side train one shared3D skeletal pose. Back contributes only independent camera registration anchors; back wrist/ankle pose errors and silhouettes never enter the optimization objective. Shape is fixed throughout.

## Two actual fitting iterations

Iteration1 retained the original generation-guidance camera.316 bounded pose evaluations improved training wrists and front/side IoU, but back IoU regressed0.67895→0.66196 and ankle errors remained large. This failed global consistency; its complete fit/camera/state/mesh/GLB/render evidence is preserved under `iteration-1/`.

Iteration2 first calibrated per-view orthographic scale/translation from neck and ankle-height anchors using the unchanged170cm anatomical prior, then froze those cameras. Actual scales are front4.955254, side5.056826, back5.310755px/cm. This is nuisance registration, not recovery of the physical camera.520 bounded Powell evaluations then adjusted10 real skeletal angle components. Hip sagittal rotation was added to represent ankle placement; shoulders/elbows/hips/knees remain within explicitly bounded modest rotations. Pose skinning is not physics, support/collision or tissue simulation.

Camera-only and pose contributions are separated in `fit/camera-pose-contributions.json`:

| View | Mean joint error, source camera neutral | Camera calibrated neutral | Camera calibrated fitted pose |
|---|---:|---:|---:|
| Front |31.31px|9.57px|1.80px|
| Side |46.06px|22.45px|3.26px|
| Back, held out |38.48px|13.04px|8.37px|

All10 final annotated joint errors are≤11.34px, approximately1.3%ofgenerated full-body height. Final front ankle errors are2.60/2.47px, side2.48px, held-out back2.90/9.70px. These refer to manually annotated generated photographs, not an observed real person's anatomical joints.

Same-camera neutral→fitted full clothed-envelope IoU is front0.81606→0.83201, side0.58913→0.68983, held-out back0.79359→0.81418. Mean symmetric contour distance improves in all three views:5.998→5.273px front,15.389→11.787px side,7.048→6.154px back. Front P95 regresses17.18→20.38px; back P95 regresses17.00→17.18px. All metrics and regressions remain in `fit/metrics.json`. Side remains weakest. Hair, garment ease, hand articulation and generated proportions explain residual differences; full-clothing IoU is not bare-body accuracy.

`fit/{front,side,back}-before-after.png` overlays actual anatomical mesh contours/rig on actual photos. Cyan=model, magenta=manual landmarks/error vectors. `fit/all-before-after.png` combines them. The categorical mask overlays use green=overlap, pink=reference-only, cyan=model-only.

## Verification and reproduction

`final-geometry-check.json` reports PASS for geometry/evidence consistency: actual Python LBS versus independent source Three.js export differs by at most0.00001235cm; all frozen masks are unchanged; exact final surface masks match generic rasterization;117,681 front depth pixels are valid and finite. `final-geometry-audit.json` checks finite anatomy,0 boundary/nonmanifold edges, actual163-joint GLB and explicit0.01 matrix scale. These passes do not validate real-person dimensions, physical garment fit or tissue/cloth simulation.

From repository root:

```
node work/product-red-pointelle-20261117/model/build-model.mjs
python work/product-red-pointelle-20261117/model/calibrate-camera.py
OPENBLAS_NUM_THREADS=1 python work/product-red-pointelle-20261117/model/fit-generated.py work/product-red-pointelle-20261117/images
python work/product-red-pointelle-20261117/model/evaluate-heldout.py
python work/product-red-pointelle-20261117/model/compare-camera-contribution.py
python work/product-red-pointelle-20261117/model/photographic-overlays.py
node work/product-red-pointelle-20261117/model/export-pose.mjs work/product-red-pointelle-20261117/model/final-state.json work/product-red-pointelle-20261117/model/final-posed --glb
python work/anatomical-skill-evals-20261117/fixtures/render_mesh.py --mesh work/product-red-pointelle-20261117/model/final-posed.obj --camera work/product-red-pointelle-20261117/model/camera.json --joints work/product-red-pointelle-20261117/model/final-posed-joints.json --out work/product-red-pointelle-20261117/model/final-renders
python work/product-red-pointelle-20261117/model/verify-candidate.py
python work/product-red-pointelle-20261117/model/audit-model.py final
```

This establishes internal consistency of actual generated wearing views and a real adjustable anatomical model. The single original cropped garment photo and AI-inferred views cannot establish independent real-person multiview body accuracy. No physical garment fit was run.
