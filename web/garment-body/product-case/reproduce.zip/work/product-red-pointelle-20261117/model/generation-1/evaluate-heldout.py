import importlib.util,numpy as np,cv2,json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('fit',P/'fit-generated.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
path=P.parent/'images/back.png';im=cv2.resize(cv2.imread(str(path)),(768,1024));ref=cv2.imread(str(P/'iteration-1/fit/back-reference-mask.png'),0);out=P/'fit';cv2.imwrite(str(out/'back-reference-mask.png'),ref);cv2.imwrite(str(out/'back-segmentation.png'),np.where(ref[:,:,None]>0,im,(im*.3).astype('uint8')))
manifest=json.loads((out/'frozen-references.json').read_text());manifest['back']={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'mask_sha256':hashlib.sha256(ref.tobytes()).hexdigest(),'role':'held out, never included in optimizer'};(out/'frozen-references.json').write_text(json.dumps(manifest,indent=2))
state=json.loads((P/'final-state.json').read_text());par=np.array([state['poseDegrees'][j][a] for j,a in zip(m.JOINTS,m.AXES)]);report=json.loads((out/'metrics.json').read_text());report['back']={};roi=cv2.imread(str(out/'pose-fit-roi.png'),0)>0
for label,p in [('initial',np.zeros(len(m.JOINTS))),('final',par)]:
 v,_=m.deform(p);mask=m.silhouette(v,'back');cv2.imwrite(str(out/f'back-{label}-mask.png'),mask);overlay=np.full((1024,768,3),245,np.uint8);overlay[(ref>0)&(mask>0)]=[65,170,65];overlay[(ref>0)&(mask==0)]=[190,80,230];overlay[(ref==0)&(mask>0)]=[220,205,40];cv2.imwrite(str(out/f'back-{label}-overlay.png'),overlay);report['back'][label]={'full_clothed_envelope_comparison':m.metrics(ref,mask),'clothed_limb_pose_roi':m.metrics(ref,mask,roi)}
(out/'metrics.json').write_text(json.dumps(report,indent=2));print(json.dumps(report['back'],indent=2))
