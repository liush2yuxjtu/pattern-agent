import importlib.util,json,cv2,numpy as np
from pathlib import Path
P=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('actualfit',P/'fit-generated.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
state=json.loads((P/'final-state.json').read_text());par=np.array([state['poseDegrees'][j][a] for j,a in zip(m.JOINTS,m.AXES)]);landmarks=json.loads((P.parent/'images/landmarks.json').read_text())['points'];pairs=[]
for view in ['front','side','back']:
 photo=P.parent/'images'/f'{view}.png'
 if not photo.exists():continue
 ims=[]
 for label,p in [('initial',np.zeros(len(m.JOINTS))),('final',par)]:
  im=cv2.resize(cv2.imread(str(photo)),(768,1024));v,w=m.deform(p);mask=m.silhouette(v,view);edge=cv2.morphologyEx(mask,cv2.MORPH_GRADIENT,np.ones((3,3),np.uint8))>0;im[edge]=[255,220,0]
  c=m.CAM['views'][view]
  def proj(j):
   q=w[m.NI[j]];x=q[2] if c['axis']=='side' else q[0]*(-1 if c['axis']=='back' else 1);return (int(round((x-c['center_cm'][0])*c['px_per_cm']+384)),int(round(512-(q[1]-c['center_cm'][1])*c['px_per_cm'])))
  edges=[('upperarm01.L','lowerarm01.L'),('lowerarm01.L','wrist.L'),('upperarm01.R','lowerarm01.R'),('lowerarm01.R','wrist.R'),('upperleg01.L','lowerleg01.L'),('lowerleg01.L','foot.L'),('upperleg01.R','lowerleg01.R'),('lowerleg01.R','foot.R')]
  for a,b in edges:cv2.line(im,proj(a),proj(b),(255,180,0),2)
  for point in landmarks:
   if point['view']!=view:continue
   pred=proj(point['joint']);obs=tuple(point['pixel']);cv2.circle(im,pred,5,(255,220,0),2);cv2.circle(im,obs,6,(255,0,255),2);cv2.line(im,pred,obs,(255,0,255),1)
  cv2.rectangle(im,(0,0),(768,51),(250,250,250),-1);cv2.putText(im,f'{view} {label} / cyan mesh, magenta manual',(15,33),cv2.FONT_HERSHEY_SIMPLEX,.65,(30,30,30),1,cv2.LINE_AA);cv2.imwrite(str(P/'fit'/f'{view}-{label}-photo-overlay.png'),im);ims.append(im)
 pair=np.concatenate(ims,axis=1);cv2.imwrite(str(P/'fit'/f'{view}-before-after.png'),pair);pairs.append(cv2.resize(pair,(1152,768)))
cv2.imwrite(str(P/'fit'/'all-before-after.png'),np.concatenate(pairs,axis=0))
