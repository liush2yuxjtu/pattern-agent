import json,importlib.util,numpy as np,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('fit',P/'iteration-1/fit-generated.py')
# Load current module for rest bone heads; it reads only matching actual asset.
s=importlib.util.spec_from_file_location('fit',P/'fit-generated.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
anchors={'front':{'neck_pixel':[384,232],'ankle_mid_pixel':[382,915]},'side':{'neck_pixel':[374,232],'ankle_mid_pixel':[356,929]},'back':{'neck_pixel':[383,197],'ankle_mid_pixel':[379.5,929]}}
source=json.loads((P/'iteration-1/camera.json').read_text());cal=json.loads(json.dumps(source));rows={}
neck=m.H[m.NI['neck01']];ankle=(m.H[m.NI['foot.L']]+m.H[m.NI['foot.R']])/2
for view,a in anchors.items():
 nx,ny=a['neck_pixel'];ax,ay=a['ankle_mid_pixel'];scale=(ay-ny)/(neck[1]-ankle[1]);centerY=neck[1]+(ny-512)/scale
 horizontal=neck[2] if view=='side' else neck[0]*(-1 if view=='back' else 1);centerX=horizontal-(nx-384)/scale
 assert 4.4<scale<5.6 and 72<centerY<100
 cal['views'][view].update(px_per_cm=float(scale),center_cm=[float(centerX),float(centerY)])
 rows[view]={'manual_anchors':a,'neck_world_cm':neck.tolist(),'ankle_mid_world_cm':ankle.tolist(),'scale_px_per_cm':scale,'center_cm':[centerX,centerY],'horizontal_anchor':'neck only, leaving ankle horizontal discrepancy for pose test','vertical_anchors':'neck and mean ankle heights; same fixed170cm shape prior','annotation_uncertainty':'Manual neck-base location under hair/near collar and ankle centers under cuffs uncertain by several pixels; not detector or observed-person measurements','role':'camera calibration only; back is excluded from shared-pose training'}
cal['views']['pose']=cal['views']['front'].copy();cal['views']['depth']=cal['views']['front'].copy();cal['calibration']={'source':'manual generated-photo stable anchors','record':'camera-calibration.json','shape_prior_cm':170,'frozen_before_pose':True};(P/'camera.json').write_text(json.dumps(cal,indent=2));(P/'camera-calibration.json').write_text(json.dumps({'protocol':'Fit per-view isotropic orthographic scale from neck-to-ankle vertical span and translation from neck projected position; no shape changes. Calibration is nuisance registration, not recovered physical camera. Back calibration independent of pose optimization.','anchors':rows,'source_camera_sha256':hashlib.sha256((P/'iteration-1/camera.json').read_bytes()).hexdigest(),'calibrated_camera_sha256':hashlib.sha256((P/'camera.json').read_bytes()).hexdigest()},indent=2));print(json.dumps(rows,indent=2))
