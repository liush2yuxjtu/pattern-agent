import importlib.util,numpy as np,json,cv2,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('fit',P/'fit-generated.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);state=json.loads((P/'final-state.json').read_text());par=np.array([state['poseDegrees'][j][a] for j,a in zip(m.JOINTS,m.AXES)]);v,w=m.deform(par);obj=np.array([list(map(float,l.split()[1:])) for l in (P/'final-posed.obj').read_text().splitlines() if l.startswith('v ')]);z=np.load(P/'final-renders/rawdepth.npy');valid=cv2.imread(str(P/'final-renders/depth-valid.png'),0)>0;delta=float(np.max(abs(v[m.IDS]-obj)));same={view:bool(np.array_equal(cv2.imread(str(P/'references-generation-2'/f'{view}-reference-mask.png'),0),cv2.imread(str(P/'fit'/f'{view}-reference-mask.png'),0))) for view in ['front','side','back']}
actualmask={view:bool(np.array_equal(cv2.imread(str(P/'final-renders'/f'{view}-mask.png'),0),cv2.imread(str(P/'fit'/f'{view}-final-mask.png'),0))) for view in ['front','side','back']}
report={'verdict':'PASS' if delta<.0001 and np.isfinite(z[valid]).all() and all(same.values()) else 'FAIL','independent_python_vs_source_three_js_lbs_max_error_cm':delta,'vertices':len(obj),'triangles':len(m.F),'frozen_v2_masks_unchanged':same,'source_render_vs_fitting_masks_exact':actualmask,'depth_valid_pixels':int(valid.sum()),'depth_finite_where_valid':bool(np.isfinite(z[valid]).all()),'final_obj_sha256':hashlib.sha256((P/'final-posed.obj').read_bytes()).hexdigest(),'final_state_sha256':hashlib.sha256((P/'final-state.json').read_bytes()).hexdigest(),'camera_sha256':hashlib.sha256((P/'camera.json').read_bytes()).hexdigest(),'scope':'geometry export and frozen-reference consistency; no physical validation or real-person dimensions claim'};(P/'final-geometry-check.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
cal=json.loads((P/'camera-calibration.json').read_text())['anchors'];roi=cv2.imread(str(P/'fit/pose-fit-roi.png'),0)>0;points=json.loads((P.parent/'images/landmarks.json').read_text())['points']
for view in ['front','side','back']:
 im=cv2.resize(cv2.imread(str(P.parent/'images'/f'{view}.png')),(768,1024));sh=im.copy();sh[roi]=(im[roi]*.65+np.array([0,200,255])*.35).astype('uint8')
 for point in points:
  if point['view']==view:
   p=point['pixel'];cv2.circle(sh,tuple(p),6,(255,0,255),2);cv2.putText(sh,point['joint'],(p[0]+8,p[1]-7),cv2.FONT_HERSHEY_SIMPLEX,.42,(190,0,190),1,cv2.LINE_AA)
 for name,point in cal[view]['manual_anchors'].items():
  p=tuple(round(x) for x in point);cv2.drawMarker(sh,p,(0,220,220),cv2.MARKER_CROSS,14,2);cv2.putText(sh,name,(p[0]+8,p[1]+14),cv2.FONT_HERSHEY_SIMPLEX,.42,(0,150,150),1,cv2.LINE_AA)
 cv2.imwrite(str(P/'fit'/f'{view}-reference-landmarks-roi.png'),sh)
