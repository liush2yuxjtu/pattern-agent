import importlib.util,json,cv2,numpy as np,subprocess,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('fit',P/'fit-generated.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);base=json.loads((P/'fixed-M-baseline/final-state.json').read_text());B=m.B;raw=np.array(m.D['vertices'],float).reshape(-1,3);control={c['key']:{branch:np.array(c[branch],float) for branch in ['incr','decr']} for c in m.D['controls']};par=np.array([base['poseDegrees'][j][a] for j,a in zip(m.JOINTS,m.AXES)]);out=P/'shape-fit';out.mkdir(exist_ok=True)
def configure(state):
 V=raw.copy()
 for c,weight in zip(m.D['controls'],state['morphWeights']):
  rows=control[c['key']]['incr' if weight>=0 else 'decr'];V[rows[:,0].astype(int)]+=rows[:,1:]*abs(weight)
 V[:,1]-=V[m.IDS,1].min();m.V=V;m.H=np.array([V[m.D['joints'][b['head']]].mean(0) for b in B]);tails=np.array([V[m.D['joints'][b['tail']]].mean(0) for b in B]);Q=[]
 for h,t in zip(m.H,tails):
  y=t-h;y/=max(np.linalg.norm(y),1e-12);x=np.cross(y,[0,0,1])
  if np.linalg.norm(x)<1e-8:x=np.cross(y,[0,1,0])
  x/=np.linalg.norm(x);Q.append(np.column_stack([x,y,np.cross(x,y)]))
 m.Q=np.array(Q);m.R0=np.array([m.Q[p].T@m.Q[i] if p>=0 else m.Q[i] for i,p in enumerate(m.P)]);m.L=np.array([m.Q[p].T@(m.H[i]-m.H[p]) if p>=0 else m.H[i] for i,p in enumerate(m.P)])
refs={view:cv2.imread(str(P/'references-generation-2'/f'{view}-reference-mask.png'),0) for view in ['front','side','back']};yy,xx=np.mgrid[:1024,:768];rois={'front':(yy>=238)&(yy<=905)&(xx>=270)&(xx<=500),'side':(yy>=245)&(yy<=905)&(xx>=290)&(xx<=465)};fore=(yy>402)&(yy<460)&((xx<225)|(xx>535));dist={v:cv2.distanceTransform((cv2.dilate(refs[v],np.ones((5,5),np.uint8))==0).astype('uint8'),cv2.DIST_L2,5) for v in ['front','side']}
for v,r in rois.items():cv2.imwrite(str(out/(v+'-containment-roi.png')),r.astype('uint8')*255)
keys=['bust','waist','hips','shoulders','upperArm','thigh','calf'];prior=np.array([base['dimensions'][k] for k in keys]);std=np.array([6,6,6,2,3,5,3]);bounds={'bust':(82,98),'waist':(64,80),'hips':(88,104),'shoulders':(33,40),'upperArm':(23,31),'thigh':(46,58),'calf':(30,39)};history=[];cache={}
def score(state):
 configure(state);v,w=m.deform(par);term=0;parts={}
 for view in ['front','side']:
  mask=m.silhouette(v,view)>0;roi=rois[view];excess=mask&roi;loss=float(np.mean(np.minimum(dist[view][excess],20)**2)/100) if excess.any() else 1;parts[view]={'containment_loss':loss,'outside_pixels':int((excess&(dist[view]>0)).sum()),'body_roi_pixels':int(excess.sum())};term+=loss
 # Exposed front forearms only; small equality term, never match loose trousers as naked shape.
 front=m.silhouette(v,'front')>0;bare=float(np.logical_xor(front,refs['front']>0)[fore].mean());regularization=float(.012*np.mean(((np.array([state['dimensions'][k] for k in keys])-prior)/std)**2));loss=term+.04*bare+regularization
 row={'dimensions':state['dimensions'],'loss':loss,'containment':parts,'bare_forearm_xor':bare,'prior_regularization':regularization,'state':state};history.append(row);return row
best=score(base);initial=best;steps=[4,4,4,1,1,4,3]
for iteration in range(3):
 candidates=[]
 for key,step in zip(keys,steps):
  for sign in [-1,1]:
   dims={k:best['dimensions'][k] for k in keys};dims[key]=float(round(np.clip(dims[key]+sign*step,*bounds[key]),1))
   if .64<=dims['waist']/dims['bust']<=.88 and .96<=dims['hips']/dims['bust']<=1.25:candidates.append(dims)
 if iteration==0:candidates += [{'bust':86,'waist':68,'hips':92,'shoulders':35.5,'upperArm':26,'thigh':50,'calf':33},{'bust':84,'waist':66,'hips':90,'shoulders':35,'upperArm':25,'thigh':48,'calf':32}]
 (out/'requests.json').write_text(json.dumps(candidates));subprocess.run(['node',str(P/'shape-candidates.mjs'),str(out/'requests.json'),str(out/'responses.json')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);rows=[score(s) for s in json.loads((out/'responses.json').read_text())];candidate=min(rows,key=lambda r:r['loss']);improvement=best['loss']-candidate['loss']
 if improvement>1e-5:best=candidate
 steps=[x*.5 for x in steps]
 if improvement<1e-5:break
beststate=best['state'];(P/'shape-source-state.json').write_text(json.dumps(beststate,indent=2));(P/'final-state.json').write_text(json.dumps(beststate,indent=2));report={'protocol':{'generation':'generation-2','body_height_fixed_cm':170,'camera_frozen_sha256':hashlib.sha256((P/'camera.json').read_bytes()).hexdigest(),'training_views':['front','side'],'heldout_view':'back','loss':'one-sided naked mesh outside2px-dilated clothing envelope on torso/hip/leg ROIs; leg constraints one-sided only, no garment width equality, weak exposedforearm XOR, regularization toward fixedM','bounds_cm':bounds,'prior_standardization_cm':dict(zip(keys,std.tolist())),'basis':'clothed_envelope_estimate; conditional generated avatar, not real-person measurement','evaluations':len(history)},'initial':initial,'selected':best,'history':history};(out/'optimization.json').write_text(json.dumps(report,indent=2));print(json.dumps({'initial_loss':initial['loss'],'selected_loss':best['loss'],'dimensions':beststate['dimensions'],'evaluations':len(history),'initial_containment':initial['containment'],'final_containment':best['containment']},indent=2))
# Render analytic masks for direct shape-only comparison at unchanged calibrated camera/pose.
metrics={}
for label,state in [('fixed_M',base),('shape_candidate',beststate)]:
 configure(state);v,_=m.deform(par);metrics[label]={}
 for view in refs:
  mask=m.silhouette(v,view);cv2.imwrite(str(out/(view+'-'+label+'-mask.png')),mask);metrics[label][view]=m.metrics(refs[view],mask);im=cv2.resize(cv2.imread(str(P.parent/'images'/f'{view}.png')),(768,1024));edge=cv2.morphologyEx(mask,cv2.MORPH_GRADIENT,np.ones((3,3),np.uint8))>0;im[edge]=[255,220,0];cv2.rectangle(im,(0,0),(768,45),(245,245,245),-1);cv2.putText(im,view+' '+label,(15,30),cv2.FONT_HERSHEY_SIMPLEX,.7,(20,20,20),1,cv2.LINE_AA);cv2.imwrite(str(out/(view+'-'+label+'-overlay.png')),im)
for view in refs:cv2.imwrite(str(out/(view+'-before-after.png')),np.concatenate([cv2.imread(str(out/(view+'-'+label+'-overlay.png'))) for label in ['fixed_M','shape_candidate']],axis=1))
(out/'metrics.json').write_text(json.dumps(metrics,indent=2))
