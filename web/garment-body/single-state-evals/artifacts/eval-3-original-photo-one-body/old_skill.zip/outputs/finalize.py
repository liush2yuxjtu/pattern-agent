from pathlib import Path
import json,hashlib,subprocess,sys,numpy as np
from scipy.spatial.transform import Rotation
O=Path(__file__).resolve().parent;R=next(p for p in O.parents if (p/'web/human-studio/assets/human.json').exists())
def read(n):return json.loads((O/n).read_text())
def write(n,v):(O/n).write_text(json.dumps(v,indent=2))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['camera.json','camera-initial.json']:
 c=read(name);w,h=c['width'],c['height'];rot=Rotation.from_euler('YX',[c['yaw_deg'],c['pitch_deg']],degrees=True).as_matrix();ctr=np.array([*c['center_cm'],0.]);f=c['focal_px'];D=c['distance_cm'];M=np.zeros((3,4));M[0,:3]=f*rot[0]-w/2*rot[2];M[1,:3]=-f*rot[1]-h/2*rot[2];M[2,:3]=-rot[2];M[0,3]=-f*(rot[0]@ctr)+w/2*(D+rot[2]@ctr);M[1,3]=f*(rot[1]@ctr)+h/2*(D+rot[2]@ctr);M[2,3]=D+rot[2]@ctr
 c['world_to_pixel']=M.tolist();c['world_units']='cm';c['matrix_convention']='p=M @ [X,Y,Z,1] column vector; pixel=[p0/p2,p1/p2], origin top-left. Rotation scipy intrinsic YX yaw,pitch in degrees. Perspective depth=D-qz.'
 c['views']={'photo':dict(world_to_pixel=M.tolist(),width=w,height=h,projection='perspective')}
 vc=read('three-view-camera.json')
 for v,spec in vc['views'].items():
  s=spec['px_per_cm'];cx,cy=spec['center_cm'];mm=np.array([[0,0,0,vc['width']/2-s*cx],[0,-s,0,vc['height']/2+s*cy],[0,0,0,1.]])
  mm[0,2 if v=='side' else 0]=-s if v=='back' else s
  c['views'][v]=dict(world_to_pixel=mm.tolist(),width=vc['width'],height=vc['height'],projection='orthographic')
 write(name,c)
s=read('final-state.json');js=read('joints.json');cam=read('camera.json')
for j in js['joints']:
 j['projections']={}
 for v,c in cam['views'].items():
  q=np.array(c['world_to_pixel'])@np.r_[j['position'],1];uv=q[:2]/q[2];j['projections'][v]=dict(pixel=uv.tolist(),in_frame=bool(0<=uv[0]<c['width'] and 0<=uv[1]<c['height']),visibility='in-frame only; occlusion not inferred')
write('joints.json',js)
subprocess.run([sys.executable,str(R/'work/single-state-skill-evals-20261117/skill-old/scripts/inspect_human_state.py'),'--state',str(O/'final-state.json'),'--asset-json',str(R/'web/human-studio/assets/human.json'),'--require-match','--out',str(O/'independent-neutral-check.json')],check=True)
M=read('metrics.json');start=M['source-camera-initial'];final=M['final'];pose=s['poseDegrees'];history=read('parameter-block-history.json')
load='/web/human-studio/?model=/'+str((O/'final-state.json').relative_to(R))
(O/'load-link.txt').write_text('http://127.0.0.1:8769'+load+'\n')
(O/'launch-viewer.sh').write_text('#!/bin/sh\ncd '+str(R)+'\npython3 -m http.server 8769 --bind 127.0.0.1\n')
(O/'viewer.html').write_text('<!doctype html><meta charset="utf-8"><title>One shared anatomical state</title><style>body{font:16px system-ui;max-width:1300px;margin:auto}img{max-width:32%;vertical-align:top}.wide{max-width:48%}</style><h1>Original photograph · one fitted body and pose</h1><p><a href="'+load+'">Open saved state in actual Human Studio</a> · <a href="final-state.json">Final state</a> · <a href="report.md">Report</a></p><img src="front.png"><img src="side.png"><img src="back.png"><p>Camera-only front / side / back. Same OBJ and pose.</p><img class="wide" src="source-camera-initial-overlay.png"><img class="wide" src="final-overlay.png"><p>Before/after original photo overlays: green overlap, magenta reference-only, cyan body-only. Nude mesh vs clothed envelope is not a full clothing reconstruction.</p>')
report=f'''# Executed single-state original-photo fit

Old skill `work/single-state-skill-evals-20261117/skill-old/SKILL.md` and its three references were read. This run starts only from the supplied neutral M state; it does not reuse a fitted original-photo state.

Actual SciPy optimization runs real Human Studio cm calibration and 163-bone FK/four-weight LBS. The 12D centimetre controls produce changed rest vertices and real bone-head locations; the active cm block covers bust, waist, hips, shoulders, upperArmLength and forearmLength. Height remains the explicitly authorized 170 cm generic M prior. Official ASOS source is a 171 cm model wearing S; these are separate facts, not identical people or inferred measurements. One saved complete 163-entry pose drives every output.

## Measured outcome

|Metric (native 1000×1276)|Initial source camera|Final|
|---|---:|---:|
|Visible face/wrist mean px|{start['visible_face_wrist_mean_px']:.3f}|{final['visible_face_wrist_mean_px']:.3f}|
|All manual landmarks mean px|{start['all_manual_landmark_mean_px']:.3f}|{final['all_manual_landmark_mean_px']:.3f}|
|IoU|{start['iou']:.5f}|{final['iou']:.5f}|
|Dice|{start['dice']:.5f}|{final['dice']:.5f}|
|Symmetric contour mean px|{start['symmetric_contour_mean_px']:.3f}|{final['symmetric_contour_mean_px']:.3f}|
|Symmetric contour P95 px|{start['symmetric_contour_p95_px']:.3f}|{final['symmetric_contour_p95_px']:.3f}|
|Body outside clothed envelope fraction|{start['body_outside_envelope_fraction']:.5f}|{final['body_outside_envelope_fraction']:.5f}|

`final-camera-initial-*` uses the initial mesh under final camera to separate camera and shape/pose contributions. Source pixels, masks and manual points remain unchanged; input hashes are saved. No ROI, rescaling or reference warp was used. Hidden shoulder/elbow centers get lower weight than visible face/wrists. Auxiliary fingertip convergence hypotheses guide grasp posture and are not added to reported annotation metrics. Cm search uses 0.5cm finite coordinate probes and actual source calibration, followed by pose/camera refinement; all trials and selected parameter blocks are in history. Some dimensions stay at their initial priors when evidence does not justify a move.

## Three-dimensional inspection and limitations

The first candidate obtained excellent 2D marks but stretched hands too far in front of the body; it is retained in `attempt-1/`, not presented as final. The final solver constrains wrists near 22cm anterior world Z and elbows near 5cm, and limits root/spine lean, keeping the bent-arm hands-together hem-holding action. Front/side/back are actual renders around the same state and posed OBJ. They are hypothesis views, not observed side/back photos. Palm/finger surface orientation and overlap are inspected visually; precise finger gripping and real garment contact remain uncertain because the source hides palm surfaces and no cloth mesh is fitted. LBS is not collision/tissue/cloth simulation. Do not treat body/clothed-envelope IoU as true body shape accuracy, or low landmark error as verified 3D recovery. Hair, loose sleeves, pants and crop explain irreducible silhouette differences. Retained metric regressions are visible in the table and first attempt.

`measurements.json/CSV` report actual neutral mesh dimensions and separate bone-head distances from surface-ruler length controls. `independent-neutral-check.json` independently reconstructs the matching hashed asset using saved morphs. These are mesh checks, never photographed-person measurements. Unobservable underbust, bust-point distance, shoulder slope and crotch arc are unavailable.

## Run and consume

From repository root: `python {str((O/'reproduce.py').relative_to(R))}` then `python {str((O/'finalize.py').relative_to(R))}`. Dependencies are existing NumPy/SciPy/OpenCV/Node, no paid service and no generation invocation. Runtime/app/skill are unchanged.

Run `sh {str((O/'launch-viewer.sh').relative_to(R))}` and open `http://127.0.0.1:8769{load}` to load this exact saved state into actual editable Human Studio. The same-origin model parameter is the existing app contract. This is a local load-link delivery, not claimed browser save/import proof. `viewer.html` links the consumer and images. Every camera records explicit 3×4 homogeneous world-to-pixel matrices in cm; points are column vectors. Full state, asset and mesh fingerprints are provided.

Executed result: projected landmark alignment improved. True anatomical dimensions, exact three-dimensional gripping and physical garment fit remain NOT_VERIFIED.
'''
(O/'report.md').write_text(report)
(O/'TRACE.md').write_text('''# Trace
1. Read repository AGENTS, explicit old SKILL.md, human-studio.md, geometry-evidence.md, tools-and-evidence.md, fixtures README and original-photo README/source-description.
2. Viewed actual original ASOS image, supplied mask and manual landmarks; recorded input hashes; no outside images or fitted states read.
3. Created and executed reproduce.py with real source calibration, actual skeletal LBS, SciPy pose/camera solver and centimetre/bone blocks. First complete candidate failed side-view sanity (hands too anterior); retained under attempt-1.
4. Re-executed from original initial state with explicit depth/lean anatomical priors. Preserved initial and final cameras and camera-only comparison. Source annotations unchanged.
5. Rasterized actual final posed geometry for original-camera comparison and three independent cameras. Inspected front/side/back and original overlay with view_image.
6. Ran matching-asset independent neutral reconstruction. Saved full complete pose, world/pixel joints, OBJ cm, camera projection matrices, per-view shared hashes, measurements, metrics and actual trial history.
7. Delivered existing same-origin Human Studio model load link, local viewer and launch entrypoint. No browser consumer run is claimed. No shared runtime, app, skill or other executor output changed. No commit/push (per task instruction).
''')
write('delivery-hashes.json',{p.name:sha(p) for p in O.iterdir() if p.is_file() and p.name!='delivery-hashes.json'})
print('Finalization complete',json.dumps(M['final']))
