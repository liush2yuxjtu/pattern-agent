#!/usr/bin/env python3
"""Single actual Human Studio state; local alternating cm/pose/camera optimization."""
import sys,json,copy,hashlib,csv,importlib.util,time
from pathlib import Path
import numpy as np,cv2
from scipy.optimize import least_squares,minimize
from scipy.spatial.transform import Rotation
OUT=Path(__file__).resolve().parent
ROOT=next(p for p in OUT.parents if (p/'web/human-studio/assets/human.json').exists())
FIX=ROOT/'work/single-state-skill-evals-20261117/fixtures';sys.path.insert(0,str(FIX))
from runtime import Runtime,sha
import render_mesh
r=Runtime();initial=json.loads((FIX/'real-photo/initial-state.json').read_text());state=copy.deepcopy(initial)
photo=cv2.imread(str(FIX/'real-photo/original-product.jpg'));ref=cv2.imread(str(FIX/'real-photo/reference-mask.png'),0)>127
points=json.loads((FIX/'real-photo/manual-landmarks.json').read_text())['points']
h,w=ref.shape
# Perspective: look from positive Z; yaw/pitch rotate camera frame, Y up; distance in cm.
cam0=dict(width=w,height=h,projection='perspective',focal_px=3000.,distance_cm=225.,center_cm=[9.,125.],yaw_deg=0.,pitch_deg=0.)
cam=copy.deepcopy(cam0)
history=[]
posekeys=[(n,k) for n in ['root','spine01','neck01','head','upperarm01.L','upperarm01.R','lowerarm01.L','lowerarm01.R','wrist.L','wrist.R'] for k in range(3)]
def project(v,c):
 q=np.asarray(v).copy();q[:,0]-=c['center_cm'][0];q[:,1]-=c['center_cm'][1]
 q=q@Rotation.from_euler('YX',[c['yaw_deg'],c['pitch_deg']],degrees=True).as_matrix().T
 d=c['distance_cm']-q[:,2];uv=np.column_stack([w/2+c['focal_px']*q[:,0]/d,h/2-c['focal_px']*q[:,1]/d]);return uv,d

def pack(s,c):return np.array([s['poseDegrees'][n][k] for n,k in posekeys]+[c['focal_px'],c['distance_cm'],*c['center_cm'],c['yaw_deg'],c['pitch_deg']])
def unpack(x,s,c):
 s=copy.deepcopy(s);c=copy.deepcopy(c)
 for (n,k),v in zip(posekeys,x):s['poseDegrees'][n][k]=float(v)
 c.update(focal_px=float(x[-6]),distance_cm=float(x[-5]),center_cm=list(x[-4:-2]),yaw_deg=float(x[-2]),pitch_deg=float(x[-1]));return s,c

def residual(x,s,c):
 s,c=unpack(x,s,c);a=r.evaluate(s);uv,_=project(a['joints'],c);vuv,_=project(a['posed'],c);err=[]
 for p in points:
  xy=vuv[p['vertex']] if 'vertex'in p else uv[r.index[p['joint']]]
  weight=.32 if p.get('joint','').startswith(('upperarm','lowerarm')) else (0.65 if p.get('joint')=='neck01' else 1.)
  err.extend((xy-np.array(p['pixel']))/20*weight)
 # Explicit weak action hypotheses: fingertips converge at held hem, not observed rig labels.
 for side,target in [('L',[287,802]),('R',[280,786])]:
  err.extend((uv[r.index['finger3-3.'+side]]-target)/30*.45)
 # Keep hands forward of torso; this is a one-view anatomical prior, not measured depth.
 for side in ['L','R']:
  j=a['joints'][r.index['wrist.'+side]];err.append((j[2]-22)/7);el=a['joints'][r.index['lowerarm01.'+side]];err.append((el[2]-5)/12*.7)
 # Broad pose prior penalizes extreme but allows bent elbows and head/torso lean.
 vals=x[:len(posekeys)];err.extend(vals*.0025)
 err.extend([(c['distance_cm']-225)/200,(c['focal_px']/c['distance_cm']-14)/15,c['pitch_deg']/40,c['yaw_deg']/60])
 return np.array(err)
lo=[];hi=[]
for n,k in posekeys:
 bound=(12 if k!=1 else 25) if n in ['root','spine01'] else (30 if n in ['neck01','head'] else 150)
 lo.append(-bound);hi.append(bound)
lo+= [2000,180,-30,105,-35,-20];hi+=[5000,350,30,150,35,20]
def fit_pose(label):
 global state,cam
 x=pack(state,cam);t=time.time();fit=least_squares(residual,x,args=(state,cam),bounds=(lo,hi),diff_step=.002,max_nfev=95,ftol=2e-5,xtol=2e-5)
 state,cam=unpack(fit.x,state,cam);history.append(dict(block=label,variables='global pose incl root/torso/head/shoulder/elbow/wrist + perspective camera',nfev=fit.nfev,cost=float(np.mean(fit.fun**2)),seconds=time.time()-t,dimensions=state['dimensions'].copy(),poseDegrees=copy.deepcopy(state['poseDegrees']),camera=copy.deepcopy(cam)));print(label,fit.cost,fit.nfev,flush=True)
fit_pose('pose_camera_1')
# Actual cm calibration coordinate block; 0.5 cm finite probes respect 0.1cm source controls.
keys=['bust','waist','hips','shoulders','upperArmLength','forearmLength'];bounds={'bust':(84,96),'waist':(66,78),'hips':(91,101),'shoulders':(34,40),'upperArmLength':(26,32),'forearmLength':(21,26)}
def shape_loss(s):
 a=r.evaluate(s);v=a['posed'];uv,d=project(v,cam);j=project(a['joints'],cam)[0];e=[]
 for p in points:
  xy=uv[p['vertex']] if 'vertex'in p else j[r.index[p['joint']]];wt=.2 if p.get('joint','').startswith(('upperarm','lowerarm')) else 1.;e.extend((xy-p['pixel'])/20*wt)
 # naked mesh should be contained in opaque garment/person envelope. Fixed full-resolution mask.
 dist=cv2.distanceTransform((~ref).astype('uint8'),cv2.DIST_L2,3)
 samp=uv[r.ids[::10]];ok=(samp[:,0]>=0)&(samp[:,0]<w)&(samp[:,1]>=0)&(samp[:,1]<h);samp=samp[ok].astype(int)
 outside=dist[samp[:,1],samp[:,0]]
 prior=np.array([(s['dimensions'][k]-initial['dimensions'][k])/4 for k in keys])
 return float(np.mean(np.array(e)**2)+np.mean(np.minimum(outside,100)**2)/1500+.13*np.mean(prior**2))
for turn in range(2):
 for key in keys:
  base=state['dimensions'][key];trials=[]
  for delta in [0,-.5,.5]:
   s=copy.deepcopy(state);s['dimensions'][key]=float(np.clip(round((base+delta)*10)/10,*bounds[key]));trials.append((shape_loss(s),s))
  score,state=min(trials,key=lambda z:z[0]);history.append(dict(block='cm_shape_bone_'+key,iteration=turn,trial_costs=[x[0] for x in trials],selected_cm=state['dimensions'][key],cost=score,dimensions=state['dimensions'].copy()))
 fit_pose('pose_camera_'+str(turn+2))
# Import/UI precision. Full 163-entry local map retained.
for k in state['poseDegrees']:state['poseDegrees'][k]=[round(float(x),1) for x in state['poseDegrees'][k]]
state=r.canonical_state(state);state['limitations']=['Single original oblique clothed photograph: hidden body dimensions and depth are prior-dependent; no real-person measurement claim.'];state['basis']='prior';
def camera_matrix(c):
 R=Rotation.from_euler('YX',[c['yaw_deg'],c['pitch_deg']],degrees=True).as_matrix();ctr=np.array([*c['center_cm'],0.]);f=c['focal_px'];D=c['distance_cm'];M=np.zeros((3,4));M[0,:3]=f*R[0]-w/2*R[2];M[1,:3]=-f*R[1]-h/2*R[2];M[2,:3]=-R[2];M[0,3]=-f*(R[0]@ctr)+w/2*(D+R[2]@ctr);M[1,3]=f*(R[1]@ctr)+h/2*(D+R[2]@ctr);M[2,3]=D+R[2]@ctr
 c['world_to_pixel']=M.tolist();c['matrix_convention']='column homogeneous cm vector [X,Y,Z,1]; p=M@v; pixel=[p0/p2,p1/p2]; image x right/y down. Euler Y then X camera frame, degree units.';return c
cam=camera_matrix(cam);cam0=camera_matrix(cam0)
(OUT/'initial-state.json').write_text(json.dumps(initial,indent=2));(OUT/'final-state.json').write_text(json.dumps(state,indent=2));(OUT/'singlefinalstate.json').write_text(json.dumps(state,indent=2));(OUT/'camera-initial.json').write_text(json.dumps(cam0,indent=2));(OUT/'camera.json').write_text(json.dumps(cam,indent=2));(OUT/'parameter-block-history.json').write_text(json.dumps(history,indent=2))
a=r.evaluate(state);a0=r.evaluate(initial)
r.write_obj(OUT/'neutral.obj',a['shape']['rest']);r.write_obj(OUT/'posed.obj',a['posed']);r.write_obj(OUT/'initial-neutral.obj',a0['shape']['rest']);r.write_obj(OUT/'initial-posed.obj',a0['posed'])
def photo_render(a,c):
 uv,depth=project(a['posed'],c);pseudo=np.column_stack([uv[:,0]-w/2,h/2-uv[:,1],-depth]);spec=dict(width=w,height=h,depth_range_cm=[-400,0],views={'photo':dict(axis='front',px_per_cm=1,center_cm=[0,0])});return render_mesh.raster(pseudo,r.faces,spec,'photo')
def metric(mask):
 mask=mask>127;inter=(mask&ref).sum();union=(mask|ref).sum();a=mask.sum();b=ref.sum()
 c1=cv2.morphologyEx(mask.astype('uint8'),cv2.MORPH_GRADIENT,np.ones((3,3),'uint8'))>0;c2=cv2.morphologyEx(ref.astype('uint8'),cv2.MORPH_GRADIENT,np.ones((3,3),'uint8'))>0
 d1=cv2.distanceTransform((~c1).astype('uint8'),cv2.DIST_L2,3);d2=cv2.distanceTransform((~c2).astype('uint8'),cv2.DIST_L2,3);ds=np.r_[d1[c2],d2[c1]]
 return dict(iou=float(inter/union),dice=float(2*inter/(a+b)),symmetric_contour_mean_px=float(ds.mean()),symmetric_contour_p95_px=float(np.percentile(ds,95)),body_outside_envelope_fraction=float((mask&~ref).sum()/max(a,1)))
metrics={};
for name,aa,cc in [('source-camera-initial',a0,cam0),('final-camera-initial',a0,cam),('final',a,cam)]:
 mask,img,dep,z=photo_render(aa,cc);cv2.imwrite(str(OUT/(name+'-render.png')),img);cv2.imwrite(str(OUT/(name+'-mask.png')),mask);m=mask>127
 color=np.zeros_like(photo);color[m&ref]=[65,200,65];color[ref&~m]=[180,45,230];color[m&~ref]=[230,220,25]
 over=photo.copy();hit=m|ref;over[hit]=(photo[hit]*.55+color[hit]*.45).astype('uint8');uv=project(aa['joints'],cc)[0];vuv=project(aa['posed'],cc)[0];errors=[];visible=[]
 for p in points:
  pp=vuv[p['vertex']] if 'vertex'in p else uv[r.index[p['joint']]];target=np.array(p['pixel']);err=float(np.linalg.norm(pp-target));errors.append(err)
  if 'vertex'in p or p.get('joint','').startswith(('eye','wrist')):visible.append(err)
  cv2.line(over,tuple(target.astype(int)),tuple(np.rint(pp).astype(int)),(10,100,255),2);cv2.circle(over,tuple(target.astype(int)),5,(0,255,255),-1)
 cv2.imwrite(str(OUT/(name+'-overlay.png')),over);metrics[name]={**metric(mask),'all_manual_landmark_mean_px':float(np.mean(errors)),'visible_face_wrist_mean_px':float(np.mean(visible)),'per_point_px':errors}
# True three orthographic cameras around exactly the same saved body/pose.
views={v:dict(axis=v,px_per_cm=4.5,center_cm=[0,85]) for v in ['front','side','back']};vc=dict(width=600,height=900,depth_range_cm=[-90,90],views=views)
(OUT/'three-view-camera.json').write_text(json.dumps(vc,indent=2));joints={'joints':[dict(name=n,parent=r.bones[i]['parent'],position=a['joints'][i].tolist(),photo_pixel=project(a['joints'][[i]],cam)[0][0].tolist()) for i,n in enumerate(r.names)]};(OUT/'joints.json').write_text(json.dumps(joints,indent=2))
provenance={}
for view in views:
 mask,img,dep,z=render_mesh.raster(a['posed'],r.faces,vc,view,joints);cv2.imwrite(str(OUT/(view+'.png')),img);cv2.imwrite(str(OUT/(view+'-mask.png')),mask);provenance[view]=dict(state_sha256=sha(OUT/'final-state.json'),posed_mesh_sha256=sha(OUT/'posed.obj'),pose_sha256=hashlib.sha256(json.dumps(state['poseDegrees'],sort_keys=True).encode()).hexdigest())
(OUT/'view-provenance.json').write_text(json.dumps(provenance,indent=2));(OUT/'metrics.json').write_text(json.dumps(metrics,indent=2));np.save(OUT/'rawdepth.npy',photo_render(a,cam)[3].astype('float32'));cv2.imwrite(str(OUT/'depth-valid.png'),np.isfinite(photo_render(a,cam)[3]).astype('uint8')*255)
# Read actual calibrated neutral geometry, independent inspection subsequently uses asset and stored morphs.
measure=[dict(name=k,target_cm=state['dimensions'][k],value_cm=float(v),basis='mesh_parameter',mesh_checked=True,definition='neutral surface tape path or landmark; see model measurementDefinition') for k,v in state['measuredNeutral'].items()]
for side in ['L','R']:
 for name,p,q in [('upper_arm_bone_head', 'upperarm01.','lowerarm01.'),('forearm_bone_head','lowerarm01.','wrist.')]:
  measure.append(dict(name=name+'.'+side,value_cm=float(np.linalg.norm(a['shape']['heads'][r.index[p+side]]-a['shape']['heads'][r.index[q+side]])),basis='mesh_parameter',mesh_checked=True,definition='actual rest bone-head straight distance; different from surface-ruler control'))
(OUT/'measurements.json').write_text(json.dumps(dict(neutral_mesh_sha256=sha(OUT/'neutral.obj'),source_model_height_cm=171,source_wearing='S',authorized_initialization_height_cm=170,authorized_initialization_size='generic M',measurements=measure),indent=2))
with (OUT/'measurements.csv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=['name','target_cm','value_cm','basis','mesh_checked','definition']);writer.writeheader();writer.writerows(measure)
(OUT/'input-hashes.json').write_text(json.dumps({str(p.relative_to(ROOT)):sha(p) for p in [FIX/'real-photo/original-product.jpg',FIX/'real-photo/reference-mask.png',FIX/'real-photo/manual-landmarks.json',FIX/'real-photo/initial-state.json',r.asset]},indent=2))
r.close();print(json.dumps(metrics,indent=2))

# Complete the evidence/consumer contract after the deterministic actual fit.
import subprocess
subprocess.run([sys.executable,str(OUT/'finalize.py')],check=True)
