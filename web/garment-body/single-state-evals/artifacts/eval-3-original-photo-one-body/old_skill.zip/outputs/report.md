# Executed single-state original-photo fit

Old skill `work/single-state-skill-evals-20261117/skill-old/SKILL.md` and its three references were read. This run starts only from the supplied neutral M state; it does not reuse a fitted original-photo state.

Actual SciPy optimization runs real Human Studio cm calibration and 163-bone FK/four-weight LBS. The 12D centimetre controls produce changed rest vertices and real bone-head locations; the active cm block covers bust, waist, hips, shoulders, upperArmLength and forearmLength. Height remains the explicitly authorized 170 cm generic M prior. Official ASOS source is a 171 cm model wearing S; these are separate facts, not identical people or inferred measurements. One saved complete 163-entry pose drives every output.

## Measured outcome

|Metric (native 1000×1276)|Initial source camera|Final|
|---|---:|---:|
|Visible face/wrist mean px|271.931|3.953|
|All manual landmarks mean px|186.241|7.114|
|IoU|0.63965|0.69730|
|Dice|0.78023|0.82166|
|Symmetric contour mean px|61.060|58.087|
|Symmetric contour P95 px|169.990|188.549|
|Body outside clothed envelope fraction|0.17462|0.20312|

`final-camera-initial-*` uses the initial mesh under final camera to separate camera and shape/pose contributions. Source pixels, masks and manual points remain unchanged; input hashes are saved. No ROI, rescaling or reference warp was used. Hidden shoulder/elbow centers get lower weight than visible face/wrists. Auxiliary fingertip convergence hypotheses guide grasp posture and are not added to reported annotation metrics. Cm search uses 0.5cm finite coordinate probes and actual source calibration, followed by pose/camera refinement; all trials and selected parameter blocks are in history. Some dimensions stay at their initial priors when evidence does not justify a move.

## Three-dimensional inspection and limitations

The first candidate obtained excellent 2D marks but stretched hands too far in front of the body; it is retained in `attempt-1/`, not presented as final. The final solver constrains wrists near 22cm anterior world Z and elbows near 5cm, and limits root/spine lean, keeping the bent-arm hands-together hem-holding action. Front/side/back are actual renders around the same state and posed OBJ. They are hypothesis views, not observed side/back photos. Palm/finger surface orientation and overlap are inspected visually; precise finger gripping and real garment contact remain uncertain because the source hides palm surfaces and no cloth mesh is fitted. LBS is not collision/tissue/cloth simulation. Do not treat body/clothed-envelope IoU as true body shape accuracy, or low landmark error as verified 3D recovery. Hair, loose sleeves, pants and crop explain irreducible silhouette differences. Retained metric regressions are visible in the table and first attempt.

`measurements.json/CSV` report actual neutral mesh dimensions and separate bone-head distances from surface-ruler length controls. `independent-neutral-check.json` independently reconstructs the matching hashed asset using saved morphs. These are mesh checks, never photographed-person measurements. Unobservable underbust, bust-point distance, shoulder slope and crotch arc are unavailable.

## Run and consume

From repository root: `python work/single-state-skill-evals-20261117/iteration-1/eval-3-original-photo-one-body/old_skill/run-1/outputs/reproduce.py` then `python work/single-state-skill-evals-20261117/iteration-1/eval-3-original-photo-one-body/old_skill/run-1/outputs/finalize.py`. Dependencies are existing NumPy/SciPy/OpenCV/Node, no paid service and no generation invocation. Runtime/app/skill are unchanged.

Run `sh work/single-state-skill-evals-20261117/iteration-1/eval-3-original-photo-one-body/old_skill/run-1/outputs/launch-viewer.sh` and open `http://127.0.0.1:8769/web/human-studio/?model=/work/single-state-skill-evals-20261117/iteration-1/eval-3-original-photo-one-body/old_skill/run-1/outputs/final-state.json` to load this exact saved state into actual editable Human Studio. The same-origin model parameter is the existing app contract. This is a local load-link delivery, not claimed browser save/import proof. `viewer.html` links the consumer and images. Every camera records explicit 3×4 homogeneous world-to-pixel matrices in cm; points are column vectors. Full state, asset and mesh fingerprints are provided.

Executed result: projected landmark alignment improved. True anatomical dimensions, exact three-dimensional gripping and physical garment fit remain NOT_VERIFIED.

Independent geometry probe audit: `geometry-check.json` executes all twelve ±0.5cm trials and records actual rest mesh and bone-head movement. Selected final cm values remain initial priors; no fitted-cm recovery claim is made. Finger pinching remains unresolved (`hand-inspection.json`). All homogeneous camera reprojection checks pass; same mesh hash across three views. HTTP200 confirmed for actual Human Studio and saved state (`load-link-http-check.json`).
