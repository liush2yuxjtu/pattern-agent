from pathlib import Path
import json,sys,copy,hashlib,numpy as np
O=Path(__file__).resolve().parent;R=next(p for p in O.parents if (p/'web/human-studio/assets/human.json').exists());sys.path.insert(0,str(R/'work/single-state-skill-evals-20261117/fixtures'))
from runtime import Runtime
r=Runtime();s=json.loads((O/'initial-state.json').read_text());a=r.evaluate(s);trials=[]
for key in ['bust','waist','hips','shoulders','upperArmLength','forearmLength']:
 for delta in [-.5,.5]:
  q=copy.deepcopy(s);q['dimensions'][key]+=delta;b=r.evaluate(q);record=dict(parameter=key,delta_cm=delta,actual_neutral_max_vertex_movement_cm=float(np.linalg.norm(a['shape']['rest']-b['shape']['rest'],axis=1).max()),actual_rest_bone_head_max_movement_cm=float(np.linalg.norm(a['shape']['heads']-b['shape']['heads'],axis=1).max()),bone_head_lengths_cm={})
  for side in ['L','R']:
   for label,p,q in [('upperArm','upperarm01.','lowerarm01.'),('forearm','lowerarm01.','wrist.')]:record['bone_head_lengths_cm'][label+'.'+side]=float(np.linalg.norm(b['shape']['heads'][r.index[p+side]]-b['shape']['heads'][r.index[q+side]]))
  trials.append(record)
f=json.loads((O/'final-state.json').read_text());b=r.evaluate(f);j=json.loads((O/'joints.json').read_text());c=json.loads((O/'camera.json').read_text());errors=[]
for jj in j['joints']:
 for view,p in jj['projections'].items():
  q=np.array(c['views'][view]['world_to_pixel'])@np.r_[jj['position'],1];errors.append(float(np.max(np.abs(q[:2]/q[2]-p['pixel']))))
result=dict(cm_probe_trials=trials,finite_neutral=bool(np.isfinite(b['shape']['rest']).all()),finite_posed=bool(np.isfinite(b['posed']).all()),max_matrix_reprojection_error_px=max(errors),final_pose_complete=len(f['poseDegrees'])==163,posed_bounding_box_height_cm=float(np.ptp(b['posed'][r.ids,1])),neutral_height_cm=float(np.ptp(b['shape']['rest'][r.ids,1])),wrist_world_cm={side:b['joints'][r.index['wrist.'+side]].tolist() for side in ['L','R']},same_view_mesh_hashes=len({v['posed_mesh_sha256'] for v in json.loads((O/'view-provenance.json').read_text()).values()})==1)
assert all(t['actual_neutral_max_vertex_movement_cm']>0 for t in trials);assert result['max_matrix_reprojection_error_px']<1e-9 and result['same_view_mesh_hashes']
(O/'geometry-check.json').write_text(json.dumps(result,indent=2));r.close();print(json.dumps({k:v for k,v in result.items() if k!='cm_probe_trials'}))
