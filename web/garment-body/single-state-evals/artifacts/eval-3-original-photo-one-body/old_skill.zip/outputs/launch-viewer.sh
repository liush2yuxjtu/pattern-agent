#!/bin/sh
cd /workspace/work/pattern-agent
python3 -m http.server 8769 --bind 127.0.0.1
