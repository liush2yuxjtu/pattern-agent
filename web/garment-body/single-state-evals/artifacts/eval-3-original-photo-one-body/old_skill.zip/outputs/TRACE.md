# Trace
1. Read repository AGENTS, explicit old SKILL.md, human-studio.md, geometry-evidence.md, tools-and-evidence.md, fixtures README and original-photo README/source-description.
2. Viewed actual original ASOS image, supplied mask and manual landmarks; recorded input hashes; no outside images or fitted states read.
3. Created and executed reproduce.py with real source calibration, actual skeletal LBS, SciPy pose/camera solver and centimetre/bone blocks. First complete candidate failed side-view sanity (hands too anterior); retained under attempt-1.
4. Re-executed from original initial state with explicit depth/lean anatomical priors. Preserved initial and final cameras and camera-only comparison. Source annotations unchanged.
5. Rasterized actual final posed geometry for original-camera comparison and three independent cameras. Inspected front/side/back and original overlay with view_image.
6. Ran matching-asset independent neutral reconstruction. Saved full complete pose, world/pixel joints, OBJ cm, camera projection matrices, per-view shared hashes, measurements, metrics and actual trial history.
7. Delivered existing same-origin Human Studio model load link, local viewer and launch entrypoint. No browser consumer run is claimed. No shared runtime, app, skill or other executor output changed. No commit/push (per task instruction).

## Cleanup
{
  "timestamp_utc": "2026-11-17T10:52:42.790195+00:00",
  "server_8769": "stopped: <urlopen error [Errno 111] Connection refused>",
  "own_calibration_workers": {
    "32629": "not running",
    "33053": "not running",
    "33852": "not running"
  },
  "browser": "No browser was launched in this executor."
}
Local port8769 has been stopped. `load-link.txt` is a loopback example; run `sh launch-viewer.sh` from the outputs directory to restart the repository HTTP server before opening it. Final model/camera/metrics were not changed. Root publication supplies the permanent Human Studio link.
