#!/usr/bin/env python3
"""Actual single-anatomical-state photo solver. No other fitted state is read."""
import json,sys,copy,hashlib,time,csv,subprocess
from pathlib import Path
import numpy as np,cv2
from scipy.optimize import least_squares, minimize
from scipy.spatial.transform import Rotation
OUT=Path(__file__).resolve().parent
ROOT=next(p for p in OUT.parents if (p/'web/human-studio/assets/human.json').exists())
FIX=ROOT/'work/single-state-skill-evals-20261117/fixtures'
sys.path.insert(0,str(FIX));from runtime import Runtime,sha
import render_mesh

def put(name,x): (OUT/name).write_text(json.dumps(x,indent=2,default=lambda v:v.item() if isinstance(v,np.generic) else v.tolist())+'\n')
def proj(p,c):
 q=np.asarray(p)@Rotation.from_euler('YXZ',c[3:6],degrees=True).as_matrix().T
 return np.column_stack((500+(q[:,0]-c[1])*c[0],638-(q[:,1]-c[2])*c[0]))
def transformed(p,c):
 return np.asarray(p)@Rotation.from_euler('YXZ',c[3:6],degrees=True).as_matrix().T

def metrics(a,b):
 a=a>0;b=b>0;i=(a&b).sum();u=(a|b).sum()
 ca=cv2.Canny(a.astype('uint8')*255,50,150)>0;cb=cv2.Canny(b.astype('uint8')*255,50,150)>0
 da=cv2.distanceTransform((~ca).astype('uint8'),cv2.DIST_L2,5);db=cv2.distanceTransform((~cb).astype('uint8'),cv2.DIST_L2,5);ds=np.r_[da[cb],db[ca]]
 return dict(iou=float(i/u),dice=float(2*i/(a.sum()+b.sum())),contour_mean_px=float(ds.mean()),contour_p95_px=float(np.percentile(ds,95)),outside_fraction=float((b&~a).sum()/max(b.sum(),1)))
def overlay(a,b,photo):
 x=photo.copy();colors=np.zeros_like(photo);colors[(a>0)&(b>0)]=[50,210,60];colors[(a>0)&(b==0)]=[190,60,230];colors[(a==0)&(b>0)]=[240,220,30];sel=(a>0)|(b>0);x[sel]=(x[sel]*.5+colors[sel]*.5).astype('uint8');return x

def main():
 r=Runtime()
 try:
  source=json.loads((FIX/'real-photo/initial-state.json').read_text());ann=json.loads((FIX/'real-photo/manual-landmarks.json').read_text())['points'];ref=cv2.imread(str(FIX/'real-photo/reference-mask.png'),0);photo=cv2.imread(str(FIX/'real-photo/original-product.jpg'))
  put('input-provenance.json',{str(p.relative_to(ROOT)):sha(p) for p in [FIX/'real-photo/original-product.jpg',FIX/'real-photo/reference-mask.png',FIX/'real-photo/manual-landmarks.json',FIX/'real-photo/initial-state.json',FIX/'runtime.py',ROOT/'web/human-studio/assets/human.json']})
  posekeys=[('upperarm01.L',i) for i in range(3)]+[('upperarm01.R',i) for i in range(3)]+[('lowerarm01.L',i) for i in range(3)]+[('lowerarm01.R',i) for i in range(3)]+[('head',i) for i in range(3)]+[('spine01',i) for i in range(3)]+[('wrist.L',i) for i in range(3)]+[('wrist.R',i) for i in range(3)]
  cam0=np.array([13.2,6.5,124.,-12.,0.,0.]);pose0=np.zeros(len(posekeys));dims=copy.deepcopy(source['dimensions']);history=[]
  def state(p):
   s=copy.deepcopy(source);s['dimensions']=copy.deepcopy(dims)
   for (n,i),v in zip(posekeys,p):s['poseDegrees'][n][i]=float(v)
   # Hand closure is an explicit grasp prior, not photo-detected finger angles.
   for side in ['L','R']:
    for digit in range(1,6):
     for seg in range(1,4):s['poseDegrees'][f'finger{digit}-{seg}.{side}'][0]=35. if seg==1 else 50.
   return s
  def observations(e):return np.array([e['posed'][a['vertex']] if 'vertex' in a else e['joints'][r.index[a['joint']]] for a in ann])
  target=np.array([a['pixel'] for a in ann]);weights=np.array([.45,.25,.25,.3,.3,1.5,1.5,1.8,1.8,1.5])
  p=pose0.copy();c=cam0.copy();best=None
  def residual(v):
   pp=v[:len(posekeys)];cc=v[len(posekeys):];e=r.evaluate(state(pp));uv=proj(observations(e),cc)
   out=list(((uv-target)*weights[:,None]/15).ravel())
   # Explicit depth prior: hands in front of abdomen, elbows remain side of body.
   j=e['joints'];wl=j[r.index['wrist.L']];wr=j[r.index['wrist.R']]
   out.extend(((wl-[4,112,18])/[15,15,4]).tolist());out.extend(((wr-[-12,112,18])/[15,15,4]).tolist())
   for side in ['L','R']:
    elbow=j[r.index['lowerarm01.'+side]];sign=1 if side=='L' else -1;out.extend([max(0,21-sign*elbow[0])/1.5,(elbow[2]-6)/3])
    fingertip=j[r.index['finger3-3.'+side]];out.extend(((fingertip-[-3,111,20])/[10,12,5]).tolist())
   out.extend((pp/180*.12).tolist());out.extend(((cc-cam0)/np.array([8,25,25,50,20,20])*.12).tolist())
   return np.array(out)
  lo=np.r_[np.full(len(p),-110),[10,-20,110,-50,-18,-18]];hi=np.r_[np.full(len(p),110),[17,25,140,50,18,18]]
  # Elbow hinge X constrained to anatomical flexion; the solver can adjust roll/twist.
  for k,(n,i) in enumerate(posekeys):
   if n.startswith('lowerarm') and i==0:lo[k]=-5;hi[k]=135
   if n=='spine01':lo[k]=-12;hi[k]=12
  export_only='--export-only' in sys.argv
  if export_only or '--continue' in sys.argv:
   checkpoint=json.loads((OUT/'final-state.json').read_text());dims=checkpoint['dimensions'];p=np.array([checkpoint['poseDegrees'][n][i] for n,i in posekeys]);c=np.array(json.loads((OUT/'camera.json').read_text())['final']);history=json.loads((OUT/'parameter-block-history.json').read_text())
  for cycle in range(0 if export_only else 3):
   t=time.time();v0=np.r_[p,c];fit=least_squares(residual,v0,bounds=(lo,hi),diff_step=.002,max_nfev=80,ftol=1e-6,xtol=1e-6)
   p=fit.x[:len(p)];c=fit.x[len(p):]
   history.append(dict(block='global-pose-and-camera',cycle=cycle,initial=v0.tolist(),final=fit.x.tolist(),cost=float(np.sum(residual(fit.x)**2)),evaluations=fit.nfev,seconds=time.time()-t,parameter_names=[n+':XYZ'[i+1] for n,i in posekeys]+['px_per_cm','center_x_cm','center_y_cm','yaw','pitch','roll']))
   # Real cm morph coordinate search changes rest mesh and actual bone positions.
   before=copy.deepcopy(dims);trials=[]
   for key,step,low,high in [('upperArmLength',.7,26,33),('forearmLength',.7,20,27),('waist',1,66,78),('bust',1,86,94),('shoulders',.5,35,40)]:
    orig=dims[key];candidates=[]
    for val in [orig,round(max(low,orig-step),1),round(min(high,orig+step),1)]:
     dims[key]=val;ee=r.evaluate(state(p));uv=proj(ee['posed'][r.ids[::15]],c);pix=np.rint(uv).astype(int);inside=(pix[:,0]>=0)&(pix[:,0]<1000)&(pix[:,1]>=0)&(pix[:,1]<1276);dt=cv2.distanceTransform((ref==0).astype('uint8'),cv2.DIST_L2,5);outside=dt[np.clip(pix[:,1],0,1275),np.clip(pix[:,0],0,999)];score=float(np.sum(residual(np.r_[p,c])**2)+np.mean(np.minimum(outside[inside],100)**2)/300+((val-source['dimensions'][key])/3)**2*.01);candidates.append((score,val))
    trials.append(dict(key=key,candidates=[dict(loss=sc,value_cm=val) for sc,val in candidates]));dims[key]=min(candidates)[1]
   history.append(dict(block='cm-shape-and-bone-lengths',cycle=cycle,initial=before,final=copy.deepcopy(dims),candidate_trials=trials,loss=float(np.sum(residual(np.r_[p,c])**2))))
   put('parameter-block-history.json',history);print('cycle',cycle,'cost',history[-1]['loss'],'dims',dims,'camera',c,flush=True)
  # Quantize to editor contract before final evidence.
  p=np.round(p,1);saved_dims=copy.deepcopy(dims);dims=copy.deepcopy(source['dimensions']);initial_cost=float(np.sum(residual(np.r_[pose0,cam0])**2));dims=saved_dims;put('objective.json',dict(initial=initial_cost,final=float(np.sum(residual(np.r_[p,c])**2)),definition='weighted manual landmark residual + explicit 3D elbow/hand/action priors + small pose/camera regularization; grasp prior applied in candidate states'));s=state(p);final=r.canonical_state(s);final['limitations']=['Single real clothed photograph; generic M170 prior, not recovered true body measurements.','Unobserved side/back and hand depths are regularized hypotheses; no tissue/cloth collision simulation.'];put('final-state.json',final);put('initial-state.json',source);put('camera.json',dict(protocol='orthographic-oblique-v1',units='cm',width=1000,height=1276,rotation_order='YXZ degrees',initial=cam0.tolist(),final=c.tolist(),formula='q=R(YXZ)*world; u=500+s*(qx-cx), v=638-s*(qy-cy)',near_far_cm=[-200,200]))
  ei=r.evaluate(source);ef=r.evaluate(final);r.write_obj(OUT/'neutral.obj',ef['shape']['rest']);r.write_obj(OUT/'posed.obj',ef['posed']);r.write_obj(OUT/'initial-neutral.obj',ei['shape']['rest']);r.write_obj(OUT/'initial-posed.obj',ei['posed'])
  def photo_mask(e,cc):
   uv=proj(e['posed'],cc);m=np.zeros_like(ref)
   for f in r.faces:cv2.fillConvexPoly(m,np.rint(uv[f]).astype('int32'),255)
   return m
  mi=photo_mask(ei,cam0);mf=photo_mask(ef,c);mic=photo_mask(ei,c);mfs=photo_mask(ef,cam0)
  for name,m in [('initial',mi),('final',mf),('initial-finalcamera',mic),('final-sourcecamera',mfs)]:cv2.imwrite(str(OUT/(name+'-mask.png')),m);cv2.imwrite(str(OUT/(name+'-overlay.png')),overlay(ref,m,photo))
  cv2.imwrite(str(OUT/'reference-mask.png'),ref)
  def pointmetrics(e,cc):
   dist=np.linalg.norm(proj(observations(e),cc)-target,axis=1);return dict(mean_px=float(dist.mean()),visible_face_wrists_mean_px=float(dist[[5,6,7,8,9]].mean()),per_point_px=dist.tolist())
  put('metrics.json',dict(reference_sha256=sha(FIX/'real-photo/original-product.jpg'),reference_mask_sha256=sha(FIX/'real-photo/reference-mask.png'),resolution=[1000,1276],initial=dict(mask=metrics(ref,mi),joints=pointmetrics(ei,cam0)),final=dict(mask=metrics(ref,mf),joints=pointmetrics(ef,c)),frozen_final_camera_initial=dict(mask=metrics(ref,mic),joints=pointmetrics(ei,c)),frozen_source_camera_final=dict(mask=metrics(ref,mfs),joints=pointmetrics(ef,cam0))))
  # Actual same-mesh raster views; each only changes camera axis. Full-body framing.
  camera=dict(width=600,height=900,depth_range_cm=[-100,100],views={v:dict(axis=axis,px_per_cm=4.8,center_cm=[0,85]) for v,axis in [('front','front'),('side','side'),('back','back')]})
  camera['views']['closeup']=dict(axis='front',px_per_cm=10,center_cm=[0,120]);camera['views']['pose']=camera['views']['front'];camera['views']['depth']=camera['views']['front'];put('render-camera.json',camera)
  protocol=json.loads((OUT/'camera.json').read_text());R=Rotation.from_euler('YXZ',c[3:6],degrees=True).as_matrix();M=np.vstack((np.r_[c[0]*R[0],500-c[0]*c[1]],np.r_[-c[0]*R[1],638+c[0]*c[2]],[0,0,0,1]));protocol['world_to_pixel_homogeneous']=M.tolist();protocol['multiplication']='column homogeneous [x,y,z,1] cm; pixel homogeneous=M@world; divide by third component';protocol['views']={}
  for name,cc in camera['views'].items():
   a=[0,0,1] if cc['axis']=='side' else ([-1,0,0] if cc['axis']=='back' else [1,0,0]);ss=cc['px_per_cm'];cx,cy=cc['center_cm'];protocol['views'][name]=dict(**cc,world_to_pixel_homogeneous=[[*list(np.array(a)*ss),300-cx*ss],[0,-ss,0,450+cy*ss],[0,0,0,1]])
  put('camera.json',protocol)
  jointrows=[dict(name=n,parent=r.bones[i]['parent'],position=ef['joints'][i].tolist(),pixel_photo=proj(ef['joints'][i:i+1],c)[0].tolist(),visibility='projected; occlusion unclassified') for i,n in enumerate(r.names)];put('joints.json',dict(joints=jointrows));provenance={}
  for view in camera['views']:
   m,im,dep,z=render_mesh.raster(ef['posed'],r.faces,camera,view,dict(joints=jointrows));cv2.imwrite(str(OUT/(view+'.png')),dep if view=='depth' else im);cv2.imwrite(str(OUT/(view+'-mask.png')),m)
   if view=='depth':np.save(OUT/'rawdepth.npy',z.astype('float32'));cv2.imwrite(str(OUT/'depth-valid.png'),np.isfinite(z).astype('uint8')*255)
   provenance[view]=dict(state_sha256=sha(OUT/'final-state.json'),posed_mesh_sha256=sha(OUT/'posed.obj'),pose_sha256=hashlib.sha256(json.dumps(final['poseDegrees'],sort_keys=True).encode()).hexdigest(),camera=camera['views'][view])
  put('view-provenance.json',provenance)
  bones={}
  for side in ['L','R']:
   for label,a,b in [('upper_arm','upperarm01.','lowerarm01.'),('forearm','lowerarm01.','wrist.')]:bones[label+'.'+side]=dict(initial_cm=float(np.linalg.norm(ei['shape']['heads'][r.index[a+side]]-ei['shape']['heads'][r.index[b+side]])),final_cm=float(np.linalg.norm(ef['shape']['heads'][r.index[a+side]]-ef['shape']['heads'][r.index[b+side]])),definition='actual bone-head distance; differs from surface ruler')
  measures=[dict(name=k,target_cm=v,measured_cm=final['measuredNeutral'][k],basis='prior' if k=='height' else 'mesh_parameter',mesh_checked=True,definition='standing_height' if k=='height' else 'neutral surface tape or named landmark ruler',limitations='not real-person measurement') for k,v in final['dimensions'].items()]
  put('measurements.json',dict(source_model=dict(height_cm=171,size='S',basis='official source'),initial_prior=dict(height_cm=170,size='generic M',basis='authorized prior'),dimensions=measures,bone_head_lengths=bones,neutral_mesh_sha256=sha(OUT/'neutral.obj'),posed_bbox_height_cm=float(np.ptp(ef['posed'][r.ids,1])),unavailable=['underbust','bust_point_spacing','front_waist_length','back_waist_length','crotch_arc']))
  with (OUT/'measurements.csv').open('w') as f:
   writer=csv.DictWriter(f,fieldnames=list(measures[0]));writer.writeheader();writer.writerows(measures)
  subprocess.run([sys.executable,str(ROOT/'work/single-state-skill-evals-20261117/skill-new/scripts/inspect_human_state.py'),'--state',str(OUT/'final-state.json'),'--asset-json',str(r.asset),'--out',str(OUT/'independent-neutral-check.json')],check=True)
  load='/web/human-studio/?model=/'+str((OUT/'final-state.json').relative_to(ROOT));(OUT/'load-link.txt').write_text('Serve repository root: python -m http.server 8873 --directory '+str(ROOT)+'\nhttp://127.0.0.1:8873'+load+'\n')
  put('run.json',dict(mode='prior_avatar',source='ASOS 211010805 original photo',source_height_cm=171,source_size='S',height_prior_cm=170,paid_generation=False,optimizer='SciPy least_squares alternating actual calibrated cm coordinate search',observed_views=1,unobserved_views=['side','back'],skill='skill-new/SKILL.md',versions=dict(python=sys.version,numpy=np.__version__,opencv=cv2.__version__),status='executed'))
  subprocess.run([sys.executable,str(OUT/'finalize.py')],check=True)
 finally:r.close()
if __name__=='__main__':main()
