# Executed original-photo single-state fit

Source: ASOS product211010805 original photograph, 1000×1276. Official source model171cm / S is separate from authorized generic M170cm body prior. The source photo, annotations and mask bytes were never edited. SHA256s are in input-provenance.json. No new generation or paid service.

Read and applied `skill-new/SKILL.md` and references human-studio.md, geometry-evidence.md and tools-and-evidence.md. Actual CC0 MakeHuman asset + Human Studio fitDimensions morph calibration + full163-bone FK and four-weight LBS were executed. This is one body and one complete pose, not per-view fitted states.

## Actual results

Full-mask IoU 0.5931 → 0.6447; Dice 0.7446 → 0.7839. Symmetric contour mean 76.52px → 62.11px, P95 250.26px → 214.10px. Visible face/wrist mean 242.42px → 3.30px. All manual points mean 163.31px → 23.09px.

`metrics.json` separately contains fixed final-camera initial versus final and fixed source-camera comparisons. Camera changes contribute to the raw improvement. `objective.json` records actual fixed final-objective initial/final costs; `parameter-block-history.json` records every pose/camera and cm shape/bone block including executed cm candidates. Waist moved72→71cm; arm ruler controls remained29/23cm after actual bounded trials. This is limited shape identifiability, not proof of true photographed measurements. Upper/forearm bone-head lengths are independently listed separately from surface ruler controls.

The approximate crop camera reaches yaw/pitch/center bounds. Its optimized orientation is a nuisance model, not calibrated photography. `camera.json` gives initial/final parameters, explicit photo and every-view3×4 world-to-pixel matrices, column-vector multiplication, axis/degree and pixel conventions. All front/side/back/closeup/pose/depth renders share identical final-state and posed OBJ hashes; only view cameras change.

## Actual visual inspection and limitations

Front, side and back were opened and inspected. Both elbows remain outside torso, both forearms return toward the front abdomen, palms and curled fingers approximate holding the shirt. Final side view no longer shows the first candidate's large forward reach, and the retained first rejected candidate is in `rejected-depth-ambiguous-round/`. The first candidate is not the delivered state. Wrist/finger closure and elbow depth constraints are explicit 3D action priors. Exact finger contact and palm orientation remain imperfect; no garment contact or tissue collision solver ran. The final wrist/forearm surfaces are close to abdomen; subtle self-contact is not certified collision-free. The side/back are unobserved hypotheses from the same mesh, never presented as real observed evidence. Hair/knit/clothing and cropped lower body explain residual silhouette differences. The mesh template head is not a reconstructed identity.

The neutral asset reconstruction check PASS verifies only model geometry/measurements. Actual OBJ/cm boundaries, finite vertices, mesh topology, raw-depth validity and matrix joint reprojection are in `geometry-audit.json`. Bounds/target errors in `independent-neutral-check.json`. Standing height comes from neutral mesh; posed bbox height is separately reported. Underbust, bust-point separation, waist lengths and crotch arc unavailable. Size prior and measured mesh values do not become real-person measurements.

## Run and consume

From repository root: `python work/single-state-skill-evals-20261117/iteration-1/eval-3-original-photo-one-body/with_skill/run-1/outputs/reproduce.py`. This starts solely from the supplied neutral M initial-state, runs all optimization blocks, renders actual outputs, reconstructs neutral measurement evidence and creates this report. `--export-only` re-renders the current run's state; `--continue` continues only this run's checkpoint.

See `load-link.txt`: serve repository root at8873 and open its same-origin Human Studio `?model=` link. `consumer-check.mjs` uses the real application's import/URL validation contract and HTTP-fetches this exact state; browser UI was not exercised. All163angles roundtrip exactly. Use actual editor Import to edit dimensions or pose further. Any edits create a new model and invalidate these frozen scores.
