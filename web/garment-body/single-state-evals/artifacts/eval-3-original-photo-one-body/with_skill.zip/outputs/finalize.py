#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,sys,shutil,collections
import numpy as np,cv2
from scipy.spatial.transform import Rotation
P=Path(__file__).resolve().parent
ROOT=next(p for p in P.parents if (p/'web/human-studio/assets/human.json').exists());FIX=ROOT/'work/single-state-skill-evals-20261117/fixtures';sys.path.insert(0,str(FIX));import render_mesh
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,x):(P/n).write_text(json.dumps(x,indent=2)+'\n')
v,f=render_mesh.obj(P/'posed.obj');c=json.loads((P/'camera.json').read_text());s=json.loads((P/'final-state.json').read_text());m=json.loads((P/'metrics.json').read_text());cfinal=c['final'];q=v@Rotation.from_euler('YXZ',cfinal[3:],degrees=True).as_matrix().T
cam=dict(width=1000,height=1276,depth_range_cm=[-200,200],views={'photo':dict(axis='front',px_per_cm=cfinal[0],center_cm=cfinal[1:3])});mask,img,dep,z=render_mesh.raster(q,f,cam,'photo');cv2.imwrite(str(P/'photo-render.png'),img)
photo=cv2.imread(str(FIX/'real-photo/original-product.jpg'));blend=photo.copy();hit=mask>0;blend[hit]=(photo[hit]*.45+img[hit]*.55).astype('uint8');cv2.imwrite(str(P/'photo-render-overlay.png'),blend);shutil.copy(FIX/'real-photo/original-product.jpg',P/'original-product.jpg')
provenance=json.loads((P/'view-provenance.json').read_text());provenance['photo']=dict(state_sha256=sha(P/'final-state.json'),posed_mesh_sha256=sha(P/'posed.obj'),pose_sha256=hashlib.sha256(json.dumps(s['poseDegrees'],sort_keys=True).encode()).hexdigest(),camera_protocol='camera.json world_to_pixel_homogeneous');save('view-provenance.json',provenance)
# Independent matrix projection from actual saved joints and actual saved OBJ.
J=json.loads((P/'joints.json').read_text())['joints'];mat=np.array(c['world_to_pixel_homogeneous']);world=np.c_[[j['position'] for j in J],np.ones(len(J))];uv=world@mat.T;uv=uv[:,:2]/uv[:,2:];err=np.max(abs(uv-np.array([j['pixel_photo'] for j in J])))
edges=collections.Counter(tuple(sorted((int(face[k]),int(face[(k+1)%3])))) for face in f for k in range(3));d=np.load(P/'rawdepth.npy');valid=cv2.imread(str(P/'depth-valid.png'),0)>0
save('geometry-audit.json',dict(vertices=len(v),triangles=len(f),finite_vertices=bool(np.isfinite(v).all()),boundary_edges=sum(x==1 for x in edges.values()),nonmanifold_edges=sum(x>2 for x in edges.values()),posed_bbox_cm=np.ptp(v,axis=0).tolist(),matrix_joint_reprojection_max_px=float(err),depth_valid_count=int(valid.sum()),depth_finite_on_valid=bool(np.isfinite(d[valid]).all()),depth_semantics='orthographic front signed world Z cm; larger values nearer camera; background -inf',state_sha256=sha(P/'final-state.json'),posed_mesh_sha256=sha(P/'posed.obj')))
initialR=Rotation.from_euler('YXZ',c['initial'][3:],degrees=True).as_matrix();ci=c['initial'];c['initial_world_to_pixel_homogeneous']=np.vstack((np.r_[ci[0]*initialR[0],500-ci[0]*ci[1]],np.r_[-ci[0]*initialR[1],638+ci[0]*ci[2]],[0,0,0,1])).tolist();save('camera.json',c)
report=f'''# Executed original-photo single-state fit

Source: ASOS product211010805 original photograph, 1000×1276. Official source model171cm / S is separate from authorized generic M170cm body prior. The source photo, annotations and mask bytes were never edited. SHA256s are in input-provenance.json. No new generation or paid service.

Read and applied `skill-new/SKILL.md` and references human-studio.md, geometry-evidence.md and tools-and-evidence.md. Actual CC0 MakeHuman asset + Human Studio fitDimensions morph calibration + full163-bone FK and four-weight LBS were executed. This is one body and one complete pose, not per-view fitted states.

## Actual results

Full-mask IoU {m['initial']['mask']['iou']:.4f} → {m['final']['mask']['iou']:.4f}; Dice {m['initial']['mask']['dice']:.4f} → {m['final']['mask']['dice']:.4f}. Symmetric contour mean {m['initial']['mask']['contour_mean_px']:.2f}px → {m['final']['mask']['contour_mean_px']:.2f}px, P95 {m['initial']['mask']['contour_p95_px']:.2f}px → {m['final']['mask']['contour_p95_px']:.2f}px. Visible face/wrist mean {m['initial']['joints']['visible_face_wrists_mean_px']:.2f}px → {m['final']['joints']['visible_face_wrists_mean_px']:.2f}px. All manual points mean {m['initial']['joints']['mean_px']:.2f}px → {m['final']['joints']['mean_px']:.2f}px.

`metrics.json` separately contains fixed final-camera initial versus final and fixed source-camera comparisons. Camera changes contribute to the raw improvement. `objective.json` records actual fixed final-objective initial/final costs; `parameter-block-history.json` records every pose/camera and cm shape/bone block including executed cm candidates. Waist moved72→{s['dimensions']['waist']}cm; arm ruler controls remained29/23cm after actual bounded trials. This is limited shape identifiability, not proof of true photographed measurements. Upper/forearm bone-head lengths are independently listed separately from surface ruler controls.

The approximate crop camera reaches yaw/pitch/center bounds. Its optimized orientation is a nuisance model, not calibrated photography. `camera.json` gives initial/final parameters, explicit photo and every-view3×4 world-to-pixel matrices, column-vector multiplication, axis/degree and pixel conventions. All front/side/back/closeup/pose/depth renders share identical final-state and posed OBJ hashes; only view cameras change.

## Actual visual inspection and limitations

Front, side and back were opened and inspected. Both elbows remain outside torso, both forearms return toward the front abdomen, palms and curled fingers approximate holding the shirt. Final side view no longer shows the first candidate's large forward reach, and the retained first rejected candidate is in `rejected-depth-ambiguous-round/`. The first candidate is not the delivered state. Wrist/finger closure and elbow depth constraints are explicit 3D action priors. Exact finger contact and palm orientation remain imperfect; no garment contact or tissue collision solver ran. The final wrist/forearm surfaces are close to abdomen; subtle self-contact is not certified collision-free. The side/back are unobserved hypotheses from the same mesh, never presented as real observed evidence. Hair/knit/clothing and cropped lower body explain residual silhouette differences. The mesh template head is not a reconstructed identity.

The neutral asset reconstruction check PASS verifies only model geometry/measurements. Actual OBJ/cm boundaries, finite vertices, mesh topology, raw-depth validity and matrix joint reprojection are in `geometry-audit.json`. Bounds/target errors in `independent-neutral-check.json`. Standing height comes from neutral mesh; posed bbox height is separately reported. Underbust, bust-point separation, waist lengths and crotch arc unavailable. Size prior and measured mesh values do not become real-person measurements.

## Run and consume

From repository root: `python {P.relative_to(ROOT)}/reproduce.py`. This starts solely from the supplied neutral M initial-state, runs all optimization blocks, renders actual outputs, reconstructs neutral measurement evidence and creates this report. `--export-only` re-renders the current run's state; `--continue` continues only this run's checkpoint.

See `load-link.txt`: serve repository root at8873 and open its same-origin Human Studio `?model=` link. `consumer-check.mjs` uses the real application's import/URL validation contract and HTTP-fetches this exact state; browser UI was not exercised. All163angles roundtrip exactly. Use actual editor Import to edit dimensions or pose further. Any edits create a new model and invalidate these frozen scores.
'''
(P/'report.md').write_text(report)
(P/'TRACE.md').write_text('''# Execution trace
1. Read repo AGENTS, eval3 prompt, fixture READMEs, skill-new/SKILL.md and all3 referenced contracts.
2. Opened actual original-product.jpg and inspected garment/target action; did not read private-oracle, product optimized states, or another executor output.
3. Created reusable SciPy optimizer on actual Human Studio calibrated MakeHuman shape, full FK/LBS. Camera and whole-body pose solve alternates with cm morph/bone trials. Started only supplied neutral M170 state.
4. Executed first optimization; opened actual front/side/back, rejected excessive forward hand reach despite low2D error; preserved rejected-depth-ambiguous-round evidence.
5. Added explicit shirt-holding elbow/hand/finger 3D priors, reran default reproduce.py from supplied neutral initial input. Full execution log final-reproduction.log; all candidate/block values in parameter-block-history.json. Initial/final objective in objective.json.
6. Exported actual neutral/posed centimetre OBJ,163world-joints, full pose, explicit camera matrices, six actual same-mesh renders, raw Z-buffer and valid mask, native photo masks/overlays and frozen-camera comparisons.
7. Ran independent skill inspect_human_state against matching human.json; PASS neutral mesh checked. Opened final front/side/back; recorded imperfect fingers and collision limitations in report.
8. Served repository root loopback8873; ran consumer-check.mjs against actual consumer state-contract and same-origin HTTP state; PASS163angles exact. Delivered local editable Human Studio load link; no browser UI proof claimed.
9. Ran finalize.py: independently projected saved joints using saved matrices, checked actual OBJ topology/finite geometry/depth, made actual shaded photo-camera render and source overlay. No shared app, runtime or skill files modified; no commit.

Token accounting: unavailable/null. Paid/external image generation calls:0.
''')
images=['original-product.jpg','initial-overlay.png','final-overlay.png','photo-render-overlay.png','front.png','side.png','back.png','pose.png','depth.png']
(P/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Original photo one body — executed fit</title><style>body{font:16px system-ui;background:#eee;margin:24px}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:18px}img{width:100%;object-fit:contain;max-height:650px;background:white}figure{margin:0}a{color:#146}</style><h1>Original photo → one anatomical state</h1><p>Actual optimization and MakeHuman renders. Side/back are priors; imperfect contact remains. <a href="report.md">Report</a> · <a href="metrics.json">Metrics</a> · <a href="load-link.txt">Human Studio load link</a> · <a href="reproduce.py">Run</a></p><main>'+''.join(f'<figure><img src="{i}"><figcaption>{i}</figcaption></figure>' for i in images)+'</main>')
