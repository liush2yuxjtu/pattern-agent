# Actual Human Studio same-action editor

PASS: 41 executed checks. Old skill and its Human Studio, geometry-evidence and tools-and-evidence references used. No shared application/runtime/skill changes; no external generation. Chromium 156.0.8078.79 with isolated contexts, loopback 8922. Token usage: null (unknown).

Exact source bent/seated target action imported from fixture; actual UI inputs changed waist 76→79 cm, upper arm ruler 29→31 cm and forearm ruler 23→24 cm. Complete six-entry poseDegrees map preserved at every size edit, front/side/back view, save, reload and reimport. Unspecified joints remain zero under model contract. Front/side/back use one identical posed mesh hash, separate actual recorded camera matrices and distinct rendered pixels.

Actual full geometry: 13,380 vertices, 26,756 triangles, 163 rig bones. Actual OBJ downloaded from UI; max vertex deviation from renderer 8.533834140000779e-7 cm. Dimensions are mesh parameters, not estimates of a real person.

| Measurement | Before cm | After cm |
|---|---:|---:|
| Neutral height | 180.00001525878906 | 179.99998474121094 |
| Neutral waist | 76.00003748729519 | 79.000000799199 |
| Neutral upperArmLength | 29.000078356367435 | 31.000003535271738 |
| Neutral forearmLength | 23.000007423971546 | 24.000158061639667 |
| Posed bounding-box height | 132.67235627884986 | 132.6724021397045 |
| Actual bone-head upperArm.L | 26.6826858258548 | 28.70079364471707 |
| Actual bone-head forearm.L | 23.254219073753582 | 24.260502988699766 |
| Actual bone-head upperArm.R | 26.6826858258548 | 28.70079364471707 |
| Actual bone-head forearm.R | 23.254219073753582 | 24.260502988699766 |

Neutral tape/landmark dimensions independently reconstructed using the exact fingerprinted human.json and old skill inspect_human_state.py. Bone-head lengths are actual world joint distances, separate from mesh landmark ruler lengths. Posed bounding-box height describes the bent action, not standing height. Joint skinning does not establish tissue collision or physical fit.

Invalid imports tested current version, asset, cm units, bounds, types, unknown joints, pose limits and weights, atomically rejecting without state changes. Actual number UI tested off-step, excessive value and empty input; imported off-step dimensions/angles and cache normalization tested in isolated contexts. Legacy version/wrong asset caches ignored. Actual 375px mobile context loaded final state with no horizontal overflow. Browser page errors/failed requests: zero. Screenshots are real app captures, not generated photographs.

Reproduce: node reproduce.cjs from this repository checkout. It serves repository root on its own loopback port, executes the UI, creates outputs here and closes its browser/server. It probes camera matrices through a read-only camera update observer in this isolated page; no shared source edits.

Implementation debugging retained in attempt-1-TRACE.md/attempt-1-failure.json and attempt-2-TRACE.md/attempt-2-failure.json. The first camera probe targeted an instance-owned renderer method; it was replaced with a camera matrix update observer. The second checker compared JSON insertion order; canonical object comparison and measured vertex tolerance now verify semantic pose equality and geometry. These were verifier issues; the final executed run passed all 41 checks.

Visual review: actual front, side, back and 375px captures inspected. The bent elbows and flexed hips/knees retain the source seated action. No physical collision or anatomical validity certification is claimed.
