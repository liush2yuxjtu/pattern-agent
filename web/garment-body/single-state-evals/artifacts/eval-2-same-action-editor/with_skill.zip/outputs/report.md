# Real Human Studio same-action editor — PASS

Executed the specified skill-new/SKILL.md and its human-studio, geometry-evidence, and tools-and-evidence references against the actual repository application. Standalone Chromium, separate browser context/localStorage, loopback repository-root server on 127.0.0.1:8921. No app, runtime or skill changes; no private-oracle or other executor outputs read. No external generation. Token usage: null (unavailable).

## Actual consumer workflow

Imported the exact fixture JSON through the real Import/file input, preserving its complete six-entry pose map. Entered waist 76→79cm, upperArmLength 29→31cm and forearmLength 23→24cm through real number inputs and Tab/change events. The seated/bent-elbow target action and all saved local joint rotations remain exactly unchanged. Used real Front, Side and Back buttons, Save model, PNG 2× and Export OBJ. Reloaded cache, imported source again, then reimported the actual downloaded final JSON. All 33 assertions passed with no page runtime errors.

Maximum posed vertex displacement: 2.030751414cm. Actual rendered OBJ vertices match the final getGeometry surface within 0.001cm. This is anatomical skinning, not a collision or physical tissue simulation.

## Neutral dimensions and actual bones

Independent matching-asset reconstruction in neutral-reconstruction-check.json passed (maximum target residual 0.000159cm). Rendered rest-mesh path measurements independently recomputed from actual vertices:

| Dimension | Before target | Final mesh cm | Definition |
|---|---:|---:|---|
| Waist | 76 | 79.000001 | Neutral surface tape path |
| Upper-arm length | 29 | 31.000004 | Neutral landmark distance |
| Forearm length | 23 | 24.000158 | Neutral landmark distance |
| Standing height | 180 | 179.999985 | Neutral standing mesh height |

Actual left and right shoulder→elbow bone-head distances: 26.682686→28.700794cm (+2.018108cm). Actual elbow→wrist bone-head distances: 23.254219→24.260503cm (+1.006284cm). These differ from the ruler landmark definitions. World joint coordinates change with the modified shape despite identical local angles. Final posed bounding-box height: 132.672402cm, separately from 180cm neutral height. All values describe mesh parameters, not a measured photographed human.

## One body across cameras

Each of front.png, side.png and back.png is an actual PNG 2× export, with full UI screenshots alongside. All have state hash `842adad0ad5bf2e46d72af8c271bcf8aec57b385b12a4c481d3f885bad0fd6a6`, posed mesh hash `bee4109a2b78f820ec1061fb3f9d2ee6b7800a44b5aa8ac4ecd5077a59549004` and pose hash `46e4e9c639a8e0487b84799978ed799f9841c68b98d95866b2065ef38324b77a`. The three image hashes differ. view-states.json records full state, geometry identity, actual screen projection bounds and UI camera protocol. The app does not expose camera matrices; none are invented. Thus exact matrix restoration beyond the documented UI camera buttons is not claimed.

## Boundaries and mobile

Rejected incompatible version/asset/units, string dimensions, out-of-range import dimensions and >180° import angles without changing the current model. Off-step JSON/UI values normalized to the actual 0.1 step; blank input restored the current value and out-of-range UI input clamped. Reloaded old-version, off-step, invalid-type and out-of-range cache cases using only this isolated browser profile; finite normalized state and old cache isolation passed. Cache input and resulting full snapshots are saved separately. Final state was restored after every case.

At 375×812, document scrollWidth was 375px: no horizontal overflow. The actual side view button still worked and retained the final state. mobile-375.png and mobile-side.png are full-page narrow-screen evidence. Side screenshot visibly retains the seated target action; anatomical self-collision has not been independently audited.

## Reproduction

From repository root: `node work/single-state-skill-evals-20261117/iteration-1/eval-2-same-action-editor/with_skill/run-1/outputs/reproduce.cjs` (requires existing Playwright and /usr/bin/chromium; REPO_ROOT can override checkout). The script starts its own root server and closes its own browser/server in finally. Separately executed the skill's `inspect_human_state.py --state final-state.json --asset-json web/human-studio/assets/human.json --expected-asset a75b6a2d59b2fa60ea29393e380182174627ba66d0993c649c8c571a6ccecda6 --require-match` and saved neutral-reconstruction-check.json. Server and browser have closed after this run. No commit was made under the task's explicit instruction.

Inputs and outputs are bound by SHA-256 in results.json, view-states.json and manifest.json. Complete geometry-before/after include rest/posed vertices, original indices/bodyVertexIds and all world bone heads. Compact posed arrays must use bodyVertexIds to remap indices.
