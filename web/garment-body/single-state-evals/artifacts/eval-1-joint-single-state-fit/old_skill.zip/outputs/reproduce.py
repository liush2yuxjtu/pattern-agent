#!/usr/bin/env python3
from pathlib import Path
import sys,json,copy,time,hashlib,subprocess
import numpy as np,cv2
from scipy.optimize import least_squares, minimize_scalar
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'web/human-studio/assets/human.json').exists())
BASE=ROOT/'work/single-state-skill-evals-20261117'; FIX=BASE/'fixtures/joint-fit'; OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'fixtures'));from runtime import Runtime,sha
DKEY=['waist','upperArmLength','forearmLength'];PKEY=[('upperarm01.L',2),('upperarm01.R',2),('lowerarm01.L',0),('lowerarm01.R',0),('wrist.L',2),('wrist.R',2)]
def dump(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n')
def main():
 start=time.time();r=Runtime();history=[]
 try:
  init=json.loads((FIX/'initial-state.json').read_text());cam0=json.loads((FIX/'camera.json').read_text());ref=json.loads((FIX/'reference-joints.json').read_text())['views']
  masks={v:cv2.imread(str(FIX/f'reference-{v}-mask.png'),0) for v in ref}
  x=np.array([init['dimensions'][k] for k in DKEY]+[init['poseDegrees'][n][a] for n,a in PKEY]+[cam0['views']['front']['px_per_cm']]+cam0['views']['front']['center_cm'],float)
  lo=np.array([64,26,20,-35,-35,15,15,-40,-40,1.8,-8,75]);hi=np.array([80,33,27,35,35,110,110,40,40,2.8,8,95])
  def statecam(x):
   s=copy.deepcopy(init);c=copy.deepcopy(cam0)
   for k,v in zip(DKEY,x[:3]):s['dimensions'][k]=round(float(v),1)
   for (n,a),v in zip(PKEY,x[3:9]):s['poseDegrees'][n][a]=float(v)
   for v in ['front','side','back','pose','depth']:c['views'][v].update(px_per_cm=float(x[9]),center_cm=x[10:12].tolist())
   return s,c
  count=0
  def residual(x):
   nonlocal count
   count+=1;s,c=statecam(x);ev=r.evaluate(s,skin=False)
   return np.concatenate([(r.project(ev['joints'],c,v)[[r.index[t['joint']] for t in rows]]-np.array([t['pixel'] for t in rows])).ravel() for v,rows in ref.items()])
  def record(label,x,extra=None):
   s,c=statecam(x);row=dict(block=label,dimensions=s['dimensions'],pose_fit={n:s['poseDegrees'][n] for n,a in PKEY},camera=c['views']['front'],joint_rmse_px=float(np.sqrt(np.mean(residual(x)**2))),elapsed_seconds=time.time()-start)
   if extra:row.update(extra)
   history.append(row);dump(OUT/'parameter-block-history.json',history);print(label,row['joint_rmse_px'],s['dimensions'],flush=True)
  initial_x=x.copy();record('initial',x)
  # Central finite differences use practical cm probes above source 0.1cm quantization.
  def jac(x):
   steps=np.array([.2,.2,.2,.03,.03,.03,.03,.03,.03,.001,.01,.01]);cols=[]
   for i,h in enumerate(steps):
    a=x.copy();b=x.copy();a[i]=min(hi[i],x[i]+h);b[i]=max(lo[i],x[i]-h);cols.append((residual(a)-residual(b))/(a[i]-b[i]))
   return np.array(cols).T
  for iteration in range(3):
   # Wrist twist cannot affect wrist-head annotations; fix it until silhouette stage.
   active=[0,1,2,3,4,5,6,9,10,11];base=x.copy()
   def expand(y):z=base.copy();z[active]=y;return z
   sol=least_squares(lambda y:residual(expand(y)),x[active],jac=lambda y:jac(expand(y))[:,active],bounds=(lo[active],hi[active]),max_nfev=22,xtol=1e-7,ftol=1e-8,gtol=1e-7,x_scale='jac')
   x=expand(sol.x);x[:3]=np.round(x[:3],1);record('joint_shape_pose_camera_'+str(iteration),x,dict(scipy_status=int(sol.status),nfev=sol.nfev))
  def maskloss(z):
   s,c=statecam(z);e=r.evaluate(s);loss=0
   for v,m in masks.items():
    q=r.mask(e['posed'],c,v)>0;t=m>0;loss+=1-np.count_nonzero(q&t)/np.count_nonzero(q|t)
   return float(loss)
  record('silhouette_initial',x,dict(mask_loss=maskloss(x)))
  # Discrete cm waist search; wrist angles optimize actual LBS masks, not projected head positions.
  for cycle in range(2):
   for i,grid in [(0,np.arange(64,80.01,.5 if cycle==0 else .1)),(7,np.arange(-22,22.1,2 if cycle==0 else .5)),(8,np.arange(-22,22.1,2 if cycle==0 else .5))]:
    if cycle and i==0:grid=np.arange(max(64,x[i]-.6),min(80,x[i]+.6)+.01,.1)
    if cycle and i in (7,8):grid=np.arange(max(-40,x[i]-3),min(40,x[i]+3)+.01,.5)
    vals=[]
    for a in grid:z=x.copy();z[i]=a;vals.append(maskloss(z))
    x[i]=float(grid[np.argmin(vals)]);record(['waist','left_wrist','right_wrist'][[0,7,8].index(i)]+'_silhouette_'+str(cycle),x,dict(mask_loss=min(vals)))
  # 0.1 degree export/UI normalization and final full LBS evaluation.
  x[3:9]=np.round(x[3:9],1);s,c=statecam(x);record('final',x,dict(mask_loss=maskloss(x),objective_evaluations=count))
  r.save(init,cam0,OUT/'source-camera-initial',views=['front','side'])
  r.save(init,c,OUT/'final-camera-initial',views=['front','side'])
  final=r.save(s,c,OUT,views=['front','side','back','closeup','pose','depth']);(OUT/'state.json').rename(OUT/'final-state.json')
  dump(OUT/'initial-state.json',init);dump(OUT/'initial-camera.json',cam0)
  # Preserve provenance reference to renamed state; bytes unchanged.
  prov=json.loads((OUT/'view-provenance.json').read_text());assert len({v['posed_mesh_sha256'] for v in prov.values()})==1
  metrics={};comparisons=[('source_camera_initial',init,cam0),('final_camera_initial',init,c),('final_camera_final',final,c)]
  for label,st,ca in comparisons:
   ev=r.evaluate(st);metrics[label]={}
   for v,t in masks.items():
    q=r.mask(ev['posed'],ca,v)>0;t=t>0;inter=np.count_nonzero(q&t);union=np.count_nonzero(q|t)
    cq=cv2.morphologyEx(q.astype('uint8'),cv2.MORPH_GRADIENT,np.ones((3,3),np.uint8))>0;ct=cv2.morphologyEx(t.astype('uint8'),cv2.MORPH_GRADIENT,np.ones((3,3),np.uint8))>0
    dtq=cv2.distanceTransform((~cq).astype('uint8'),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);dtt=cv2.distanceTransform((~ct).astype('uint8'),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);dist=np.r_[dtq[ct],dtt[cq]]
    joints=r.project(ev['joints'],ca,v)[[r.index[z['joint']] for z in ref[v]]];target=np.array([z['pixel'] for z in ref[v]])
    metrics[label][v]=dict(IoU=inter/union,Dice=2*inter/(q.sum()+t.sum()),symmetric_contour_mean_px=float(dist.mean()),symmetric_contour_p95_px=float(np.percentile(dist,95)),joint_mean_euclidean_px=float(np.linalg.norm(joints-target,axis=1).mean()))
    overlay=cv2.imread(str(FIX/f'reference-{v}.png'));overlay[t&q]=(0,220,0);overlay[t&~q]=(220,0,220);overlay[q&~t]=(220,220,0)
    cv2.imwrite(str(OUT/f'{label}-{v}-overlay.png'),overlay);cv2.imwrite(str(OUT/f'{label}-{v}-mask.png'),q.astype('uint8')*255)
  dump(OUT/'metrics.json',metrics)
  ev=r.evaluate(final);rest=ev['shape']['rest'];measure={}
  # Independent measurements on actual reconstructed coordinates and landmark paths.
  for ctrl in r.data['controls']:
   path=ctrl.get('path',[]);value=float(np.linalg.norm(np.diff(rest[np.asarray(path,int)],axis=0),axis=1).sum()) if path else float(np.ptp(rest[r.ids,1]))
   measure[ctrl['key']]=dict(value_cm=value,target_cm=final['dimensions'][ctrl['key']],method='standing_height' if ctrl['key']=='height' else ('landmark_ruler_path' if 'Length' in ctrl['key'] or ctrl['key']=='shoulders' else 'surface_tape_path'),basis='prior' if ctrl['key']=='height' else 'mesh_parameter')
  bones={}
  for side in ['L','R']:
   names=[f'upperarm01.{side}',f'lowerarm01.{side}',f'wrist.{side}'];idx=[r.index[n] for n in names]
   bones[side]={'upperarm_head_distance_cm':float(np.linalg.norm(ev['shape']['heads'][idx[1]]-ev['shape']['heads'][idx[0]])),'forearm_head_distance_cm':float(np.linalg.norm(ev['shape']['heads'][idx[2]]-ev['shape']['heads'][idx[1]]))}
  dump(OUT/'measurements.json',dict(neutral=measure,bone_head_distances=bones,neutral_mesh_sha256=sha(OUT/'neutral.obj'),posed_bbox_height_cm=float(np.ptp(ev['posed'][r.ids,1]))))
  (OUT/'measurements.csv').write_text('name,value_cm,target_cm,definition\n'+'\n'.join(f'{k},{v["value_cm"]},{v["target_cm"]},{v["method"]}' for k,v in measure.items())+'\n')
  raw=np.load(OUT/'rawdepth.npy');valid=cv2.imread(str(OUT/'depth-valid.png'),0)>0
  dump(OUT/'validation.json',dict(finite_vertices=bool(np.isfinite(ev['posed']).all()),surface_vertices=len(r.ids),triangles=len(r.faces),complete_pose_count=len(final['poseDegrees']),single_shared_state=len({v['state_sha256'] for v in prov.values()})==1,single_mesh=len({v['posed_mesh_sha256'] for v in prov.values()})==1,depth_valid_pixels=int(valid.sum()),depth_finite_valid=bool(np.isfinite(raw[valid]).all()),depth_valid_range_cm=[float(raw[valid].min()),float(raw[valid].max())],depth_definition='signed front-axis Z coordinate cm, nearest maximum; background -inf',runtime_seconds=time.time()-start))
  cameras={}
  for name,v in c['views'].items():
   scale=v['px_per_cm'];cx,cy=v['center_cm'];axis=v['axis']
   horizontal=[0,0,1] if axis=='side' else [-1 if axis=='back' else 1,0,0]
   matrix=[[scale*a for a in horizontal]+[c['width']/2-cx*scale],[0,-scale,0,c['height']/2+cy*scale],[0,0,0,1]]
   cameras[name]=dict(world_to_pixel_affine_3x4=matrix,projection='orthographic',depth_axis=[1,0,0] if axis=='side' else [0,0,-1 if axis=='back' else 1],depth_clip_cm=c['depth_range_cm'],pixel_convention='u right, v down; camera center at width/2,height/2; cm world')
  dump(OUT/'camera-projection-contract.json',cameras)
  jointmeta={}
  for name in c['views']:
   pixels=r.project(ev['joints'],c,name)
   jointmeta[name]=[dict(name=n,parent=r.bones[i]['parent'],world_cm=ev['joints'][i].tolist(),pixel=pixels[i].tolist(),inside_canvas=bool(0<=pixels[i,0]<c['width'] and 0<=pixels[i,1]<c['height']),occlusion='not classified') for i,n in enumerate(r.names)]
  dump(OUT/'pose-world-projections.json',dict(poseDegrees=final['poseDegrees'],views=jointmeta,state_sha256=sha(OUT/'final-state.json'),posed_mesh_sha256=sha(OUT/'posed.obj')))
  spec=__import__('importlib.util',fromlist=['spec_from_file_location']);sp=spec.spec_from_file_location('independent_audit',BASE/'skill-old/scripts/inspect_human_state.py');audit=spec.module_from_spec(sp);sp.loader.exec_module(audit)
  dump(OUT/'independent-neutral-audit.json',audit.audit(final,r.asset.read_bytes(),require_match=True))
  manifest={str(p.relative_to(ROOT)):sha(p) for p in [FIX/'initial-state.json',FIX/'camera.json',FIX/'reference-joints.json',FIX/'reference-front.png',FIX/'reference-side.png',FIX/'reference-front-mask.png',FIX/'reference-side-mask.png',BASE/'fixtures/runtime.py',BASE/'fixtures/calibrate-worker.mjs',r.asset,BASE/'skill-old/SKILL.md']};dump(OUT/'input-hashes.json',manifest)
  (OUT/'report.md').write_text('# Executed single-state fit\n\nReal Human Studio cm calibration, 163-bone FK and real four-weight LBS were executed. SciPy joint fitting plus discrete actual silhouette fitting optimized waist, upper/forearm ruler lengths, arm rotations, wrist rotations, and one shared camera scale/center. Height remains 170cm prior. All other initial angles and dimensions are retained. Front/side observations alone were used.\n\nMetrics:\n```json\n'+json.dumps(metrics,indent=2)+'\n```\n\nFinal state: '+json.dumps({k:final['dimensions'][k] for k in DKEY})+'. Bone-head distances are separately in measurements.json and differ from surface ruler lengths. All six views bind to the same state, pose and actual posed OBJ hashes. Closeup has its own original declared camera; all standard cameras share optimized scale/center. Camera contribution is exposed by source-camera-initial versus final-camera-initial, and body contribution by final-camera-initial versus final-camera-final.\n\nDepth is signed camera-axis surface coordinate in cm, not distance from an optical center. Negative-infinite background is invalid. Masks retain triangle-edge fill pixels while exact barycentric Z-buffer excludes edge rounding pixels; depth-valid is authoritative for depth.\n\nControlled synthetic MakeHuman data only: no claims about real person dimensions, clothing, collision simulation or held-out back accuracy. Wrist twist is silhouette constrained; hidden geometry remains uncertain. No external or paid generation. Source reference pixels and full-frame 320×448 evaluation were unchanged.\n\nReproduce: `python '+str(Path(__file__).relative_to(ROOT))+'` from repository root. Outputs overwrite this run directory only.\n')
  (OUT/'TRACE.md').write_text('# Execution trace\n\nExplicit skill: work/single-state-skill-evals-20261117/skill-old/SKILL.md, with references/human-studio.md, geometry-evidence.md, tools-and-evidence.md. Read eval id 1 and fixture READMEs/runtime; visually inspected original front reference. No private-oracle, other executor or historical optimized state read.\n\nExecuted reproduce.py with NumPy/SciPy/OpenCV and one Node calibration worker. Each parameter block and elapsed time is recorded in parameter-block-history.json. Full initial and final meshes, source and final camera protocols, overlays and actual final six views were written. Worker closes in finally. No server/browser was started. Model token use is unavailable and is not fabricated. Python execution wall time is in validation.json; this is not model thinking time.\n')
 finally:r.close()
if __name__=='__main__':main()
