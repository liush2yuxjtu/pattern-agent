# Executed single-state fit

Real Human Studio cm calibration, 163-bone FK and real four-weight LBS were executed. SciPy joint fitting plus discrete actual silhouette fitting optimized waist, upper/forearm ruler lengths, arm rotations, wrist rotations, and one shared camera scale/center. Height remains 170cm prior. All other initial angles and dimensions are retained. Front/side observations alone were used.

Metrics:
```json
{
  "source_camera_initial": {
    "front": {
      "IoU": 0.6967737634982002,
      "Dice": 0.821292476920055,
      "symmetric_contour_mean_px": 4.366281986236572,
      "symmetric_contour_p95_px": 12.815897941589355,
      "joint_mean_euclidean_px": 9.859774149417479
    },
    "side": {
      "IoU": 0.696967950195988,
      "Dice": 0.8214273582662455,
      "symmetric_contour_mean_px": 4.169012069702148,
      "symmetric_contour_p95_px": 11.313708305358887,
      "joint_mean_euclidean_px": 9.179679954261088
    }
  },
  "final_camera_initial": {
    "front": {
      "IoU": 0.8644081119320861,
      "Dice": 0.927273493823517,
      "symmetric_contour_mean_px": 1.827695608139038,
      "symmetric_contour_p95_px": 10.29563045501709,
      "joint_mean_euclidean_px": 4.666879828828579
    },
    "side": {
      "IoU": 0.8784572095257703,
      "Dice": 0.9352964816776881,
      "symmetric_contour_mean_px": 1.3105978965759277,
      "symmetric_contour_p95_px": 11.401754379272461,
      "joint_mean_euclidean_px": 4.55206445318905
    }
  },
  "final_camera_final": {
    "front": {
      "IoU": 1.0,
      "Dice": 1.0,
      "symmetric_contour_mean_px": 0.0,
      "symmetric_contour_p95_px": 0.0,
      "joint_mean_euclidean_px": 9.54157388020706e-14
    },
    "side": {
      "IoU": 1.0,
      "Dice": 1.0,
      "symmetric_contour_mean_px": 0.0,
      "symmetric_contour_p95_px": 0.0,
      "joint_mean_euclidean_px": 9.54157388020706e-14
    }
  }
}
```

Final state: {"waist": 68, "upperArmLength": 29.5, "forearmLength": 23.5}. Bone-head distances are separately in measurements.json and differ from surface ruler lengths. All six views bind to the same state, pose and actual posed OBJ hashes. Closeup has its own original declared camera; all standard cameras share optimized scale/center. Camera contribution is exposed by source-camera-initial versus final-camera-initial, and body contribution by final-camera-initial versus final-camera-final.

Depth is signed camera-axis surface coordinate in cm, not distance from an optical center. Negative-infinite background is invalid. Masks retain triangle-edge fill pixels while exact barycentric Z-buffer excludes edge rounding pixels; depth-valid is authoritative for depth.

Controlled synthetic MakeHuman data only: no claims about real person dimensions, clothing, collision simulation or held-out back accuracy. Wrist twist is silhouette constrained; hidden geometry remains uncertain. No external or paid generation. Source reference pixels and full-frame 320×448 evaluation were unchanged.

Reproduce: `python work/single-state-skill-evals-20261117/iteration-1/eval-1-joint-single-state-fit/old_skill/run-1/outputs/reproduce.py` from repository root. Outputs overwrite this run directory only.

Independent saved morph reconstruction: PASS (independent-neutral-audit.json), max neutral target residual 0.00005228cm. Observed final front/side/back and raw depth visualization; no gross pose reset. Real arm head distances are 27.35535cm upper arm and 23.71731cm forearm, versus ruler lengths 29.5cm and 23.5cm. This is an exact controlled fixture reconstruction, not a measurement of a real person.
