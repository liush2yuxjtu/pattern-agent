# Execution trace

Explicit skill: work/single-state-skill-evals-20261117/skill-old/SKILL.md, with references/human-studio.md, geometry-evidence.md, tools-and-evidence.md. Read eval id 1 and fixture READMEs/runtime; visually inspected original front reference. No private-oracle, other executor or historical optimized state read.

Executed reproduce.py with NumPy/SciPy/OpenCV and one Node calibration worker. Each parameter block and elapsed time is recorded in parameter-block-history.json. Full initial and final meshes, source and final camera protocols, overlays and actual final six views were written. Worker closes in finally. No server/browser was started. Model token use is unavailable and is not fabricated. Python execution wall time is in validation.json; this is not model thinking time.

Post-run independently reconstructed neutral mesh with the old skill inspect_human_state.py audit: PASS, max target residual 0.00005228cm. Added explicit orthographic world-to-pixel affine contracts and all 163 joint projections/inside-canvas flags. Visually inspected actual final front, side, back and depth images; bent arms remain in the same action, no A-pose reset. Both calibration worker PIDs exited.
