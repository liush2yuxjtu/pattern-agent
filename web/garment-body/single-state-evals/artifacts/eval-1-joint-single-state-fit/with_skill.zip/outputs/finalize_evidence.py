from pathlib import Path
import json,hashlib,numpy as np,cv2
O=Path(__file__).resolve().parent
load=lambda n:json.loads((O/n).read_text())
def dump(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=load('final-state.json');c=load('camera.json');m=load('metrics.json');h=load('parameter-block-history.json');j=load('joints.json')['joints'];prov=load('view-provenance.json');mats={};projected={}
for name,v in c['views'].items():
 a=v['axis'];sc=v['px_per_cm'];cx,cy=v['center_cm'];mat=np.zeros((3,4));mat[0,2 if a=='side' else 0]=sc*(-1 if a=='back' else 1);mat[0,3]=c['width']/2-sc*cx;mat[1,1]=-sc;mat[1,3]=c['height']/2+sc*cy;mat[2,3]=1
 depth=np.zeros(4);depth[0 if a=='side' else 2]=-1 if a=='back' else 1
 mats[name]={'world_cm_to_pixel_homogeneous_3x4':mat.tolist(),'depth_coordinate_1x4':depth.tolist(),'projection':'orthographic; image origin top left; nearest surface largest depth; depth_range_cm is visualization interval, not clipping; no perspective near/far clipping'}
 rows=[]
 for q in j:
  uv=mat@np.r_[q['position'],1];rows.append(dict(name=q['name'],parent=q['parent'],world_cm=q['position'],pixel=uv[:2].tolist(),inside_canvas=bool(0<=uv[0]<c['width'] and 0<=uv[1]<c['height']),occlusion='not classified'))
 projected[name]={'joints':rows,'state_sha256':prov[name]['state_sha256'],'posed_mesh_sha256':prov[name]['posed_mesh_sha256']}
dump('camera-matrices.json',mats);dump('pose-world-projected-joints.json',projected)
v=[];faces=[]
for l in (O/'posed.obj').read_text().splitlines():
 t=l.split()
 if t and t[0]=='v':v.append(list(map(float,t[1:4])))
 if t and t[0]=='f':faces.append([int(x)-1 for x in t[1:4]])
v=np.array(v);f=np.array(faces);ed=np.sort(np.concatenate([f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]]),axis=1);_,counts=np.unique(ed,axis=0,return_counts=True)
dump('geometry-check.json',dict(vertices=len(v),triangles=len(f),finite_vertices=bool(np.isfinite(v).all()),face_indices_valid=bool(f.min()>=0 and f.max()<len(v)),boundary_edges=int((counts==1).sum()),nonmanifold_edges=int((counts>2).sum()),bounds_cm=[v.min(0).tolist(),v.max(0).tolist()],all_six_same_state=len({x['state_sha256'] for x in prov.values()})==1,all_six_same_pose=len({x['pose_sha256'] for x in prov.values()})==1,all_six_same_mesh=len({x['posed_mesh_sha256'] for x in prov.values()})==1,collision_check='not run; real LBS is not collision simulation'))
me=load('measurements.json');run=load('run.json')
text='''# Executed single-body joint fit

This run used the explicitly requested new skill snapshot and the public joint-fit fixture, actual Human Studio fitDimensions calibration and full 163-bone FK/LBS. Reference images were visually inspected before fitting. They depict a controlled anatomical MakeHuman body with bent arms; they are not real-person photographs. Height remains the disclosed 170cm prior. No external generation was invoked.

A reusable optimizer was implemented and executed: practical-step least-squares jointly fit waist/arm ruler controls, upper-arm Z and elbow X rotations, and one common orthographic camera scale/center, followed by silhouette coordinate searches for waist and wrist Z. All other local joint angles were retained. Three alternating rounds were run. Wrist rotations are unobservable from wrist-head points and were selected using silhouettes. Parameters and losses for every block, including temporary regressions, are in parameter-block-history.json; no reference image, mask, ROI, or annotation was changed.

## Measured results

|Protocol|Front IoU|Side IoU|Front joint RMSE px|Side joint RMSE px|
|---|---:|---:|---:|---:|
'''
for key in ['initial_source_camera','initial_final_camera','final_source_camera','final_final_camera']:
 a=m[key];text+=f"|{key}|{a['front']['IoU']:.8f}|{a['side']['IoU']:.8f}|{a['front']['joint_RMSE_px']:.8f}|{a['side']['joint_RMSE_px']:.8f}|\n"
text+='\nCommon final camera: '+json.dumps(c['views']['front'])+'. Evaluation uses the unchanged full 320×448 supplied canvases. Four protocols separate camera and body contributions; overlays use green overlap, magenta reference-only and cyan model-only. The weakest final view is '+min(['front','side'],key=lambda x:m['final_final_camera'][x]['IoU'])+'. Full Dice and symmetric contour mean/P95 are in metrics.json.\n\n'
text+='Final requested/independently reconstructed neutral surface-ruler sizes (cm):\n\n|Control|Requested|Measured neutral|\n|---|---:|---:|\n'
for k in ['height','waist','upperArmLength','forearmLength']:text+=f"|{k}|{s['dimensions'][k]:.3f}|{s['measuredNeutral'][k]:.6f}|\n"
text+='\nMaximum cm target residual: '+str(s['maximumTargetErrorCm'])+'. Independent neutral reconstruction: independent-neutral-check.json (matching asset, serialized morph coefficients, actual tape/landmark definitions). Posed bounding-box height is '+str(me['posed_bbox_height_cm'])+'cm and is not a new stature measurement. Actual bone-head segments are separately listed in measurements.json:\n\n'
for a in me['actual_bone_head_distances']:text+=f"- {a['name']}: neutral {a['neutral_cm']:.6f}cm, posed {a['posed_cm']:.6f}cm.\n"
text+='''
## Artifacts and limits

final-state.json is the single complete importable state; camera.json is separate. neutral.obj and posed.obj are actual surface meshes in Y-up cm. All six images bind to the same state/pose/posed-mesh hashes in view-provenance.json. World and projected joints include canvas visibility, without an occlusion claim. Camera image/depth transforms are explicit in camera-matrices.json. rawdepth.npy stores actual front-camera Z coordinates in cm, background -inf, with depth-valid.png; depth.png is visualization only.

front/side/back/closeup/pose/depth PNGs are actual geometry images, not clothing generations; closeup shows anatomical mesh, without invented garment texture or seams. The back view is inferred from the shared fitted state and was not an observed training view. viewer.html loads the saved actual posed.obj and enables camera views. It does not independently re-fit or alter the body. Human Studio can import final-state.json for editable cm/pose controls.

The controlled fixture permits internal geometry consistency conclusions only. These values are not measurements of a real person. Rendering uses the provided orthographic rasterizer. LBS has no tissue/collision simulation; a formal self-intersection/body-penetration test was not run. Point alignment does not establish unique human anatomy, and the withheld back target was not accessed. No private target, previous fit, or other executor output was read. Model token usage is unavailable and is left null. Numeric run duration is recorded in run.json, excluding report assembly.

Reproduce from any directory with `python PATH/TO/outputs/reproduce.py`, using the repository asset/runtime and NumPy, SciPy, OpenCV, Node already installed. The worker is closed in a finally block. Run `python PATH/TO/outputs/finalize_evidence.py` to rebuild report/verification metadata after fitting. No server or browser was started, and no shared app/runtime/skill was edited. No commit was made per this evaluation's explicit instruction.
'''
(O/'report.md').write_text(text)
(O/'TRACE.md').write_text('''# Execution trace

1. Read repository AGENTS.md, evals.json id1, explicitly requested skill-new/SKILL.md, its human-studio / geometry-evidence / tools-and-evidence references, fixture README files and runtime source. Did not read private-oracle or old fitted states.
2. Inspected the actual front/side reference images at their supplied 320x448 size. Read public initial state, camera and 2D joint annotations.
3. Implemented reproduce.py inside this run output only. Started one persistent Node calibration worker via Runtime. Runtime uses actual MakeHuman morph calibration, bone-head extraction, full FK and four-weight LBS.
4. Executed three joint/shape/bone/pose/camera least-squares rounds with practical cm finite differences and per-round silhouette searches. optimization.log is actual stdout/stderr. parameter-block-history.json records all accepted blocks with elapsed wall time, parameters and metrics.
5. Exported actual initial/final surfaces, six final geometry views, Z buffer, source/final camera comparisons and OpenCV overlays at original resolution; retained fixed input hashes.
6. Independently reconstructed neutral surface dimensions using the skill's inspect_human_state.py --require-match against the actual asset. Wrote bone-head distances separately. Parsed exported OBJ to verify finite vertices, valid faces, boundary/nonmanifold edge counts, bounds, and per-view shared state/pose/mesh hashes.
7. Assembled camera matrices, complete world/projected joint metadata, report and local actual mesh viewer. Visual inspection covers front/side references and the saved front/side/back render contact sheet; this is not a formal collision check.
8. Worker termination is in Runtime.close() in finally. No browser/server started; no shared files changed; no commit. API/model token count is unknown, not estimated. Run timing is measured with time.time and available in run.json.
''')

initial_j={x['name']:np.array(x['position']) for x in load('initial-source-camera/joints.json')['joints']}
final_j={x['name']:np.array(x['position']) for x in j}
segments=[]
for side in ['L','R']:
 for a,b in [('upperarm01','lowerarm01'),('lowerarm01','wrist')]:
  n1=a+'.'+side;n2=b+'.'+side;before=float(np.linalg.norm(initial_j[n1]-initial_j[n2]));after=float(np.linalg.norm(final_j[n1]-final_j[n2]));segments.append(dict(segment=[n1,n2],initial_actual_head_distance_cm=before,final_actual_head_distance_cm=after,change_cm=after-before))
def vertices(path):return np.array([list(map(float,l.split()[1:4])) for l in path.read_text().splitlines() if l.startswith('v ')])
a=vertices(O/'initial-source-camera/neutral.obj');b=vertices(O/'neutral.obj');d=np.linalg.norm(a-b,axis=1)
dump('actual-shape-bone-change.json',dict(bone_head_segments=segments,neutral_surface_vertex_displacement_mean_cm=float(d.mean()),neutral_surface_vertex_displacement_max_cm=float(d.max()),changed_vertices=int((d>1e-8).sum()),definition='actual initial/final exported OBJ and actual FK world joint heads; no requested-ruler substitution'))
for row in h:
 row['normalized_dimensions']={**load('initial-state.json')['dimensions'],**{k:round(row['parameters'][k],1) for k in ['waist','upperArmLength','forearmLength']}}
dump('parameter-block-history.json',h)
