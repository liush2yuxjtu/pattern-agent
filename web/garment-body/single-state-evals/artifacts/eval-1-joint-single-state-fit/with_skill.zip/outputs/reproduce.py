#!/usr/bin/env python3
"""Executed joint fit. Inputs are exclusively the public fixture and source asset/runtime."""
import sys,json,copy,time,hashlib,csv,subprocess
from pathlib import Path
import numpy as np,cv2
from scipy.optimize import least_squares, minimize_scalar
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'web/human-studio/assets/human.json').exists())
FIX=ROOT/'work/single-state-skill-evals-20261117/fixtures';sys.path.insert(0,str(FIX))
from runtime import Runtime,sha
OUT=Path(__file__).resolve().parent
IN=FIX/'joint-fit'
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def metrics(a,b):
 a=a>0;b=b>0;inter=(a&b).sum();union=(a|b).sum()
 ca=cv2.morphologyEx(a.astype('uint8'),cv2.MORPH_GRADIENT,np.ones((3,3),np.uint8))>0
 cb=cv2.morphologyEx(b.astype('uint8'),cv2.MORPH_GRADIENT,np.ones((3,3),np.uint8))>0
 da=cv2.distanceTransform((~ca).astype('uint8'),cv2.DIST_L2,5);db=cv2.distanceTransform((~cb).astype('uint8'),cv2.DIST_L2,5)
 d=np.r_[da[cb],db[ca]]
 return dict(IoU=float(inter/union),Dice=float(2*inter/(a.sum()+b.sum())),symmetric_contour_mean_px=float(d.mean()),symmetric_contour_p95_px=float(np.percentile(d,95)))
def overlay(ref,mask,photo):
 a=ref>0;b=mask>0;c=photo.copy();color=np.zeros_like(c);color[a&b]=(0,210,0);color[a&~b]=(210,0,210);color[b&~a]=(210,210,0);c[a|b]=(0.35*c[a|b]+.65*color[a|b]).astype('uint8');return c

def main():
 start=time.time();r=Runtime();history=[]
 try:
  initial=json.loads((IN/'initial-state.json').read_text());cam0=json.loads((IN/'camera.json').read_text());obs=json.loads((IN/'reference-joints.json').read_text())['views']
  refs={v:cv2.imread(str(IN/f'reference-{v}-mask.png'),0) for v in obs};photos={v:cv2.imread(str(IN/f'reference-{v}.png')) for v in obs}
  dims=['waist','upperArmLength','forearmLength'];poses=[('upperarm01.L',2),('upperarm01.R',2),('lowerarm01.L',0),('lowerarm01.R',0),('wrist.L',2),('wrist.R',2)]
  names=dims+[f'{k}[{i}]' for k,i in poses]+['px_per_cm','center_xz_cm','center_y_cm']
  x=np.array([initial['dimensions'][k] for k in dims]+[initial['poseDegrees'][k][i] for k,i in poses]+[cam0['views']['front']['px_per_cm']]+cam0['views']['front']['center_cm'])
  lower=np.array([64,26,20,-40,-40,10,10,-40,-40,2.1,-6,78]);upper=np.array([80,33,27,40,40,105,105,40,40,2.7,6,92]);eps=np.array([.21,.21,.21,.08,.08,.08,.08,.08,.08,.0002,.02,.02])
  def unpack(x):
   s=copy.deepcopy(initial);c=copy.deepcopy(cam0)
   for i,k in enumerate(dims):s['dimensions'][k]=round(float(x[i]),1)
   for i,(k,j) in enumerate(poses):s['poseDegrees'][k][j]=float(x[3+i])
   for v in ['front','side','back','pose','depth']:c['views'][v].update(px_per_cm=float(x[9]),center_cm=list(map(float,x[10:12])))
   return s,c
  def jr(x):
   s,c=unpack(x);e=r.evaluate(s,skin=False);res=[]
   for v,rows in obs.items():
    uv=r.project(e['joints'],c,v)
    res.extend((uv[[r.index[t['joint']] for t in rows]]-np.array([t['pixel'] for t in rows])).ravel())
   return np.array(res)
  def jac(x):
   columns=[]
   for j,h in enumerate(eps):
    xp=x.copy();xm=x.copy();xp[j]+=h;xm[j]-=h;columns.append((jr(xp)-jr(xm))/(2*h))
   return np.array(columns).T
  def record(block,x,message=''):
   state,cam=unpack(x);e=r.evaluate(state);m={v:metrics(refs[v],r.mask(e['posed'],cam,v)) for v in obs}
   row=dict(block=block,elapsed_seconds=time.time()-start,parameters=dict(zip(names,map(float,x))),normalized_dimensions=state['dimensions'],joint_RMSE_px=float(np.sqrt(np.mean(jr(x)**2))),views=m,message=message);history.append(row);dump(OUT/'parameter-block-history.json',history);print(json.dumps(row),flush=True)
  record('initial',x)
  # Joint residual is differentiated at practical cm steps, respecting 0.1cm engine normalization.
  for iteration in range(3):
   fit=least_squares(jr,x,jac=jac,bounds=(lower,upper),max_nfev=35,xtol=1e-7,ftol=1e-8,gtol=1e-5,x_scale='jac')
   x=fit.x;record(f'joint-shape-bone-pose-camera-{iteration+1}',x,str(fit.message))
   # Waist is best identified from silhouette; wrist rotations have no head-joint residual.
   for j,grid in [(0,np.arange(64,80.01,.5)),(7,np.arange(-30,30.01,2)),(8,np.arange(-30,30.01,2))]:
    best=(float('inf'),x[j])
    def loss(z):
     trial=x.copy();trial[j]=z;s,c=unpack(trial);e=r.evaluate(s);return sum(1-metrics(refs[v],r.mask(e['posed'],c,v))['IoU'] for v in obs)
    for z in grid:
     cost=loss(z)
     if cost<best[0]:best=(cost,z)
    radius=.5 if j==0 else 2
    candidates=np.arange(max(lower[j],best[1]-radius),min(upper[j],best[1]+radius)+.001,.1 if j==0 else .25)
    for z in candidates:
     cost=loss(z)
     if cost<best[0]:best=(cost,z)
    x[j]=best[1];record(f'silhouette-{names[j]}-{iteration+1}',x)
  state,camera=unpack(x);initial_dir=OUT/'initial-source-camera';final_initial=OUT/'initial-final-camera';source_final=OUT/'final-source-camera'
  r.save(initial,cam0,initial_dir,views=['front','side']);r.save(initial,camera,final_initial,views=['front','side']);r.save(state,cam0,source_final,views=['front','side']);final=r.save(state,camera,OUT,views=['front','side','back','closeup','pose','depth'])
  dump(OUT/'final-state.json',final);dump(OUT/'initial-state.json',initial);dump(OUT/'source-camera.json',cam0)
  allmetrics={}
  for protocol,ss,cc in [('initial_source_camera',initial,cam0),('initial_final_camera',initial,camera),('final_source_camera',state,cam0),('final_final_camera',state,camera)]:
   e=r.evaluate(ss);entry={}
   for v in obs:
    mask=r.mask(e['posed'],cc,v);cv2.imwrite(str(OUT/f'{protocol}-{v}-mask.png'),mask);cv2.imwrite(str(OUT/f'{protocol}-{v}-overlay.png'),overlay(refs[v],mask,photos[v]));entry[v]=metrics(refs[v],mask)
    uv=r.project(e['joints'],cc,v);entry[v]['joint_RMSE_px']=float(np.sqrt(np.mean((uv[[r.index[t['joint']] for t in obs[v]]]-np.array([t['pixel'] for t in obs[v]]))**2)))
   allmetrics[protocol]=entry
  allmetrics['protocol']={'resolution':[cam0['width'],cam0['height']],'ROI':'entire supplied image; no crop or altered reference','reference_hashes':{p.name:sha(p) for p in IN.iterdir() if p.is_file()},'contour':'symmetric distance between 3x3 morphological boundaries; OpenCV L2 distance transform','final_state_sha256':sha(OUT/'final-state.json'),'posed_mesh_sha256':sha(OUT/'posed.obj')}
  dump(OUT/'metrics.json',allmetrics)
  # Independent reconstruction directly from serialized coefficients and asset paths, without reusing self-reported measures.
  asset=r.data;vv=r.base.copy()
  for control,w in zip(asset['controls'],final['morphWeights']):
   rows=np.asarray(control['incr' if w>=0 else 'decr'],float)
   if len(rows):vv[rows[:,0].astype(int)]+=rows[:,1:]*abs(w)
  print('asset measure keys',asset.keys(),flush=True)
  dump(OUT/'measurement-schema.json',{k:v for k,v in asset.items() if 'measur' in k.lower()})
  # A separate evaluator script verifies neutral measures from actual asset landmarks.
  helpers=ROOT/'work/single-state-skill-evals-20261117/skill-new/scripts/inspect_human_state.py'
  subprocess.run([sys.executable,str(helpers),'--state',str(OUT/'final-state.json'),'--asset-json',str(r.asset),'--expected-asset',sha(r.asset),'--require-match','--out',str(OUT/'independent-neutral-check.json')],check=True)
  e=r.evaluate(state);sh=e['shape'];segments=[]
  for side in ['L','R']:
   for label,a,b in [('upper_arm_bone_head_distance','upperarm01','lowerarm01'),('forearm_bone_head_distance','lowerarm01','wrist')]:
    i=r.index[a+'.'+side];j=r.index[b+'.'+side];segments.append(dict(name=label+'.'+side,neutral_cm=float(np.linalg.norm(sh['heads'][j]-sh['heads'][i])),posed_cm=float(np.linalg.norm(e['joints'][j]-e['joints'][i])),definition=f'{a}.{side} head to {b}.{side} head; distinct from surface ruler'))
  measurements=dict(targets=final['dimensions'],measured_neutral=final['measuredNeutral'],actual_bone_head_distances=segments,neutral_height_cm=float(np.ptp(sh['rest'][r.ids,1])),posed_bbox_height_cm=float(np.ptp(e['posed'][r.ids,1])),neutral_mesh_sha256=sha(OUT/'neutral.obj'),basis='mesh_parameter; height170 prior; controlled geometry fixture, not real-person measurements')
  dump(OUT/'measurements.json',measurements)
  with (OUT/'measurements.csv').open('w') as f:
   w=csv.writer(f);w.writerow(['name','target_cm','measured_neutral_cm','basis']);w.writerows([[k,v,final['measuredNeutral'][k],'mesh_parameter' if k!='height' else 'prior'] for k,v in final['dimensions'].items()])
  z=np.load(OUT/'rawdepth.npy');valid=np.isfinite(z);dump(OUT/'depth-check.json',dict(valid_pixels=int(valid.sum()),finite_valid=bool(np.isfinite(z[valid]).all()),range_cm=[float(z[valid].min()),float(z[valid].max())],semantics='orthographic front surface Z coordinate cm, largest Z wins; background -inf; validity stored separately'))
  dump(OUT/'run.json',dict(mode='observed_fit',evidence='controlled real MakeHuman geometry; not photographs or ImageGen',runtime_seconds=time.time()-start,model_tokens=None,token_limitations='API usage unavailable; no fabricated token count',python=sys.version,asset_sha256=sha(r.asset),input_sha256={p.name:sha(p) for p in IN.iterdir() if p.is_file()},skill_snapshot_sha256=sha(ROOT/'work/single-state-skill-evals-20261117/skill-new/SKILL.md'),runtime_sha256=sha(FIX/'runtime.py')))
  record('final-export',x)
 finally:r.close()
if __name__=='__main__':
 main()
 subprocess.run([sys.executable,str(OUT/'finalize_evidence.py')],check=True)
