# Executed single-body joint fit

This run used the explicitly requested new skill snapshot and the public joint-fit fixture, actual Human Studio fitDimensions calibration and full 163-bone FK/LBS. Reference images were visually inspected before fitting. They depict a controlled anatomical MakeHuman body with bent arms; they are not real-person photographs. Height remains the disclosed 170cm prior. No external generation was invoked.

A reusable optimizer was implemented and executed: practical-step least-squares jointly fit waist/arm ruler controls, upper-arm Z and elbow X rotations, and one common orthographic camera scale/center, followed by silhouette coordinate searches for waist and wrist Z. All other local joint angles were retained. Three alternating rounds were run. Wrist rotations are unobservable from wrist-head points and were selected using silhouettes. Parameters and losses for every block, including temporary regressions, are in parameter-block-history.json; no reference image, mask, ROI, or annotation was changed.

## Measured results

|Protocol|Front IoU|Side IoU|Front joint RMSE px|Side joint RMSE px|
|---|---:|---:|---:|---:|
|initial_source_camera|0.69677376|0.69696795|7.70707113|7.01889442|
|initial_final_camera|0.86440811|0.87845721|6.34805718|6.19578728|
|final_source_camera|0.69350259|0.71191994|7.49995668|6.89340013|
|final_final_camera|1.00000000|1.00000000|0.00000000|0.00000000|

Common final camera: {"axis": "front", "px_per_cm": 2.2, "center_cm": [-5.12047815702479e-14, 84.99999999999997]}. Evaluation uses the unchanged full 320×448 supplied canvases. Four protocols separate camera and body contributions; overlays use green overlap, magenta reference-only and cyan model-only. The weakest final view is front. Full Dice and symmetric contour mean/P95 are in metrics.json.

Final requested/independently reconstructed neutral surface-ruler sizes (cm):

|Control|Requested|Measured neutral|
|---|---:|---:|
|height|170.000|169.999975|
|waist|68.000|68.000020|
|upperArmLength|29.500|29.500001|
|forearmLength|23.500|23.500003|

Maximum cm target residual: 5.227893640835646e-05. Independent neutral reconstruction: independent-neutral-check.json (matching asset, serialized morph coefficients, actual tape/landmark definitions). Posed bounding-box height is 169.9999748759419cm and is not a new stature measurement. Actual bone-head segments are separately listed in measurements.json:

- upper_arm_bone_head_distance.L: neutral 27.355354cm, posed 27.355354cm.
- forearm_bone_head_distance.L: neutral 23.717309cm, posed 23.717309cm.
- upper_arm_bone_head_distance.R: neutral 27.355354cm, posed 27.355354cm.
- forearm_bone_head_distance.R: neutral 23.717309cm, posed 23.717309cm.

## Artifacts and limits

final-state.json is the single complete importable state; camera.json is separate. neutral.obj and posed.obj are actual surface meshes in Y-up cm. All six images bind to the same state/pose/posed-mesh hashes in view-provenance.json. World and projected joints include canvas visibility, without an occlusion claim. Camera image/depth transforms are explicit in camera-matrices.json. rawdepth.npy stores actual front-camera Z coordinates in cm, background -inf, with depth-valid.png; depth.png is visualization only.

front/side/back/closeup/pose/depth PNGs are actual geometry images, not clothing generations; closeup shows anatomical mesh, without invented garment texture or seams. The back view is inferred from the shared fitted state and was not an observed training view. viewer.html loads the saved actual posed.obj and enables camera views. It does not independently re-fit or alter the body. Human Studio can import final-state.json for editable cm/pose controls.

The controlled fixture permits internal geometry consistency conclusions only. These values are not measurements of a real person. Rendering uses the provided orthographic rasterizer. LBS has no tissue/collision simulation; a formal self-intersection/body-penetration test was not run. Point alignment does not establish unique human anatomy, and the withheld back target was not accessed. No private target, previous fit, or other executor output was read. Model token usage is unavailable and is left null. Numeric run duration is recorded in run.json, excluding report assembly.

Reproduce from any directory with `python PATH/TO/outputs/reproduce.py`, using the repository asset/runtime and NumPy, SciPy, OpenCV, Node already installed. The worker is closed in a finally block. Run `python PATH/TO/outputs/finalize_evidence.py` to rebuild report/verification metadata after fitting. No server or browser was started, and no shared app/runtime/skill was edited. No commit was made per this evaluation's explicit instruction.

Visual inspection of the saved front/side/back contact sheet found the same bent-arm action in every view. Hands overlap in the side projection; no large hand-through-torso crossing is apparent in these views, but this is visual inspection only. actual-shape-bone-change.json documents actual neutral vertex movement and actual bone-head length changes rather than ruler labels. The static viewer was implemented but was not browser-tested in this fitting run.
