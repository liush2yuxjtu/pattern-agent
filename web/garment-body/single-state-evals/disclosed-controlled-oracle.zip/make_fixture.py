#!/usr/bin/env python3
"""Fixture author only. Never expose this target-state constructor to executors."""
from pathlib import Path
import sys,json,copy,hashlib,shutil,platform
import numpy as np, cv2,scipy
P=Path(__file__).resolve().parent;F=P.parent/'fixtures';sys.path.insert(0,str(F))
from runtime import Runtime,sha
r=Runtime()
base={'height':170,'bust':91,'waist':68,'hips':96,'shoulders':37,'upperArm':27,'thigh':53,'neck':32,'upperArmLength':29.5,'forearmLength':23.5,'thighLength':40,'calf':35}
pose={'upperarm01.L':[-4,8,16],'upperarm01.R':[-4,-8,-16],'lowerarm01.L':[62,0,-10],'lowerarm01.R':[57,0,10],'wrist.L':[0,0,-12],'wrist.R':[0,0,12]}
target=r.canonical_state({'dimensions':base,'poseDegrees':pose})
initial=copy.deepcopy(target);initial['dimensions'].update(waist=76,upperArmLength=31.5,forearmLength=25.5)
initial['poseDegrees']['upperarm01.L'][2]=5;initial['poseDegrees']['upperarm01.R'][2]=-5
initial['poseDegrees']['lowerarm01.L'][0]=46;initial['poseDegrees']['lowerarm01.R'][0]=42
initial['poseDegrees']['wrist.L'][2]=0;initial['poseDegrees']['wrist.R'][2]=0
initial=r.canonical_state(initial)
camera={'width':320,'height':448,'projection':'orthographic','depth_range_cm':[-70,70],'coordinate_system':'X left/right; Y up; Z front, centimetres','views':{}}
for view,axis in [('front','front'),('side','side'),('back','back'),('pose','front'),('depth','front')]:camera['views'][view]={'axis':axis,'px_per_cm':2.2,'center_cm':[0,85]}
camera['views']['closeup']={'axis':'front','px_per_cm':4.4,'center_cm':[0,125]}
biased=copy.deepcopy(camera)
for name,c in biased['views'].items():
 if name!='closeup':c['px_per_cm']=2.36;c['center_cm']=[1.5,83.5]
joints=['neck01','head','upperarm01.L','upperarm01.R','lowerarm01.L','lowerarm01.R','wrist.L','wrist.R','upperleg01.L','upperleg01.R','lowerleg01.L','lowerleg01.R','foot.L','foot.R']
targetresult=r.evaluate(target)
landmarks={'scope':'Synthetic projections of the same actual target body and pose; not human annotation or photograph detections.','views':{}}
for view in ['front','side']:
 xy=r.project(targetresult['joints'],camera,view)
 landmarks['views'][view]=[{'joint':name,'pixel':xy[r.index[name]].tolist(),'visibility':'inside canvas only; no occlusion claim'} for name in joints]
case=F/'joint-fit';case.mkdir(exist_ok=True)
(case/'initial-state.json').write_text(json.dumps(initial,indent=2)+'\n');(case/'camera.json').write_text(json.dumps(biased,indent=2)+'\n');(case/'reference-joints.json').write_text(json.dumps(landmarks,indent=2)+'\n')
r.save(target,camera,P/'target',views=['front','side','back'])
r.save(initial,biased,case/'initial-renders',views=['front','side','back'])
for view in ['front','side']:
 for suffix in ['.png','-mask.png']:shutil.copy2(P/'target'/(view+suffix),case/('reference-'+view+suffix))
# The browser control case has a different disclosed shape/pose, not the hidden fit answer.
browser={'dimensions':{**base,'bust':90,'waist':71,'upperArmLength':29,'forearmLength':23},'poseDegrees':{**pose,'lowerarm01.L':[48,0,-8],'lowerarm01.R':[52,0,8],'upperarm01.L':[-3,8,20],'upperarm01.R':[-3,-8,-20]}}
r.save(browser,camera,F/'pose-preservation/source',views=['front','side','back'])
(P/'target-state.json').write_text(json.dumps(target,indent=2)+'\n');(P/'target-camera.json').write_text(json.dumps(camera,indent=2)+'\n')
manifest={'asset_sha256':sha(r.asset),'body_vertices':len(r.ids),'triangles':len(r.faces),'bones':len(r.bones),'evidence':'controlled anatomical geometry, not real photo/body truth','versions':{'python':platform.python_version(),'numpy':np.__version__,'opencv':cv2.__version__,'scipy':scipy.__version__},'files':{str(p.relative_to(F)):sha(p) for p in sorted(F.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}}
(F/'frozen-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n');r.close();print(json.dumps({'fixture_ready':True,'files':len(manifest['files']),'target_oracle':str(P)}))
