# Single-body single-action joint fitting task inputs

Read `../README.md` and import `../runtime.py` for the actual anatomical
calibration, full163bone FK/LBS, mask projection and final render/export API.
The helper has NO image-fit optimizer and contains no hidden task answers.

Fit the supplied initial body/pose/camera against the two public front/side
reference images/masks and actual projected reference joints. Preserve the
bent-arm target action; do not switch to A-pose. Save ONE final body and ONE
complete joint-angle table, with all views rendered from it. Joint limits and
the three adjustable cm keys are in the shared README. The biased camera is
also adjustable through one global scale/center; it is not a fixed truth.

Neutral(cm) and posed outputs differ: measure body sizes in the neutral state;
use the actual skinned posed mesh for the photo projection/overlay. This is a
controlled anatomical geometry fixture, not real model measurements or ImageGen.
No fresh generation, external service or paid compute is needed.

Always close the persistent calibration process in a `finally` clause:

```python
r=Runtime()
try:
    # perform your fitting and export
    ...
finally:
    r.close()
```

Reuse one Runtime per fitting process. It caches shape calibration by the full
dimension dictionary; changing camera or pose reuses those shape results.
`evaluate(...,skin=False)` gives fast full FK joints for the standing-lower-body
fixture; `evaluate(...,skin=True)` adds real LBS and posed floor normalization.
Call `save` only for initial/final evidence, not every objective evaluation:
colored depth-buffer rendering is intentionally more expensive than `mask`.
