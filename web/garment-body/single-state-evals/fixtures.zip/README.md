# Actual anatomical single-state test runtime

`runtime.py` and `calibrate-worker.mjs` are reusable evaluation infrastructure,
not a provided solution. They read the existing CC0 MakeHuman asset and actual
Human Studio cm calibration code. They contain no reference data, optimizer or
hidden target-state values. Use Python3 with NumPy, SciPy, OpenCV and Node.

```python
import sys,json
sys.path.insert(0, 'work/single-state-skill-evals-20261117/fixtures')
from runtime import Runtime
r=Runtime()
state=json.load(open('.../joint-fit/initial-state.json'))
camera=json.load(open('.../joint-fit/camera.json'))
result=r.evaluate(state)  # real shape,163-bone FK and four-weight mesh LBS
uv=r.project(result['joints'],camera,'front')
mask=r.mask(result['posed'],camera,'front')
canonical=r.canonical_state(state)  # recalculate12actual neutral cm measures
r.save(state,camera,'YOUR_OUTPUT',views=['front','side','back','pose','depth','closeup'])
r.close()
```

The Node worker remains alive until `close()`; shape calibration is cached by
dimension dictionary. `evaluate(state,skin=False)` computes actual FK joints
without mesh skinning, useful for landmark objectives; the fixture's fixed
standing lower body has unchanged foot floor, whereas generalized posed-floor
use requires full `evaluate`. `mask` is much faster than final colored Z-buffer
rendering. `save` renders the final actual surface and stores state, neutral/posed
OBJ(cm), camera, joints, same-state per-view provenance and raw depth when asked.
Every view uses the SAME supplied body/pose; only its camera axis changes.

Dimensions are normalized by source Human Studio to0.1cm. Use nonzero practical
finite-difference steps (for example0.2–0.5cm) rather than1e-8cm probes.
Pose input is a name→[X,Y,Z] degree map and may contain all163bone entries.
The initial state is complete and importable in Human Studio. Do not replace
its whole pose map with a few joints unless deliberately preserving all others.

## joint-fit inputs

`joint-fit/reference-{front,side}.png`, masks and `reference-joints.json` were
generated from ONE hidden state with bent arms. `initial-state.json` has biased
waist, upper-arm ruler length, forearm ruler length and arm angles. Its same
target-action initial pose is intentionally not neutral/A-pose. Body height and
other disclosed dimensions are fixed. Allowed cm fit keys: waist[64,80],
upperArmLength[26,33], forearmLength[20,27]. Bone-head distances and these surface
ruler controls have different definitions; source calibration actually changes
mesh/rest joints. Pose fit keys may include upperarm01.L/R Z, lowerarm01.L/R X,
wrist.L/R Z, retaining all other initial angles. Camera optimization may change
ONE global px_per_cm and ONE common center_cm for the standard front/side/back
views, copied consistently to pose/depth. Closeup is a separately named camera.
Do not change reference bytes or fit one pose per view.

Only front/side observations are training inputs. Back target and private target
state are withheld for the independent grader; do not search for or read them.
They are not real-person observations. `initial-renders` show the biased source.

## pose-preservation input

`pose-preservation/source/state.json` is a DIFFERENT disclosed bent-arm state for
real-browser testing of cm edits without changing the target action. The source
pose is deliberately complete and non-A-pose. Adjusting dimensions legitimately
moves world joints; preserving pose means retaining local joint angles and the
target action, not freezing all world-space vertex positions.
