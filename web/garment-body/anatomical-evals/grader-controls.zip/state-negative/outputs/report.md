# Anatomical state handoff audit

The usable achieved-target state is **reference.json**. These controlled model data establish mesh consistency, not real-person accuracy. No inputs were modified.

| State | Classification | Reason |
| --- | --- | --- |
| reference.json | verified | Matching asset, finite valid pose and neutral measurements independently recomputed; targets achieved within 0.2 cm |
| metre-label.json | invalid | State units must be cm; relabelling as m is invalid |
| nonfinite-angle.json | invalid | Invalid/nonfinite degree rotation: lowerarm01.L |
| pose-joint.json | invalid | Unknown edited joint: left_elbow_invented |
| reported-bust.json | invalid | Saved measuredNeutral disagrees with independently reconstructed mesh by 2.000000000 cm |
| unreached-target.json | closest_supported | Valid saved model and measurements, but target residual 9.999987571 cm exceeds 0.2 cm; usable only as an unmet-target/closest-supported state |

All six neutral meshes were independently reconstructed from matching MakeHuman asset `a75b6a2d59b2fa60ea29393e380182174627ba66d0993c649c8c571a6ccecda6` using the saved morph coefficients. Height uses the surface Y span; other values use the asset’s tape paths or landmark paths. All 12 reference values are in measurements.csv and audit.json. The maximum reference target residual is 0.004172058 cm.

For invalid cases, neutral_mesh_checked=true records the actual independent shape reconstruction; it does not approve their units, pose, or self-reported measurements. The corrupted bust reports 98.004172058 cm, while the mesh yields 96.004172058 cm.

unreached-target.json retains the same measured neutral height 180.000012429 cm against a 190 cm target. It is valid as a saved closest-supported/unmet-target state, not an achieved 190 cm body. This audit does not re-optimize or prove a global nearest solution.

The provided posed OBJ has 13380 finite vertices and 26756 faces. Its Y-up bounding-box height is 132.672357000 cm. Bent knees make this a posed extent, not neutral standing height. Units are interpreted using the supplied cm contract and matching manifest; no independent absolute physical scale was measured.

Camera recovery: unavailable (the state has no camera). Not run: browser import/reload, animated joint deformation, independent posed skinning correspondence, GLB/metre comparison, collisions, photos or physical fit. A valid joint name and finite angle do not establish collision-free anatomy. No image generation, network or paid compute was used.

Reproduce from the repository root:
```sh
python work/anatomical-skill-evals-20261117/iteration-1/eval-1-state-audit/with_skill/run-1/outputs/audit_states.py
```
