# Executed synthetic anatomical evidence

Scope: preserved the supplied seated/flexed MakeHuman surface, not a photograph or inferred person. Read repository AGENTS.md, assigned skill snapshot SKILL.md and its human-studio/tools-and-evidence references, permitted task metadata, fixture README, source state/camera/joints, actual human.json and generic renderer. No network, image generation, paid tools, shared-file changes or commits. All new files are inside this outputs directory. Explicit task restriction on commits overrides the repository default commit/push workflow.

## Reproduction

From repository root:

```sh
python work/anatomical-skill-evals-20261117/iteration-2/eval-3-pose-depth-evidence/old_skill/run-1/outputs/reproduce.py
```

Executed successfully on Python 3.12.14, NumPy 2.3.5, OpenCV 5.0.0. The runnable script copies the source posed OBJ to final.obj, neutral OBJ to neutral.obj, exact state/camera/joints, and supplied unmodified render_mesh.py. It invokes render_mesh.render with the real source rig joints, then reopens all six PNGs/masks, rawdepth/depth arrays, depth-valid and projected pose joints. Equivalent rendering CLI:

```sh
python render_mesh.py --mesh final.obj --camera camera.json --out renders --joints joints.json
```

## Observed results

- 13,380 finite vertices; 26,756 triangles. Original source vertex order and faces preserved; posed/neutral OBJ, state, camera and joints were independently reopened and confirmed byte-identical to their fixture sources.
- Actual human.json SHA256 matches the state asset fingerprint. 163 actual rig joints were preserved with cm positions and parents.
- Neutral Y-up bbox height 179.9999101 cm; seated posed bbox height 132.672357 cm; difference 47.3275531 cm. The seated bbox is not standing stature.
- All 12 neutral dimensions were measured directly on the reopened neutral OBJ, with actual asset bodyVertexIds mapping and original control tape/landmark paths. Maximum difference from saved measuredNeutral is 0.004109114 cm, within 0.03 cm. The maximum target residual of the rounded source-neutral OBJ is 0.000248508 cm. State remains byte-exact; its higher-resolution original measuredNeutral values are not overwritten.
- All six independent 384x512 images and masks match permitted supplied reference renders: mask IoU 1.0 and image mean absolute pixel error 0.0 for every view, including the colored pose skeleton.
- depth.png is single-channel uint8 using the supplied fixed [-90,90] cm range; 0 background, 1..254 foreground. depth.npy and rawdepth.npy are identical float32 signed-source-X nearest-triangle depths; larger means nearer. Background is -inf; depth-valid.png equals the finite mask (16,482 pixels). PNG encoding check differs by at most 1 quantization unit after reopening float32.
- Independent scalar ray/triangle checks at 40 finite pixels use every actual source triangle without calling the raster function. Maximum saved raw-depth discrepancy 0.000001656 cm. Samples retained in triangle-hit-checks.json.
- All 163 saved projected rig joint pixels agree with the frozen pose camera exactly (maximum error 0.0 pixels); world positions, names, visibility and parent edges are preserved. Visibility means inside canvas, not occlusion.
- Reopened pose.png and depth.png were visually inspected: seated legs, flexed arms, actual dots/lines and aligned side depth are visible.

Metrics and hashes are in metrics.json. This is deterministic internal consistency evidence for a synthetic model. It does not validate a real person's dimensions, tissue, collision, photo fitting or garment fit.
