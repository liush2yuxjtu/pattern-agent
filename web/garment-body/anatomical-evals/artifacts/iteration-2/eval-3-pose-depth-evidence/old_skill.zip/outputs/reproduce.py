#!/usr/bin/env python3
"""Preserve anatomical source and generate deterministic triangle evidence. No network."""
import hashlib, json, shutil, sys
from pathlib import Path
import cv2
import numpy as np

OUT=Path(__file__).resolve().parent
ROOT=next(p for p in OUT.parents if (p/'web/human-studio/assets/human.json').exists())
FIX=ROOT/'work/anatomical-skill-evals-20261117/fixtures'
SRC=FIX/'pose-depth-evidence'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
for a,b in [('source-posed.obj','final.obj'),('source-neutral.obj','neutral.obj'),('source-state.json','state.json'),('camera.json','camera.json'),('source-joints.json','joints.json')]:shutil.copyfile(SRC/a,OUT/b)
shutil.copyfile(FIX/'render_mesh.py',OUT/'render_mesh.py')
sys.path.insert(0,str(OUT))
import render_mesh
state=json.loads((OUT/'state.json').read_text());camera=json.loads((OUT/'camera.json').read_text());joints=json.loads((OUT/'joints.json').read_text())
v,f=render_mesh.render(OUT/'final.obj',camera,OUT/'renders',joints)
n,nf=render_mesh.obj(OUT/'neutral.obj')
asset_path=ROOT/'web/human-studio/assets/human.json';asset=json.loads(asset_path.read_text())
assert sha(asset_path)==state['asset'];assert len(v)==13380 and len(f)==26756 and np.isfinite(v).all();assert np.array_equal(f,nf)
ids={original:compact for compact,original in enumerate(asset['bodyVertexIds'])}
neutral_height=float(np.ptp(n[:,1]));posed_height=float(np.ptp(v[:,1]))
measured={'height':neutral_height}
methods={'height':'standing_height'}
for control in asset['controls'][1:]:
    path=n[[ids[k] for k in control['path']]]
    measured[control['key']]=float(np.linalg.norm(np.diff(path,axis=0),axis=1).sum())
    methods[control['key']]='landmark_distance' if len(path)==2 else 'surface_tape_path'
assert max(abs(measured[k]-state['measuredNeutral'][k]) for k in measured)<.03
assert neutral_height-posed_height>20
# Independently reopen and validate outputs, rather than trust the render call.
z=np.load(OUT/'renders/rawdepth.npy');depth=np.load(OUT/'renders/depth.npy');valid=cv2.imread(str(OUT/'renders/depth-valid.png'),0)>0
assert z.dtype==np.float32 and np.array_equal(z,depth) and np.array_equal(valid,np.isfinite(z));assert np.isneginf(z[~valid]).all()
encoded=cv2.imread(str(OUT/'renders/depth.png'),cv2.IMREAD_UNCHANGED);lo,hi=camera['depth_range_cm'];expected=np.zeros(z.shape,np.uint8);expected[valid]=np.clip(1+253*(z[valid]-lo)/(hi-lo),1,254).astype(np.uint8)
assert encoded.ndim==2 and encoded.dtype==np.uint8
encoding_error=int(np.abs(encoded.astype(int)-expected.astype(int)).max());assert encoding_error<=1
# Scalar pixel-ray intersection against every triangle; no calls to raster().
c=camera['views']['depth'];horizontal=v[:,2] if c['axis']=='side' else v[:,0]*(-1 if c['axis']=='back' else 1);distance=v[:,0] if c['axis']=='side' else v[:,2]*(-1 if c['axis']=='back' else 1)
s=c['px_per_cm'];cx,cy=c['center_cm'];xy=np.column_stack(((horizontal-cx)*s+camera['width']/2,camera['height']/2-(v[:,1]-cy)*s));t=xy[f];a,b,d=t[:,0],t[:,1],t[:,2];den=(b[:,1]-d[:,1])*(a[:,0]-d[:,0])+(d[:,0]-b[:,0])*(a[:,1]-d[:,1]);ok=np.abs(den)>=1e-10
rays=[]
locations=np.argwhere(valid)
for iy in np.linspace(0,len(locations)-1,40,dtype=int):
    y,x=locations[iy]
    u=np.full(len(f),-1.);vv=np.full(len(f),-1.)
    u[ok]=((b[ok,1]-d[ok,1])*(x-d[ok,0])+(d[ok,0]-b[ok,0])*(y-d[ok,1]))/den[ok]
    vv[ok]=((d[ok,1]-a[ok,1])*(x-d[ok,0])+(a[ok,0]-d[ok,0])*(y-d[ok,1]))/den[ok];ww=1-u-vv
    hit=ok&(u>=-1e-7)&(vv>=-1e-7)&(ww>=-1e-7);hit_depth=u*distance[f[:,0]]+vv*distance[f[:,1]]+ww*distance[f[:,2]]
    truth=float(hit_depth[hit].max());error=abs(float(z[y,x])-truth);assert error<.001
    rays.append({'pixel':[int(x),int(y)],'triangle_depth_cm':truth,'saved_depth_cm':float(z[y,x]),'absolute_error_cm':error})
pj=json.loads((OUT/'renders/pose-joints.json').read_text());c=camera['views']['pose'];max_joint_error=0.
for joint,row in zip(joints['joints'],pj['joints']):
    p=joint['position'];h=p[2] if c['axis']=='side' else p[0]*(-1 if c['axis']=='back' else 1);pixel=[(h-c['center_cm'][0])*c['px_per_cm']+camera['width']/2,camera['height']/2-(p[1]-c['center_cm'][1])*c['px_per_cm']]
    max_joint_error=max(max_joint_error,float(np.max(np.abs(np.array(pixel)-row['pixel']))));assert row['world_cm']==p and row['name']==joint['name'] and row['visible']==bool(0<=pixel[0]<camera['width'] and 0<=pixel[1]<camera['height'])
assert max_joint_error<.001 and len(joints['joints'])==len(asset['bones'])==163
comparisons={}
for view in camera['views']:
    im=cv2.imread(str(OUT/'renders'/f'{view}.png'),cv2.IMREAD_UNCHANGED);ref=cv2.imread(str(SRC/'reference-renders'/f'{view}.png'),cv2.IMREAD_UNCHANGED)
    mask=cv2.imread(str(OUT/'renders'/f'{view}-mask.png'),0)>0;refmask=cv2.imread(str(SRC/'reference-renders'/f'{view}-mask.png'),0)>0
    iou=float((mask&refmask).sum()/(mask|refmask).sum());mae=float(np.abs(im.astype(float)-ref.astype(float)).mean());assert iou>=.99 and mae<=2
    comparisons[view]={'width':int(im.shape[1]),'height':int(im.shape[0]),'mask_iou_against_supplied_reference':iou,'image_mean_absolute_error_against_supplied_reference':mae,'foreground_mask_pixels':int(mask.sum())}
metrics={'units':'cm','source_up':'Y','basis':'mesh_parameter','synthetic_control':True,'neutral_height_cm':neutral_height,'posed_height_cm':posed_height,'neutral_bbox_height_cm':neutral_height,'posed_bbox_height_cm':posed_height,'neutral_minus_posed_height_cm':neutral_height-posed_height,'measuredNeutral':measured,'neutral_tape_measurements_cm':measured,'measurement_methods':methods,'dimensions':state['dimensions'],'maximumTargetErrorCm':max(abs(measured[k]-state['dimensions'][k]) for k in measured),'maximum_saved_neutral_measurement_difference_cm':max(abs(measured[k]-state['measuredNeutral'][k]) for k in measured),'vertices':len(v),'triangles':len(f),'joint_count':len(joints['joints']),'max_joint_projection_error_px':max_joint_error,'independent_triangle_hit_sample_count':len(rays),'maximum_triangle_depth_error_cm':max(r['absolute_error_cm'] for r in rays),'depth_encoding_max_error':encoding_error,'depth_semantics':'signed source X for side projection; larger is nearer; -inf background; not camera distance','valid_depth_pixels':int(valid.sum()),'renders':comparisons,'hashes':{name:sha(OUT/name) for name in ['final.obj','neutral.obj','state.json','camera.json','joints.json','render_mesh.py']},'asset_sha256':sha(asset_path),'limitations':['Synthetic MakeHuman model, not a photographed person.','Neutral surface tape paths and landmark distances are model parameters, not physical body measurements.','Skeleton visibility means inside canvas, not occlusion.','Linear blend skeletal skinning does not simulate tissue or collisions.','Reference pixel comparison is a deterministic internal consistency check, not independent human accuracy.']}
write(OUT/'metrics.json',metrics);write(OUT/'triangle-hit-checks.json',{'samples':rays});print(json.dumps({'neutral_height_cm':neutral_height,'posed_height_cm':posed_height,'max_depth_error_cm':metrics['maximum_triangle_depth_error_cm'],'renders':comparisons},indent=2))
