# Executed synthetic anatomical pose/depth evidence

Working directory: `/workspace/work/pattern-agent`.
Scope: the supplied existing posed MakeHuman control, not a photograph or estimated human. No fit, source alteration, auto framing, network, image generation, paid tools, commits or subagents. All written artifacts are in this output directory. The caller's no-commit instruction overrides the repository's usual commit/push workflow.

Read `AGENTS.md`, the specified candidate-v2 `SKILL.md`, its Human Studio, geometry evidence, and tools/evidence references, the fixture README and metadata, and local `/verify` instructions. No private oracle, graders, or other runs/iterations/skill versions/results were read.

## Reproduce

Python dependencies already available: NumPy and OpenCV.

```bash
cd /workspace/work/pattern-agent
python work/anatomical-skill-evals-20261117/iteration-2/eval-3-pose-depth-evidence/with_skill/run-1/outputs/reproduce.py
python work/anatomical-skill-evals-20261117/iteration-2/eval-3-pose-depth-evidence/with_skill/run-1/outputs/verify_reopened.py
python work/anatomical-skill-evals-20261117/skill-candidate-v2/scripts/inspect_human_state.py --state work/anatomical-skill-evals-20261117/iteration-2/eval-3-pose-depth-evidence/with_skill/run-1/outputs/state.json --asset-json web/human-studio/assets/human.json --require-match --out work/anatomical-skill-evals-20261117/iteration-2/eval-3-pose-depth-evidence/with_skill/run-1/outputs/state-check.json
```

`reproduce.py` copies source meshes, state, camera, and source joints without modification and invokes the copied supplied `render_mesh.py` with `--joints joints.json`. It then reopens exported files and computes source/topology preservation, mesh measurements, neutral asset reconstruction, all joint projections, and 40 independently computed triangle-hit depths. It preserves the supplied renderer unchanged; its SHA256 is in metrics.json.

`verify_reopened.py` compares the delivered bytes with source bytes, rerenders the untouched source OBJ with the untouched source camera and actual source joints, and compares all six masks and image pixels including the pose annotation. Read `pixel-replay-check.json` for the actual observed outcome. This pixel replay uses the specified renderer as the deterministic rendering contract; the 40 triangle intersections in `reproduce.py` are separate vectorized intersection calculations, not the renderer's z-buffer readback.

## Observed results

- Source vertex order and all 26,756 triangles preserved, 13,380 finite vertices; posed and neutral coordinate differences to respective source files are exactly 0 cm.
- Neutral standing height is **179.9999101 cm**; seated posed bounding-box Y height is **132.672357 cm**, a **47.3275531 cm** difference. The seated bbox is not standing height.
- Neutral tape paths and landmark distances are measured on reopened neutral.obj after mapping original `bodyVertexIds` to compact indices. All 12 values and definitions are in metrics.json. Largest difference from saved `measuredNeutral`: **0.0041091131 cm**. Independent full rest reconstruction using matching human.json and saved morph coefficients differs from source-neutral.obj by at most **0.0011050753 cm**.
- Matching anatomical asset SHA256: `a75b6a2d59b2fa60ea29393e380182174627ba66d0993c649c8c571a6ccecda6`. The skill's independent asset/state measurement audit returned PASS; `state-check.json` retains the actual report.
- All **163** actual rig joints preserved. All saved floating-point joint camera projections match exactly, **0 px** maximum error; all parent-child edges verified. Visibility means inside canvas and does not imply unoccluded.
- Depth has **16,482** finite pixels. Both arrays are float32 and equal. Background is -inf and depth-valid.png exactly equals the finite mask. A fixed-seed selection of 40 valid pixels independently intersected all projected triangles; maximum error **0.000001184247 cm**. Single-channel encoded depth has 0 maximum error under the fixed [-90,90] cm encoding reconstructed from saved float32 depth.
- Deterministic source replay returned PASS: all six mask IoUs are **1.0**, all image mean absolute pixel errors are **0**, including actual skeleton annotation.
- All six images are **384×512** pixels; five color images and one single-channel uint8 depth image. Each has its own mask. The mask includes rounded triangle boundary pixels; raw depth validity is the separately retained finite barycentric hit mask.
- Reopened and visually inspected front.png, pose.png and depth.png. The side pose visibly preserves seated knees and bent forearms; actual rig points and parent lines are visible. Front projection overlaps seated thighs due to the frozen camera; no pose or camera was changed to alter the appearance.

## Limits

Only synthetic model geometry consistency is claimed. No real-person measurement accuracy, photographed garment detail, detector inference, physical tissue, collision or cloth simulation is claimed. `close-up.png` is the requested anatomical close-up under supplied metadata, not generated garment texture. No live Human Studio UI validation or re-skinning is needed for preserving these authorized existing exports, and neither is claimed. Pixel replay and numerical assertions apply to these saved files and fixed camera.
