#!/usr/bin/env python3
"""Preserve the synthetic source and run its fixed-camera triangle evidence protocol."""
import argparse, hashlib, json, shutil, subprocess, sys
from pathlib import Path
import cv2
import numpy as np
from render_mesh import obj

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,default=Path('/workspace/work/pattern-agent'));args=ap.parse_args()
    root=args.repo;out=Path(__file__).resolve().parent
    fixture=root/'work/anatomical-skill-evals-20261117/fixtures/pose-depth-evidence'
    asset_path=root/'web/human-studio/assets/human.json';asset=json.loads(asset_path.read_text())
    copies={'source-posed.obj':'final.obj','source-neutral.obj':'neutral.obj','source-state.json':'state.json','source-joints.json':'joints.json','camera.json':'camera.json'}
    for src,dest in copies.items():shutil.copyfile(fixture/src,out/dest)
    subprocess.run([sys.executable,str(out/'render_mesh.py'),'--mesh',str(out/'final.obj'),'--camera',str(out/'camera.json'),'--joints',str(out/'joints.json'),'--out',str(out/'renders')],check=True)
    v,f=obj(out/'final.obj');neutral,nf=obj(out/'neutral.obj');sv,sf=obj(fixture/'source-posed.obj');sn,snf=obj(fixture/'source-neutral.obj')
    state=json.loads((out/'state.json').read_text());camera=json.loads((out/'camera.json').read_text());joints=json.loads((out/'joints.json').read_text())
    assert sha(asset_path)==state['asset']
    assert v.shape==(13380,3) and f.shape==(26756,3) and np.isfinite(v).all()
    assert np.array_equal(f,sf) and np.array_equal(f,nf) and np.array_equal(nf,snf)
    assert np.array_equal(v,sv) and np.array_equal(neutral,sn)
    # Independent measurements on the reopened compact neutral OBJ, remapping original vertex IDs.
    mapping={original:compact for compact,original in enumerate(asset['bodyVertexIds'])}
    measurements={'height':float(np.ptp(neutral[:,1]))}
    definitions={'height':'standing_height'}
    for c in asset['controls'][1:]:
        path=np.array([mapping[i] for i in c['path']]);measurements[c['key']]=float(np.linalg.norm(np.diff(neutral[path],axis=0),axis=1).sum())
        definitions[c['key']]='landmark_distance' if len(path)==2 else 'surface_tape_path'
    # Rebuild the full rest buffer using the saved shape coefficients and matching anatomical asset.
    full=np.asarray(asset['vertices'],dtype=float).reshape(-1,3).copy()
    for c,w in zip(asset['controls'],state['morphWeights']):
        for idx,x,y,z in c['incr' if w>=0 else 'decr']:full[idx]+=abs(w)*np.array([x,y,z])
    rest=full[asset['bodyVertexIds']].copy();rest[:,1]-=rest[:,1].min()
    rest_error=float(np.abs(rest-neutral).max());assert rest_error<.003
    tapes_error=max(abs(measurements[k]-state['measuredNeutral'][k]) for k in measurements);assert tapes_error<.03
    # Check all saved floating-point joint projections directly from frozen camera metadata.
    pj=json.loads((out/'renders/pose-joints.json').read_text());c=camera['views']['pose'];w,h=camera['width'],camera['height'];s=c['px_per_cm'];cx,cy=c['center_cm']
    lookup={j['name']:j for j in joints['joints']};joint_error=0
    for row in pj['joints']:
        p=np.array(lookup[row['name']]['position']);horizontal=p[2] if c['axis']=='side' else p[0]*(-1 if c['axis']=='back' else 1)
        expected=np.array([(horizontal-cx)*s+w/2,h/2-(p[1]-cy)*s]);joint_error=max(joint_error,float(np.abs(expected-row['pixel']).max()))
        assert row['world_cm']==p.tolist() and row['visible']==bool(0<=expected[0]<w and 0<=expected[1]<h)
    assert len(pj['joints'])==len(asset['bones'])==163 and joint_error<.001
    expected_edges=[[j['parent'],j['name']] for j in joints['joints'] if j.get('parent') in lookup];assert pj['edges']==expected_edges
    # Independent 40-pixel triangle intersections (vectorized across all triangles).
    raw=np.load(out/'renders/rawdepth.npy');depth=np.load(out/'renders/depth.npy');valid=cv2.imread(str(out/'renders/depth-valid.png'),0)
    assert raw.dtype==np.float32 and np.array_equal(raw,depth) and np.array_equal(valid,(np.isfinite(raw)*255).astype(np.uint8))
    assert np.isneginf(raw[~np.isfinite(raw)]).all()
    dc=camera['views']['depth'];s=dc['px_per_cm'];cx,cy=dc['center_cm'];axis=dc['axis']
    horizontal=v[:,2] if axis=='side' else v[:,0]*(-1 if axis=='back' else 1)
    world_depth=v[:,0] if axis=='side' else v[:,2]*(-1 if axis=='back' else 1)
    projected=np.column_stack(((horizontal-cx)*s+w/2,h/2-(v[:,1]-cy)*s));tri=projected[f];a,b,c=tri[:,0],tri[:,1],tri[:,2]
    den=(b[:,1]-c[:,1])*(a[:,0]-c[:,0])+(c[:,0]-b[:,0])*(a[:,1]-c[:,1]);nondeg=np.abs(den)>1e-10;safe=np.where(nondeg,den,1)
    pixels=np.argwhere(np.isfinite(raw));rng=np.random.default_rng(20261117);sample=pixels[rng.choice(len(pixels),40,replace=False)];hit_errors=[]
    for y,x in sample:
        u=((b[:,1]-c[:,1])*(x-c[:,0])+(c[:,0]-b[:,0])*(y-c[:,1]))/safe
        vv=((c[:,1]-a[:,1])*(x-c[:,0])+(a[:,0]-c[:,0])*(y-c[:,1]))/safe;ww=1-u-vv
        hits=nondeg&(u>=-1e-7)&(vv>=-1e-7)&(ww>=-1e-7);z=u*world_depth[f[:,0]]+vv*world_depth[f[:,1]]+ww*world_depth[f[:,2]]
        expected=float(z[hits].max());hit_errors.append(abs(expected-float(raw[y,x])))
    assert max(hit_errors)<.001
    encoded=cv2.imread(str(out/'renders/depth.png'),cv2.IMREAD_UNCHANGED);lo,hi=camera['depth_range_cm'];finite=np.isfinite(raw)
    expected=np.zeros_like(encoded);expected[finite]=np.clip(1+253*(raw[finite]-lo)/(hi-lo),1,254).astype(np.uint8)
    encode_error=int(np.abs(encoded.astype(int)-expected.astype(int)).max());assert encoded.ndim==2 and encode_error<=1
    images={}
    for name in camera['views']:
        im=cv2.imread(str(out/'renders'/f'{name}.png'),cv2.IMREAD_UNCHANGED);mask=cv2.imread(str(out/'renders'/f'{name}-mask.png'),0)
        assert im.shape[:2]==(h,w) and mask.shape==(h,w) and np.count_nonzero(mask)>0
        images[name]={'shape':list(im.shape),'mask_foreground_pixels':int(np.count_nonzero(mask)),'sha256':sha(out/'renders'/f'{name}.png')}
    neutral_height=measurements['height'];posed_height=float(np.ptp(v[:,1]));assert neutral_height-posed_height>20
    metrics={'units':'cm','basis':'mesh_parameter','synthetic_control':True,'neutral_height_cm':neutral_height,'posed_height_cm':posed_height,'neutralHeightCm':neutral_height,'posedHeightCm':posed_height,'measuredNeutral':measurements,'neutral_measurements_cm':measurements,'measurement_definitions':definitions,'vertex_count':len(v),'triangle_count':len(f),'bone_count':len(joints['joints']),'neutral_asset_reconstruction_max_error_cm':rest_error,'neutral_saved_measurement_max_error_cm':tapes_error,'posed_source_max_coordinate_error_cm':float(np.abs(v-sv).max()),'neutral_source_max_coordinate_error_cm':float(np.abs(neutral-sn).max()),'depth':{'semantics':'Signed source X for side orthographic camera; larger is nearer; not camera distance. Background -inf.','dtype':str(raw.dtype),'valid_pixels':int(finite.sum()),'sampled_triangle_hits':40,'max_triangle_depth_error_cm':max(hit_errors),'encoded_max_error':encode_error,'depth_range_cm':[lo,hi]},'joint_projection_max_error_px':joint_error,'images':images,'sha256':{name:sha(out/name) for name in ['final.obj','neutral.obj','state.json','camera.json','joints.json','render_mesh.py']},'asset_sha256':sha(asset_path),'limits':['Synthetic MakeHuman control; no photographed-person measurements.','Neutral tape paths and landmark distances differ from planar cross sections.','Skeleton visibility means inside canvas, not occlusion visibility.','Linear blend skinning is not tissue or cloth simulation.','Fixed camera is deliberately preserved, including framing.']}
    (out/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n');print(json.dumps(metrics,indent=2))
if __name__=='__main__':main()
