#!/usr/bin/env python3
"""Reopen delivered files and compare every pixel to deterministic source rasterization."""
import json
from pathlib import Path
import cv2
import numpy as np
from render_mesh import obj,raster
out=Path(__file__).resolve().parent
fixture=Path('/workspace/work/pattern-agent/work/anatomical-skill-evals-20261117/fixtures/pose-depth-evidence')
v,f=obj(fixture/'source-posed.obj');camera=json.loads((fixture/'camera.json').read_text());joints=json.loads((fixture/'source-joints.json').read_text())
for source,dest in [('source-posed.obj','final.obj'),('source-neutral.obj','neutral.obj'),('source-state.json','state.json'),('source-joints.json','joints.json'),('camera.json','camera.json')]:assert (fixture/source).read_bytes()==(out/dest).read_bytes()
rows={}
for view in camera['views']:
    mask,im,depth,raw=raster(v,f,camera,view,joints)
    saved=cv2.imread(str(out/'renders'/f'{view}.png'),cv2.IMREAD_UNCHANGED);sm=cv2.imread(str(out/'renders'/f'{view}-mask.png'),0)
    ref=depth if view=='depth' else im;intersection=np.logical_and(mask>0,sm>0).sum();union=np.logical_or(mask>0,sm>0).sum()
    error=float(np.abs(saved.astype(float)-ref.astype(float)).mean());iou=float(intersection/union)
    assert error==0 and iou==1
    rows[view]={'mean_absolute_pixel_error':error,'mask_iou':iou,'pixels_equal':True}
    if view=='depth':assert np.array_equal(np.load(out/'renders/rawdepth.npy'),raw.astype(np.float32))
(out/'pixel-replay-check.json').write_text(json.dumps({'verdict':'PASS','method':'Reopened delivered files; rerasterized untouched source OBJ and source joints using supplied deterministic renderer with frozen fixture camera.','views':rows},indent=2)+'\n')
print(json.dumps(rows,indent=2))
