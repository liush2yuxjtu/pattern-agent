import os,json,time,shutil,hashlib
from pathlib import Path
import cv2,numpy as np
from scipy.optimize import minimize
ROOT=Path('/workspace/work/pattern-agent');OUT=Path(__file__).parent;FIX=ROOT/'work/anatomical-skill-evals-20261117/fixtures/anatomical-fit'
a=json.loads((ROOT/'web/human-studio/assets/human.json').read_text());initial=json.loads((FIX/'initial-state.json').read_text());cam=json.loads((FIX/'camera.json').read_text());base=np.array(a['vertices']).reshape(-1,3);ids=np.array(a['bodyVertexIds']);faces=np.array(a['indices']).reshape(-1,3)
inc=np.zeros((12,*base.shape));dec=inc.copy()
for i,c in enumerate(a['controls']):
 for target,key in [(inc,'incr'),(dec,'decr')]:
  rows=np.array(c[key]);target[i,rows[:,0].astype(int)]=rows[:,1:]
refs={v:cv2.imread(str(FIX/f'reference-{v}-mask.png'),0)>127 for v in ['front','side']}
dist={v:cv2.distanceTransform((~r).astype('uint8'),cv2.DIST_L2,3)+cv2.distanceTransform(r.astype('uint8'),cv2.DIST_L2,3) for v,r in refs.items()}
def build(w):
 v=base+np.einsum('i,ijk->jk',np.maximum(w,0),inc)+np.einsum('i,ijk->jk',np.maximum(-w,0),dec);v[:,1]-=v[ids,1].min();return v
def masks(v):
 out={}
 for view in refs:
  c=cam['views'][view];p=np.rint(np.c_[(v[:,2] if view=='side' else v[:,0])*2.4+192,256-(v[:,1]-92)*2.4]).astype('int32');m=np.zeros((512,384),np.uint8)
  for tri in p[faces]:cv2.fillConvexPoly(m,tri,1)
  out[view]=m.astype(bool)
 return out
def iou(p,r):return float((p&r).sum()/(p|r).sum())
def measure(v):
 return {c['key']:float(np.ptp(v[ids,1]) if c['key']=='height' else np.linalg.norm(np.diff(v[c['path']],axis=0),axis=1).sum()) for c in a['controls']}
trace=[];best=[1e10,None];count=0;start=time.time()
def objective(w):
 global count
 v=build(w);ms=masks(v);scores={k:iou(ms[k],refs[k]) for k in refs};loss=sum(float(dist[k][ms[k]^refs[k]].sum()/refs[k].sum()) for k in refs)
 dims=measure(v);penalty=sum(max(c['min']-dims[c['key']],0)**2+max(dims[c['key']]-c['max'],0)**2 for c in a['controls']);loss+=penalty
 count+=1
 if loss<best[0]:
  best[:]=[loss,w.copy()];row={'evaluation':count,'seconds':round(time.time()-start,2),'loss':loss,'iou':scores,'weights':w.tolist(),'dimensions':dims};trace.append(row)
  (OUT/'search-trace.json').write_text(json.dumps(trace,indent=2));np.save(OUT/'best-weights.npy',w)
 if count%100==0:print(count,round(loss,6),scores,flush=True)
 return loss
w=np.array(initial['morphWeights']);initial_ms=masks(build(w));(OUT/'initial-metrics.json').write_text(json.dumps({k:iou(initial_ms[k],refs[k]) for k in refs},indent=2))
for round_no in range(3):
 res=minimize(objective,w,method='Powell',bounds=[(-1.8,1.8)]*12,options={'maxiter':6,'maxfev':2200,'xtol':0.0006,'ftol':0.00001});w=best[1];print('ROUND',round_no,best[0],measure(build(w)),flush=True)
 np.save(OUT/'best-weights.npy',w)
 if best[0]<.00015:break
(OUT/'optimized-dimensions.json').write_text(json.dumps({k:round(v,1) for k,v in measure(build(w)).items()},indent=2))
