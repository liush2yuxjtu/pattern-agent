import json,cv2,numpy as np,hashlib,csv,sys
from pathlib import Path
OUT=Path(__file__).parent;ROOT=Path('/workspace/work/pattern-agent');FIX=ROOT/'work/anatomical-skill-evals-20261117/fixtures/anatomical-fit';sys.path.insert(0,str(ROOT/'work/anatomical-skill-evals-20261117/fixtures'));from render_mesh import obj
state=json.loads((OUT/'state.json').read_text());metrics={'mode':'synthetic anatomical control','projection':'fixed orthographic; centimetres Y-up; unchanged fixture cameras','initial':{},'final':{},'improvement':{},'constraints':{}}
def scores(p,r):
 inter=(p&r).sum();union=(p|r).sum();cont=lambda m:cv2.morphologyEx(m.astype('uint8'),cv2.MORPH_GRADIENT,np.ones((3,3),np.uint8))>0
 pc,rc=cont(p),cont(r);pd=cv2.distanceTransform((~pc).astype('uint8'),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);rd=cv2.distanceTransform((~rc).astype('uint8'),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);d=np.r_[pd[rc],rd[pc]]
 return {'iou':float(inter/union),'dice':float(2*inter/(p.sum()+r.sum())),'symmetric_contour_mean_px':float(d.mean()),'symmetric_contour_p95_px':float(np.percentile(d,95))}
(OUT/'overlays').mkdir(exist_ok=True)
for view in ['front','side']:
 r=cv2.imread(str(FIX/f'reference-{view}-mask.png'),0)>127
 p=cv2.imread(str(OUT/'renders'/f'{view}-mask.png'),0)>127
 i=cv2.imread(str(FIX/'initial-renders'/f'{view}-mask.png'),0)>127
 metrics['initial'][view]=scores(i,r);metrics['final'][view]=scores(p,r);metrics['improvement'][view]=metrics['final'][view]['iou']-metrics['initial'][view]['iou']
 overlay=np.full((*r.shape,3),242,np.uint8);overlay[r&p]=[70,200,70];overlay[r&~p]=[180,50,230];overlay[p&~r]=[230,210,20];cv2.imwrite(str(OUT/'overlays'/f'{view}.png'),overlay)
v,f=obj(OUT/'final.obj');vi,fi=obj(FIX/'initial.obj');depth=np.load(OUT/'renders/rawdepth.npy');valid=cv2.imread(str(OUT/'renders/depth-valid.png'),0)>0
metrics['constraints']={'finite_vertices':bool(np.isfinite(v).all()),'vertex_count':len(v),'triangle_count':len(f),'exact_source_faces':bool(np.array_equal(f,fi)),'pose_neutral':state['poseDegrees']=={},'fixed_camera':json.loads((OUT/'camera.json').read_text())==json.loads((FIX/'camera.json').read_text()),'maximum_tape_target_residual_cm':state['maximumTargetErrorCm'],'depth_dtype':str(depth.dtype),'depth_valid_exact':bool(np.array_equal(valid,np.isfinite(depth))),'bone_count':len(json.loads((OUT/'joints.json').read_text())['joints'])}
metrics['limitations']=['Synthetic control, not recovered person measurements.','Silhouette fit does not identify internal anatomy or certify physical garment fit.','All dimensions are mesh parameters calculated from neutral surface tape paths or landmarks.']
metrics['hashes']={k:hashlib.sha256((OUT/k).read_bytes()).hexdigest() for k in ['final.obj','state.json','camera.json','joints.json']};(OUT/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
measurements=[{'name':k,'value':v,'unit':'cm','basis':'mesh_parameter','mesh_checked':True,'target':state['dimensions'][k]} for k,v in state['measuredNeutral'].items()];(OUT/'measurements.json').write_text(json.dumps(measurements,indent=2));
with (OUT/'measurements.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=measurements[0].keys());w.writeheader();w.writerows(measurements)
print(json.dumps(metrics,indent=2))
