import json,sys,cv2,numpy as np
from pathlib import Path
OUT=Path(__file__).parent;ROOT=Path('/workspace/work/pattern-agent');sys.path.insert(0,str(ROOT/'work/anatomical-skill-evals-20261117/fixtures'));from render_mesh import obj
v,f=obj(OUT/'final.obj');cam=json.loads((OUT/'camera.json').read_text());checks={'mask_iou':{},'depth':{}};W,H=cam['width'],cam['height']
for name,c in cam['views'].items():
 s=c['px_per_cm'];cx,cy=c['center_cm'];hor=v[:,2] if c['axis']=='side' else v[:,0]*(-1 if c['axis']=='back' else 1);xy=np.c_[(hor-cx)*s+W/2,H/2-(v[:,1]-cy)*s];mask=np.zeros((H,W),np.uint8)
 for tri in np.rint(xy).astype('int32')[f]:cv2.fillConvexPoly(mask,tri,255)
 saved=cv2.imread(str(OUT/'renders'/f'{name}-mask.png'),0)>0;mask=mask>0;checks['mask_iou'][name]=float((saved&mask).sum()/(saved|mask).sum())
 if name=='depth':
  z=np.load(OUT/'renders/rawdepth.npy');pts=np.argwhere(np.isfinite(z));pts=pts[np.linspace(0,len(pts)-1,301).astype(int)];p=xy[f];a,b,c0=p[:,0],p[:,1],p[:,2];den=(b[:,1]-c0[:,1])*(a[:,0]-c0[:,0])+(c0[:,0]-b[:,0])*(a[:,1]-c0[:,1]);nz=abs(den)>1e-10;den=np.where(nz,den,1);errs=[]
  depths=v[f,0]
  for y,x in pts:
   u=((b[:,1]-c0[:,1])*(x-c0[:,0])+(c0[:,0]-b[:,0])*(y-c0[:,1]))/den;vv=((c0[:,1]-a[:,1])*(x-c0[:,0])+(a[:,0]-c0[:,0])*(y-c0[:,1]))/den;ww=1-u-vv;hit=nz&(u>=-1e-7)&(vv>=-1e-7)&(ww>=-1e-7);d=u*depths[:,0]+vv*depths[:,1]+ww*depths[:,2];errs.append(abs(d[hit].max()-z[y,x]))
  dep=cv2.imread(str(OUT/'renders/depth.png'),0);valid=np.isfinite(z);lo,hi=cam['depth_range_cm'];expected=np.zeros_like(dep);expected[valid]=np.clip(1+253*(z[valid]-lo)/(hi-lo),1,254).astype('uint8');checks['depth']={'independent_sample_count':len(errs),'max_triangle_depth_error_cm':float(max(errs)),'encoding_mean_abs_error_uint8':float(np.abs(dep.astype(float)-expected).mean()),'background_zero':bool((dep[~valid]==0).all()),'raw_arrays_equal':bool(np.array_equal(z,np.load(OUT/'renders/depth.npy')))}
assert min(checks['mask_iou'].values())==1
assert checks['depth']['max_triangle_depth_error_cm']<.001
(OUT/'geometry-check.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks,indent=2))
