from pathlib import Path
import json,hashlib,sys
import cv2,numpy as np
OUT=Path(__file__).parent;ROOT=Path('/workspace/work/pattern-agent');FIX=ROOT/'work/anatomical-skill-evals-20261117/fixtures/anatomical-fit'
def obj(p):
 v=[];f=[]
 for line in Path(p).read_text().splitlines():
  x=line.split()
  if x and x[0]=='v':v.append(list(map(float,x[1:4])))
  if x and x[0]=='f':f.append([int(y.split('/')[0])-1 for y in x[1:]])
 return np.array(v),np.array(f)
def project(v,c):
 axis=c['axis'];horizontal=v[:,2] if axis=='side' else v[:,0]*(-1 if axis=='back' else 1);return np.column_stack(((horizontal-c['center_cm'][0])*c['px_per_cm']+192,256-(v[:,1]-c['center_cm'][1])*c['px_per_cm']))
def mask(v,f,c):
 m=np.zeros((512,384),np.uint8)
 for p in np.rint(project(v,c)[f]).astype('int32'):cv2.fillConvexPoly(m,p,255)
 return m>0
def metric(r,m):
 b1=r^cv2.erode(r.astype('uint8'),np.ones((3,3),np.uint8)).astype(bool);b2=m^cv2.erode(m.astype('uint8'),np.ones((3,3),np.uint8)).astype(bool)
 d1=cv2.distanceTransform((~b1).astype('uint8'),cv2.DIST_L2,5);d2=cv2.distanceTransform((~b2).astype('uint8'),cv2.DIST_L2,5);ds=np.r_[d1[b2],d2[b1]]
 return {'IoU':float((r&m).sum()/(r|m).sum()),'Dice':float(2*(r&m).sum()/(r.sum()+m.sum())),'symmetric_contour_mean_px':float(ds.mean()),'symmetric_contour_p95_px':float(np.percentile(ds,95))}
cam=json.loads((OUT/'camera.json').read_text());a,af=obj(FIX/'initial.obj');v,f=obj(OUT/'final.obj');data=json.loads((ROOT/'web/human-studio/assets/human.json').read_text());state=json.loads((OUT/'state.json').read_text());ids=np.array(data['bodyVertexIds']);inv=np.full(len(data['vertices'])//3,-1);inv[ids]=np.arange(len(ids));source_f=inv[np.array(data['indices']).reshape(-1,3)]
rest=np.array(data['vertices']).reshape(-1,3)
for c,w in zip(data['controls'],state['morphWeights']):
 rows=np.array(c['incr' if w>=0 else 'decr']);rest[rows[:,0].astype(int)]+=abs(w)*rows[:,1:]
rest[:,1]-=rest[ids,1].min();measured={c['key']:float(np.ptp(rest[ids,1])) if c['key']=='height' else float(np.linalg.norm(np.diff(rest[c['path']],axis=0),axis=1).sum()) for c in data['controls']}
metrics={'protocol':{'reference':'supplied synthetic anatomical control masks','units':'cm','camera':'fixed supplied orthographic metadata; no fit/scale/pose changes','resolution':[384,512],'search':'bounded Powell 12 source morphs; 656 actual evaluations; objective symmetric boundary distance; dimension ranges enforced; three decreasing tolerances','limitation':'Geometric synthetic control fit, not recovered person measurements; no physical cloth/tissue simulation.'},'views':{},'validation':{'finite_vertices':int(np.isfinite(v).all()),'vertex_count':len(v),'triangle_count':len(f),'exact_source_triangle_order':bool(np.array_equal(f,source_f)),'exact_initial_triangle_order':bool(np.array_equal(f,af)),'fixed_camera_bytes_equal':(OUT/'camera.json').read_bytes()==(FIX/'camera.json').read_bytes(),'state_reconstruction_max_vertex_difference_cm':float(abs(v-rest[ids]).max()),'independent_neutral_measurements_cm':measured,'max_dimension_residual_cm':max(abs(measured[k]-state['dimensions'][k]) for k in measured),'neutral_pose':state['poseDegrees']=={}},'six_render_masks':{}}
(OUT/'overlays').mkdir(exist_ok=True);(OUT/'evidence').mkdir(exist_ok=True)
for name in ['front','side']:
 r=cv2.imread(str(FIX/f'reference-{name}-mask.png'),0)>127;im=mask(a,af,cam['views'][name]);fm=mask(v,f,cam['views'][name]);initial=metric(r,im);final=metric(r,fm);metrics['views'][name]={'initial':initial,'final':final,'IoU_improvement':final['IoU']-initial['IoU']};cv2.imwrite(str(OUT/'evidence'/f'initial-{name}-mask.png'),im.astype('uint8')*255)
 overlay=np.full((512,384,3),242,np.uint8);overlay[r&fm]=(70,190,70);overlay[r&~fm]=(180,60,230);overlay[fm&~r]=(240,210,40);cv2.imwrite(str(OUT/'overlays'/f'{name}.png'),overlay)
for name,c in cam['views'].items():
 independent=mask(v,f,c);saved=cv2.imread(str(OUT/'renders'/f'{name}-mask.png'),0)>127;metrics['six_render_masks'][name]=metric(independent,saved)
# Independently evaluate nearest triangle depth for deterministic foreground/background samples.
z=np.load(OUT/'renders/rawdepth.npy');z2=np.load(OUT/'renders/depth.npy');valid=np.isfinite(z);saved_valid=cv2.imread(str(OUT/'renders/depth-valid.png'),0)>127
xy=project(v,cam['views']['depth'])[f];d=v[f,0];aa,bb,cc=xy[:,0],xy[:,1],xy[:,2];den=(bb[:,1]-cc[:,1])*(aa[:,0]-cc[:,0])+(cc[:,0]-bb[:,0])*(aa[:,1]-cc[:,1]);good=abs(den)>1e-10;safe=np.where(good,den,1)
rng=np.random.default_rng(20261117);coords=np.argwhere(valid);sample=coords[rng.choice(len(coords),min(600,len(coords)),replace=False)];errors=[]
for y,x in sample:
 u=((bb[:,1]-cc[:,1])*(x-cc[:,0])+(cc[:,0]-bb[:,0])*(y-cc[:,1]))/safe;t=((cc[:,1]-aa[:,1])*(x-cc[:,0])+(aa[:,0]-cc[:,0])*(y-cc[:,1]))/safe;s=1-u-t;hit=good&(u>=-1e-7)&(t>=-1e-7)&(s>=-1e-7);expected=(u*d[:,0]+t*d[:,1]+s*d[:,2])[hit].max();errors.append(abs(float(z[y,x])-expected))
lo,hi=cam['depth_range_cm'];encoded=np.zeros(z.shape,'uint8');encoded[valid]=np.clip(1+253*(z[valid]-lo)/(hi-lo),1,254).astype('uint8');saved=cv2.imread(str(OUT/'renders/depth.png'),0)
metrics['validation']['depth']={'dtype':str(z.dtype),'finite_pixels':int(valid.sum()),'negative_infinity_background':bool(np.isneginf(z[~valid]).all()),'valid_mask_exact':bool(np.array_equal(valid,saved_valid)),'rawdepth_matches_depth_npy':bool(np.array_equal(z,z2)),'encoded_mean_absolute_error':float(abs(encoded.astype(float)-saved).mean()),'independent_sample_count':len(errors),'independent_sample_max_depth_error_cm':max(errors),'semantics':'signed source X, larger nearer; -inf background; nearest actual triangle; fixed range [-90,90] cm'}
metrics['hashes']={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [OUT/'final.obj',OUT/'state.json',OUT/'joints.json',OUT/'camera.json']};metrics['reference_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in FIX.iterdir() if p.is_file()}
(OUT/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n');print(json.dumps(metrics['views'],indent=2));print(json.dumps(metrics['validation'],indent=2))
