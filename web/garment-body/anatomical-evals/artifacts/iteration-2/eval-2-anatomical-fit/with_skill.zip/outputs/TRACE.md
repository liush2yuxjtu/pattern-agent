# Anatomical fit execution trace

Scope: fit the supplied synthetic anatomical control, with the candidate-v2 garment-body-six-view skill and its human-studio, geometry-evidence and tools-and-evidence references. Read repository AGENTS.md. No network, generation services, private oracle, graders, other runs/iterations or skill versions were accessed. No shared sources, fixtures or skill files were modified. No commits were made, as explicitly requested for this evaluation.

Inputs were visually inspected: front and side are neutral-pose anatomical triangle renders, not photographs. Camera is the supplied fixed orthographic 384×512, 2.4 px/cm for front/side; its file is copied byte-for-byte. Y-up centimetres and source body vertex order are preserved. References and input SHA-256 are recorded in metrics.json.

## Actual execution

1. `OPENBLAS_NUM_THREADS=1 python outputs/fit.py`: started at supplied initial morph weights, reconstructed all source rest vertices and exact source surface topology, rasterized every triangle with OpenCV at the final 384×512 resolution. Used three bounded Powell rounds across the 12 source shape morphs, enforcing each supplied control's dimension range with a penalty; pose and camera were never optimized. 656 evaluations, 29.3 seconds. Each improving candidate's weights, independently computed dimensions, per-view IoU and loss are in search-history.json; raw progress is search.log. Stopped after the three tolerance rounds showed diminishing improvements. The current best candidate was retained rather than a worse Powell endpoint.
2. `node outputs/export.mjs`: rounded independently measured targets to the engine's required 0.1 cm increments, invoked the unchanged body-engine.js fitDimensions, exported the calibrated neutral source body to final.obj, and saved complete state.json. All 163 bone heads were calculated using the engine's jointPosition(data, finalFullRestBuffer, bone.head), then saved in joints.json. No compact-surface indexing was used for joints.
3. Ran the supplied `fixtures/render_mesh.py --mesh outputs/final.obj --camera outputs/camera.json --joints outputs/joints.json --out outputs/renders` once after fitting. It produced all six independent actual triangle views and masks, annotated pose using actual projected rig points/parents, projected joint records, signed-source-X depth, float32 depth.npy/rawdepth.npy and finite mask.
4. `python skill-candidate-v2/scripts/inspect_human_state.py --state outputs/state.json --asset-json web/human-studio/assets/human.json --require-match --out outputs/neutral-state-check.json`: PASS; independent rest reconstruction and all twelve neutral tape/landmark measurements match.
5. `python outputs/audit.py`: independently read initial.obj/final.obj, rerasterized masks, measured initial/final fit at full resolution, made OpenCV overlap overlays, checked source topology/camera/state reconstruction and depth encoding. Independently intersected all source triangles at 600 deterministic randomly selected valid depth pixels; maximum raw-depth error was 0.000001864 cm. Full rawdepth/depth arrays and finite masks matched exactly. All six saved render masks have IoU 1.0 against independent raw-OBJ projection. No independent full-image lighting comparison was run; all render pixels were produced directly by the prescribed unchanged deterministic renderer.
6. `node outputs/refit-check.mjs`: independent fitDimensions from default zero weights and saved dimensions differs from the final saved body by at most 0.0000317 cm, below the 0.05 cm contract.

## Achieved final result

| View | Initial IoU | Final IoU | Improvement | Final Dice | Contour mean / P95 px |
|---|---:|---:|---:|---:|---:|
| front | 0.913046 | 0.989441 | 0.076395 | 0.994693 | 0.133390 / 1.0 |
| side | 0.916940 | 0.993139 | 0.076199 | 0.996558 | 0.086233 / 1.0 |

The front view is the weaker view. Both exceed IoU 0.97 and improve by more than 0.01. Final measurements are synthetic mesh parameters, not recovered person measurements. Maximum neutral target error is 0.0000173 cm. final.obj has 13,380 finite vertices and exactly 26,756 triangles in source order; neutral poseDegrees is empty. Independent saved-state surface reconstruction differs by less than 5e-10 cm. The fixed camera matches the fixture bytes exactly.

Overlays: green overlap, magenta reference only, cyan candidate only. Viewed the final front overlay and actual side pose render: overall alignment is close; residual silhouette errors are localized, largely subpixel/one-pixel boundaries. No tissue/cloth simulation, photographic accuracy, real-person measurement recovery, or unseen-view observational accuracy is claimed. Back and close-up are renders of the fitted synthetic mesh and are not held-out real-world evidence.

Files: final.obj, state.json, camera.json, joints.json, metrics.json; overlays/front.png and side.png; renders/{front,side,back,close-up,pose,depth}.png and their masks; renders/pose-joints.json; renders/depth.npy, rawdepth.npy, depth-valid.png. Supporting executable code and intermediate search evidence are all local to this output directory.
