import json,time,sys,hashlib,importlib.util
from pathlib import Path
import numpy as np,cv2
from scipy.optimize import minimize
ROOT=Path('/workspace/work/pattern-agent'); OUT=Path(__file__).parent; FIX=ROOT/'work/anatomical-skill-evals-20261117/fixtures/anatomical-fit'
data=json.loads((ROOT/'web/human-studio/assets/human.json').read_text());initial=json.loads((FIX/'initial-state.json').read_text());camera=json.loads((FIX/'camera.json').read_text())
base=np.array(data['vertices']).reshape(-1,3);ids=np.array(data['bodyVertexIds']); inverse=np.full(len(base),-1);inverse[ids]=np.arange(len(ids));faces=inverse[np.array(data['indices']).reshape(-1,3)]
bases=[]
for sign in ['incr','decr']:
 b=np.zeros((12,len(base),3))
 for i,c in enumerate(data['controls']):
  a=np.array(c[sign]);b[i,a[:,0].astype(int)]=a[:,1:]
 bases.append(b)
# Tensordot can have expensive multithreading overhead; explicit sum is small and deterministic.
def full(w):
 v=base.copy()
 for i,weight in enumerate(w):v+=bases[0 if weight>=0 else 1][i]*abs(weight)
 v[:,1]-=v[ids,1].min();return v
refs=[cv2.imread(str(FIX/f'reference-{name}-mask.png'),0)>127 for name in ['front','side']]
refdist=[cv2.distanceTransform((~r).astype('uint8'),cv2.DIST_L2,5)-cv2.distanceTransform(r.astype('uint8'),cv2.DIST_L2,5) for r in refs]
def raster(v,axis):
 xy=np.column_stack((v[:,axis]*2.4+192,256-(v[:,1]-92)*2.4));polys=np.rint(xy[faces]).astype(np.int32);m=np.zeros((512,384),np.uint8)
 for p in polys:cv2.fillConvexPoly(m,p,1)
 return m>0
calls=0;best=1e10;history=[];start=time.time()
def evaluate(w,record=True):
 global calls,best
 v=full(w);surface=v[ids];ms=[raster(surface,a) for a in [0,2]];ious=[np.count_nonzero(m&r)/np.count_nonzero(m|r) for m,r in zip(ms,refs)]
 # symmetric boundary distance keeps both views relevant, with continuous distance and overlap terms.
 losses=[]
 for m,r,rd in zip(ms,refs,refdist):
  boundary=m^cv2.erode(m.astype('uint8'),np.ones((3,3),np.uint8)).astype(bool)
  candidate_dist=cv2.distanceTransform((~m).astype('uint8'),cv2.DIST_L2,5)-cv2.distanceTransform(m.astype('uint8'),cv2.DIST_L2,5)
  rb=r^cv2.erode(r.astype('uint8'),np.ones((3,3),np.uint8)).astype(bool)
  losses.append(float(np.mean(np.abs(rd[boundary]))+np.mean(np.abs(candidate_dist[rb]))))
 measured=measure(v);penalty=sum(max(c['min']-measured[c['key']],0,measured[c['key']]-c['max'])**2 for c in data['controls'])
 loss=sum(losses)+20*penalty
 calls+=1
 if loss<best:
  best=loss;row={'evaluation':calls,'elapsed_s':time.time()-start,'loss':loss,'IoU':dict(zip(['front','side'],ious)),'weights':list(w),'dimensions':measured};history.append(row);(OUT/'best-search.json').write_text(json.dumps(row,indent=2));print(calls,round(loss,4),[round(x,5) for x in ious],flush=True)
 return loss
def measure(v):
 result={}
 for c in data['controls']:
  result[c['key']]=float(np.ptp(v[ids,1])) if c['key']=='height' else float(np.linalg.norm(np.diff(v[c['path']],axis=0),axis=1).sum())
 return result
w=np.array(initial['morphWeights']);evaluate(w)
for it,step in enumerate([.12,.04,.015]):
 result=minimize(evaluate,w,method='Powell',bounds=[(-2,2)]*12,options={'maxiter':5,'maxfev':1800,'xtol':step,'ftol':.0001});w=np.array(json.loads((OUT/'best-search.json').read_text())['weights']);print('ROUND',it,'calls',calls,flush=True)
 (OUT/'search-history.json').write_text(json.dumps(history,indent=2))
(OUT/'candidate-dimensions.json').write_text(json.dumps({k:round(v,1) for k,v in measure(full(w)).items()},indent=2));(OUT/'optimized-weights.json').write_text(json.dumps(list(w)))
print('DONE',time.time()-start,flush=True)
