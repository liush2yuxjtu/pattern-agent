#!/usr/bin/env python3
"""Offline immutable-input anatomical state audit. Python standard library only."""
import argparse,csv,hashlib,json,math,platform
from pathlib import Path

RANGES={'height':(145,195),'bust':(72,120),'waist':(54,108),'hips':(80,126),'shoulders':(30,46),'upperArm':(20,40),'thigh':(40,76),'neck':(28,44),'upperArmLength':(24,38),'forearmLength':(18,31),'thighLength':(30,52),'calf':(28,48)}
FILES=['reference.json','metre-label.json','nonfinite-angle.json','pose-joint.json','reported-bust.json','unreached-target.json','posed-cm.obj']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def finite(v):return type(v) in (int,float) and math.isfinite(v)
def reconstruct(state,asset):
    w=state.get('morphWeights')
    if not isinstance(w,list) or len(w)!=12 or not all(finite(v) and -2<=v<=2 for v in w):raise ValueError('Invalid morphWeights')
    p=list(asset['vertices'])
    for c,v in zip(asset['controls'],w):
        for i,x,y,z in c['incr' if v>=0 else 'decr']:
            for ax,delta in enumerate((x,y,z)):p[3*i+ax]+=abs(v)*delta
    if not all(finite(v) for v in p):raise ValueError('Nonfinite reconstructed geometry')
    ys=[p[i*3+1] for i in asset['bodyVertexIds']]
    m={'height':max(ys)-min(ys)}
    for c in asset['controls'][1:]:
        m[c['key']]=sum(math.dist(p[3*a:3*a+3],p[3*b:3*b+3]) for a,b in zip(c['path'],c['path'][1:]))
    return m

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fixtures',type=Path,required=True);parser.add_argument('--asset',type=Path,required=True);parser.add_argument('--out',type=Path,required=True)
    a=parser.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    before={f:sha(a.fixtures/f) for f in FILES};source=json.loads((a.fixtures/'source.json').read_text());asset_hash=sha(a.asset);asset=json.loads(a.asset.read_text())
    assert asset_hash==source['asset_sha256'],'Source asset fingerprint mismatch'
    assert asset['schema']==1 and asset['unit']=='cm'
    assert [c['key'] for c in asset['controls']]==list(RANGES)
    assert all(finite(x) for x in asset['vertices'])
    bones={b['name'] for b in asset['bones']};cases=[];details={};reference=None
    for filename in FILES[:-1]:
        s=json.loads((a.fixtures/filename).read_text());errors=[]
        if s.get('version')!='makehuman-cm-rig-v1':errors.append('Unsupported state version')
        if s.get('units')!='cm':errors.append('State units must be cm; metre label is incompatible with this asset/export contract')
        if s.get('asset')!=asset_hash:errors.append('State/asset SHA256 mismatch')
        for field in ['dimensions','measuredNeutral']:
            d=s.get(field)
            if not isinstance(d,dict) or set(d)!=set(RANGES) or not all(finite(v) and v>0 for v in d.values()):errors.append(field+' must contain all 12 finite positive measurements')
        for k,(lo,hi) in RANGES.items():
            v=s.get('dimensions',{}).get(k)
            if not finite(v) or not lo<=v<=hi or abs(v*10-round(v*10))>=1e-7:errors.append('Invalid target '+k)
        pose=s.get('poseDegrees')
        if not isinstance(pose,dict):errors.append('Missing poseDegrees')
        else:
            for bone,angles in pose.items():
                if bone not in bones:errors.append('Unknown pose bone: '+bone)
                if not isinstance(angles,list) or len(angles)!=3 or not all(finite(v) and -180<=v<=180 and abs(v*10-round(v*10))<1e-7 for v in angles):errors.append('Invalid/nonfinite joint rotation: '+bone)
        m=None;residual=None;delta=None
        try:
            m=reconstruct(s,asset)
            residual=max(abs(m[k]-s['dimensions'][k]) for k in RANGES)
            delta=max(abs(m[k]-s['measuredNeutral'][k]) for k in RANGES)
            if delta>=.002:errors.append('Saved measuredNeutral disagrees with independently reconstructed mesh (maximum difference %.9f cm)'%delta)
            reported=s.get('maximumTargetErrorCm')
            declared_residual=max(abs(s['dimensions'][k]-s['measuredNeutral'][k]) for k in RANGES)
            if not finite(reported) or reported<0 or abs(reported-declared_residual)>=.002:errors.append('False/invalid maximumTargetErrorCm')
            if not finite(reported) or abs(reported-residual)>=.002:errors.append('Reported target residual disagrees with independently reconstructed mesh')
        except (ValueError,KeyError,TypeError) as e:errors.append(str(e))
        classification='invalid' if errors else ('verified' if residual<=.2 else 'closest_supported')
        reason='; '.join(errors) if errors else ('Valid state; all 12 neutral targets achieved within 0.2 cm model tolerance.' if classification=='verified' else 'Valid state and faithful reported measurements/residual; standing-height target is not achieved. Retain closest saved supported geometry, not target as measured. No new solver optimality claim.')
        cases.append(dict(file=filename,classification=classification,reason=reason,neutral_mesh_checked=m is not None,maximum_target_error_cm=residual))
        details[filename]=dict(recomputed_neutral=m,maximum_saved_measurement_difference_cm=delta,errors=errors,pose_bones_checked=list(pose) if isinstance(pose,dict) else [])
        if filename=='reference.json':
            assert classification=='verified';reference=m
    vertices=[]
    for line in (a.fixtures/'posed-cm.obj').read_text().splitlines():
        if line.startswith('v '):
            xyz=list(map(float,line.split()[1:4]));assert len(xyz)==3 and all(finite(v) for v in xyz);vertices.append(xyz)
    assert vertices
    bbox=max(v[1] for v in vertices)-min(v[1] for v in vertices)
    after={f:sha(a.fixtures/f) for f in FILES};assert before==after,'Inputs changed during audit'
    assert before==source['files'],'Input bytes differ from source manifest'
    audit=dict(cases=cases,measurements=reference,basis='mesh_parameter',pose_bbox_height_cm=bbox,camera_recovered=False,real_person_accuracy_established=False,input_hashes=before,asset_sha256=asset_hash,usable_state='reference.json',source_manifest_hash=sha(a.fixtures/'source.json'),input_hashes_unchanged=True,source_manifest_hashes_match=True,coordinate_system='cm; X lateral, Y up, Z front/back',model_match_tolerance_cm=.2,reconstruction_tolerance_cm=.002,details=details,posed_obj_vertex_count=len(vertices),not_run=['Posed skinning correctness and OBJ-to-state identity reconstruction','Browser/UI import, deformation, rendering, save/reload','GLB units, rig and inverse bind verification (no GLB input)','Camera calibration/recovery (state has no camera)','Real-person or photographic accuracy (controlled model data)'])
    (a.out/'audit.json').write_text(json.dumps(audit,indent=2,allow_nan=False)+'\n')
    with (a.out/'measurements.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['key','value','unit','basis'])
        for k,v in reference.items():writer.writerow([k,repr(v),'cm','mesh_parameter'])
    rows='\n'.join('| '+c['file']+' | '+c['classification']+' | '+c['reason']+' |' for c in cases)
    measured_rows='\n'.join('| '+k+' | '+format(v,'.9f')+' |' for k,v in reference.items())
    report=f'''# Anatomical handoff audit

Usable state: **reference.json**. Independently reconstructed neutral geometry achieves all 12 targets within the 0.2 cm model tolerance. Maximum target residual: {cases[0]['maximum_target_error_cm']:.9f} cm. This tolerance concerns model reproduction, not person measurement accuracy.

| State | Classification | Evidence |
| --- | --- | --- |
{rows}

All six states were independently reconstructed from matching asset vertices plus signed sparse morph deltas (positive uses incr, negative uses decr); results are retained even for invalid states. `neutral_mesh_checked: true` means neutral geometry was actually recomputed. It does not override a failed unit, pose or saved-measurement validation. Edited bone names were checked against all {len(bones)} asset bones; rotations require finite XYZ triples within [-180,180] degrees and 0.1-degree steps.

`unreached-target.json` is valid closest-supported saved geometry: neutral standing height is {reference['height']:.9f} cm, while its target is 190 cm and residual is {cases[-1]['maximum_target_error_cm']:.9f} cm. This audit does not rerun the solver or prove global optimality of the morph envelope. `reported-bust.json` falsely adds 2 cm to the saved bust; independent mesh reconstruction catches it despite its internally consistent declared residual.

| Neutral measurement | cm |
| --- | ---: |
{measured_rows}

Definitions: standing height is the neutral surface Y extent; shoulders and the three limb lengths use asset landmark distances; other dimensions follow the asset's named surface tape paths. Tape paths are not substitute horizontal cross-sections. All have basis **mesh_parameter**, describing this controlled MakeHuman model, not a photographed person.

The posed OBJ contains {len(vertices)} vertices in centimetres, Y-up. Its actual bounding-box height is **{bbox:.9f} cm**. That posed height is separate from **{reference['height']:.9f} cm** neutral standing height and cannot establish it. No unit conversion was applied. The OBJ bounding box was measured; posed skinning or correspondence to the saved pose was not independently reconstructed.

All seven required input SHA256 hashes match the source manifest and were identical before and after execution. Asset SHA256: `{asset_hash}`. Inputs were preserved. Full-precision measurements and per-state comparisons are in audit.json and measurements.csv.

Camera recovery: false; state does not contain a camera. Real-person accuracy established: false. No photographs were supplied. No browser, rendering, export skinning or GLB verification was performed; no image generation, network requests or paid tools were used. No physical tissue, collision or garment-fit claim is made.

Reproduce using the command in TRACE.md. The standalone audit script uses only Python standard library and fails on input provenance mismatches.
'''
    (a.out/'report.md').write_text(report)
    print(json.dumps(dict(cases=[{'file':c['file'],'classification':c['classification'],'maximum_target_error_cm':c['maximum_target_error_cm']} for c in cases],neutral_height_cm=reference['height'],pose_bbox_height_cm=bbox,hashes_unchanged=True,python=platform.python_version()),indent=2))
if __name__=='__main__':main()
