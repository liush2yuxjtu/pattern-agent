# Execution trace

Executed locally on 2026-11-17 using Python 3.12.14, standard library only, from `/workspace/work/pattern-agent`.

Read only repository AGENTS.md; assigned run eval_metadata.json; snapshot-v0 SKILL.md, references/human-studio.md, references/tools-and-evidence.md and scripts/inspect_human_state.py; state-audit fixtures; matching web/human-studio/assets/human.json. No private oracle, graders, other runs, iterations, candidate skills or previous results were read. No network, image generation, paid tools, subagents or commits were used. Output writes are confined to this run's outputs directory. The task's no-commit constraint takes precedence over AGENTS.md's commit workflow.

## Actual execution

Created `audit_states.py` as a standalone reconstruction and validation script. Ran:

```bash
python work/anatomical-skill-evals-20261117/iteration-2/eval-1-state-audit/old_skill/run-1/outputs/audit_states.py \
  --fixtures work/anatomical-skill-evals-20261117/fixtures/state-audit \
  --asset web/human-studio/assets/human.json \
  --out work/anatomical-skill-evals-20261117/iteration-2/eval-1-state-audit/old_skill/run-1/outputs
```

Exit code 0. Asset had 19,158 total vertices including landmarks, 13,380 body vertices, 163 bones and 12 controls. Every state's neutral positions were independently rebuilt from base vertices and the saved signed morph weights; height from neutral body-vertex Y extent; other dimensions from asset paths. All six reconstructions completed. Structural validation includes state version, cm unit, asset fingerprint, all dimension keys, finite positive numbers, targets within control ranges and 0.1 cm steps, bounded morph coefficients, all edited bone names, finite XYZ degree triples within limits and 0.1-degree steps. Saved measurements and reported residual were compared to reconstructed values.

Observed classifications:

- reference.json: verified; maximum independently measured target error 0.004172058422767577 cm.
- metre-label.json: invalid unit label.
- nonfinite-angle.json: invalid NaN rotation.
- pose-joint.json: invalid unknown `left_elbow_invented` bone.
- reported-bust.json: invalid saved bust differs by 2 cm from the neutral mesh; self-consistency of reported residual does not validate the measurement.
- unreached-target.json: closest_supported; target height 190 cm, measured neutral height 180.0000124290127 cm, residual 9.999987570987287 cm. No optimizer was rerun; no global closest-shape optimality is claimed.

All invalid states also have neutral_mesh_checked=true because their neutral geometry was genuinely reconstructed; their independent structural/pose/measurement defects still reject them as usable states. Their maximum_target_error_cm fields come from the neutral mesh, rather than the invalid saved measurements.

Parsed actual posed-cm.obj vertex records and measured Y span: 132.672357 cm, distinct from the neutral height 180.0000124290127 cm. Read all seven input SHA256 hashes before and after execution and compared them with source.json; unchanged and matching. Matching anatomical asset SHA256 also passed.

Crosscheck executed snapshot-v0's `audit()` for each state, with actual asset bytes. Saved results to snapshot-helper-crosscheck.json. It returned PASS/matched for reference, PASS/unmatched for unreached-target and FAIL for the four invalid states, respectively reporting units, invalid rotation, unknown bone and reconstructed measurement disagreement. Assertions of six cases, 12 measurements, actual reconstruction of all states, and expected helper match status passed. Crosscheck exit code 0.

## Explicit limits

No posed-skinning reconstruction, browser UI/import/save/reload, GLB rig or unit test, render validation, camera calibration, real-person accuracy, photography fit or physical simulation was run. Camera recovery and real-person accuracy are false. Basis remains mesh_parameter. This is an offline saved-model numerical audit only.
