# Anatomical handoff audit

Usable state: **reference.json**. Independently reconstructed neutral geometry achieves all 12 targets within the 0.2 cm model tolerance. Maximum target residual: 0.004172058 cm. This tolerance concerns model reproduction, not person measurement accuracy.

| State | Classification | Evidence |
| --- | --- | --- |
| reference.json | verified | Valid state; all 12 neutral targets achieved within 0.2 cm model tolerance. |
| metre-label.json | invalid | State units must be cm; metre label is incompatible with this asset/export contract |
| nonfinite-angle.json | invalid | Invalid/nonfinite joint rotation: lowerarm01.L |
| pose-joint.json | invalid | Unknown pose bone: left_elbow_invented |
| reported-bust.json | invalid | Saved measuredNeutral disagrees with independently reconstructed mesh (maximum difference 2.000000000 cm); Reported target residual disagrees with independently reconstructed mesh |
| unreached-target.json | closest_supported | Valid state and faithful reported measurements/residual; standing-height target is not achieved. Retain closest saved supported geometry, not target as measured. No new solver optimality claim. |

All six states were independently reconstructed from matching asset vertices plus signed sparse morph deltas (positive uses incr, negative uses decr); results are retained even for invalid states. `neutral_mesh_checked: true` means neutral geometry was actually recomputed. It does not override a failed unit, pose or saved-measurement validation. Edited bone names were checked against all 163 asset bones; rotations require finite XYZ triples within [-180,180] degrees and 0.1-degree steps.

`unreached-target.json` is valid closest-supported saved geometry: neutral standing height is 180.000012429 cm, while its target is 190 cm and residual is 9.999987571 cm. This audit does not rerun the solver or prove global optimality of the morph envelope. `reported-bust.json` falsely adds 2 cm to the saved bust; independent mesh reconstruction catches it despite its internally consistent declared residual.

| Neutral measurement | cm |
| --- | ---: |
| height | 180.000012429 |
| bust | 96.004172058 |
| waist | 76.000038174 |
| hips | 102.000125098 |
| shoulders | 36.999422539 |
| upperArm | 27.000032246 |
| thigh | 54.000107668 |
| neck | 32.000029190 |
| upperArmLength | 29.000078690 |
| forearmLength | 23.000009302 |
| thighLength | 40.000093735 |
| calf | 36.000006785 |

Definitions: standing height is the neutral surface Y extent; shoulders and the three limb lengths use asset landmark distances; other dimensions follow the asset's named surface tape paths. Tape paths are not substitute horizontal cross-sections. All have basis **mesh_parameter**, describing this controlled MakeHuman model, not a photographed person.

The posed OBJ contains 13380 vertices in centimetres, Y-up. Its actual bounding-box height is **132.672357000 cm**. That posed height is separate from **180.000012429 cm** neutral standing height and cannot establish it. No unit conversion was applied. The OBJ bounding box was measured; posed skinning or correspondence to the saved pose was not independently reconstructed.

All seven required input SHA256 hashes match the source manifest and were identical before and after execution. Asset SHA256: `a75b6a2d59b2fa60ea29393e380182174627ba66d0993c649c8c571a6ccecda6`. Inputs were preserved. Full-precision measurements and per-state comparisons are in audit.json and measurements.csv.

Camera recovery: false; state does not contain a camera. Real-person accuracy established: false. No photographs were supplied. No browser, rendering, export skinning or GLB verification was performed; no image generation, network requests or paid tools were used. No physical tissue, collision or garment-fit claim is made.

Reproduce using the command in TRACE.md. The standalone audit script uses only Python standard library and fails on input provenance mismatches.
