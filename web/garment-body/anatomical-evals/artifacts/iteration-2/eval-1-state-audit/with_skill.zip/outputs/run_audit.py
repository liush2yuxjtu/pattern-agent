#!/usr/bin/env python3
"""Reconstruct neutral meshes without trusting saved measurement claims; stdlib only."""
import csv, hashlib, importlib.util, json, math, sys
sys.dont_write_bytecode = True
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p/'web/human-studio/assets/human.json').is_file())
FIX = ROOT/'work/anatomical-skill-evals-20261117/fixtures/state-audit'
ASSET = ROOT/'web/human-studio/assets/human.json'
SKILL = ROOT/'work/anatomical-skill-evals-20261117/skill-candidate-v2'
NAMES = ['reference.json', 'metre-label.json', 'nonfinite-angle.json', 'pose-joint.json', 'reported-bust.json', 'unreached-target.json']
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def reconstruct(asset, weights):
    # Directly implement morph addition on XYZ tuples, separately from skill helper.
    vertices = [list(asset['vertices'][i:i+3]) for i in range(0,len(asset['vertices']),3)]
    for control, weight in zip(asset['controls'],weights):
        for idx,dx,dy,dz in control['incr' if weight >= 0 else 'decr']:
            for axis,delta in enumerate((dx,dy,dz)):
                vertices[idx][axis] += abs(weight)*delta
    assert all(math.isfinite(c) for v in vertices for c in v)
    heights = [vertices[idx][1] for idx in asset['bodyVertexIds']]
    measurements = {'height':max(heights)-min(heights)}
    for control in asset['controls'][1:]:
        path=control['path']
        measurements[control['key']] = sum(math.sqrt(sum((vertices[b][j]-vertices[a][j])**2 for j in range(3))) for a,b in zip(path,path[1:]))
    return measurements

def main():
    source=json.loads((FIX/'source.json').read_text())
    hashes={n:sha(FIX/n) for n in NAMES+['posed-cm.obj']}
    assert all(source['files'][n]==h for n,h in hashes.items()), 'Source manifest mismatch'
    asset=json.loads(ASSET.read_text()); asset_hash=sha(ASSET)
    assert asset_hash==source['asset_sha256']
    spec=importlib.util.spec_from_file_location('skill_inspector',SKILL/'scripts/inspect_human_state.py')
    helper=importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    keys=[c['key'] for c in asset['controls']]; bones={b['name'] for b in asset['bones']}
    cases=[]; details={}; measures={}
    for name in NAMES:
        state=json.loads((FIX/name).read_text())
        measured=reconstruct(asset,state['morphWeights'])
        residual=max(abs(measured[k]-state['dimensions'][k]) for k in keys)
        difference=max(abs(measured[k]-state['measuredNeutral'][k]) for k in keys)
        unknown=sorted(set(state['poseDegrees'])-bones)
        bad_angles=[k for k,v in state['poseDegrees'].items() if len(v)!=3 or any(type(a) not in (int,float) or not math.isfinite(a) or not -180<=a<=180 or abs(a*10-round(a*10))>1e-7 for a in v)]
        errors=[]
        if state['units']!='cm': errors.append('State units must be cm; supplied '+state['units'])
        if state['asset']!=asset_hash: errors.append('Asset fingerprint mismatch')
        if unknown: errors.append('Unknown pose bone: '+', '.join(unknown))
        if bad_angles: errors.append('Nonfinite or invalid joint rotation: '+', '.join(bad_angles))
        if difference>=0.002: errors.append(f'Saved measuredNeutral disagrees with reconstructed mesh by {difference:.12g} cm')
        if abs(residual-state['maximumTargetErrorCm'])>=0.002: errors.append('maximumTargetErrorCm disagrees with actual reconstructed target residual')
        try: helper_result=helper.audit(state,ASSET.read_bytes(),asset_hash,False)
        except (ValueError,KeyError,TypeError,IndexError) as exc: helper_result={'verdict':'FAIL','error':str(exc)}
        if helper_result['verdict']=='FAIL' and not errors: errors.append(helper_result['error'])
        if not errors:
            assert helper_result['neutral_mesh_checked']
            assert max(abs(measured[k]-helper_result['measuredNeutral'][k]) for k in keys)<1e-9
        classification='invalid' if errors else ('verified' if residual<=0.2 else 'closest_supported')
        reason='; '.join(errors) if errors else (f'All contract, fingerprint, pose name/angle and neutral measurement checks passed; largest actual target residual {residual:.12g} cm.' if classification=='verified' else f'Valid saved coefficients and honest measurements; target not achieved: requested height {state["dimensions"]["height"]} cm, measured {measured["height"]:.12g} cm, residual {residual:.12g} cm. Usable only with this unmet target disclosed; no new solver/calibration run performed.')
        cases.append({'file':name,'classification':classification,'reason':reason,'neutral_mesh_checked':True,'maximum_target_error_cm':residual})
        details[name]={'recomputed_neutral':measured,'maximum_saved_measurement_disagreement_cm':difference,'edited_bones_checked':sorted(state['poseDegrees']),'unknown_bones':unknown,'invalid_angle_bones':bad_angles,'helper_result':helper_result}
        if name=='reference.json': measures=measured
    objverts=[]; faces=0
    for line in (FIX/'posed-cm.obj').read_text().splitlines():
        if line.startswith('v '):
            point=list(map(float,line.split()[1:4])); assert len(point)==3 and all(map(math.isfinite,point)); objverts.append(point)
        elif line.startswith('f '): faces+=1
    bbox=[max(p[i] for p in objverts)-min(p[i] for p in objverts) for i in range(3)]
    assert all(sha(FIX/n)==h for n,h in hashes.items()),'Input mutated'
    audit={'cases':cases,'measurements':measures,'basis':'mesh_parameter','pose_bbox_height_cm':bbox[1],'camera_recovered':False,'real_person_accuracy_established':False,'input_hashes':hashes,'asset_sha256':asset_hash,'usable_state':'reference.json','target_match_tolerance_cm':0.2,'measurement_consistency_tolerance_cm':0.002,'input_hashes_unchanged':True,'source_manifest_checked':True,'obj_audit':{'vertices':len(objverts),'faces':faces,'axis_spans_cm':bbox,'up_axis':'Y','pose':'seated','units':'cm'},'details':details,'not_run':['Browser/UI import and rendering','Posed skinning or neutral-to-posed OBJ correspondence','Topology and intersection audit','Camera reconstruction (not present in state/OBJ)','Real-person or photo accuracy','New bounded solver run to establish global nearest supported solution']}
    (HERE/'audit.json').write_text(json.dumps(audit,indent=2,allow_nan=False)+'\n')
    with (HERE/'measurements.csv').open('w',newline='') as f:
        writer=csv.writer(f); writer.writerow(['key','value','unit','basis']); writer.writerows((k,measures[k],'cm','mesh_parameter') for k in keys)
    table='\n'.join(f'| {c["file"]} | {c["classification"]} | {c["maximum_target_error_cm"]:.9f} | {c["reason"]} |' for c in cases)
    mt='\n'.join(f'| {k} | {measures[k]:.9f} | '+('standing_height' if k=='height' else ('landmark_distance' if next(c for c in asset['controls'] if c['key']==k)['kind']=='landmark distance' else 'surface_tape_path'))+' |' for k in keys)
    (HERE/'report.md').write_text(f'''# Saved anatomical-state audit\n\n`reference.json` is the usable verified handoff. `unreached-target.json` is structurally valid and geometrically consistent but its 190 cm height target is not achieved. The four other states are invalid.\n\n| State | Classification | Actual maximum target error (cm) | Reason |\n|---|---|---:|---|\n{table}\n\nAll six neutral meshes were actually rebuilt from the matching asset's base vertices and signed sparse morph coefficients; all 12 dimensions were recomputed. `neutral_mesh_checked=true` denotes that numerical reconstruction was performed, including on invalid inputs; it does not imply that an invalid state passed. A separate call of candidate v2's helper agrees on valid states and rejects the invalid ones.\n\n## Reference neutral dimensions\n\nAll values have basis `mesh_parameter`, units cm, neutral pose, and derive from the MakeHuman model rather than a photographed person. Height uses Y extent of body vertices; the other measurements sum the asset's specified tape paths or two-landmark distances. Shoulder breadth is bilateral acromion distance, not joint spacing or silhouette width.\n\n| Key | Recomputed cm | Definition |\n|---|---:|---|\n{mt}\n\nThe seated posed OBJ contains {len(objverts)} vertices and {faces} faces. Its Y bounding-box height is **{bbox[1]:.9f} cm**, while independently rebuilt neutral standing height is **{measures['height']:.9f} cm**. The OBJ bounding box cannot establish neutral standing height. OBJ coordinates were read directly in cm; no metre conversion was applied.\n\nThe source manifest's hashes match all six states and the OBJ, and the asset fingerprint is `{asset_hash}`. A before/after hash check found no input changes.\n\nCamera recovery is false: these saved states and OBJ do not contain camera settings. Real-person accuracy is false: these are controlled synthetic model data. Browser import/rendering, posed skinning/correspondence, topology/intersections and a fresh bounded calibration/nearest-solution proof were not run. The closest-supported label preserves an honest supported saved shape with an unmet target; it does not assert that a new optimization proved a global optimum.\n\nReproduce with `python {HERE.relative_to(ROOT)}/run_audit.py` from the repository, or run that script by absolute path from any directory. Only its output directory is written. See `TRACE.md` and `audit.json` for executed checks and complete per-case measurements.\n''')
    print(json.dumps({'classifications':{c['file']:c['classification'] for c in cases},'neutral_height_cm':measures['height'],'pose_bbox_height_cm':bbox[1],'hashes_unchanged':True},indent=2))

if __name__=='__main__': main()
