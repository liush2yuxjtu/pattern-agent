# Saved anatomical-state audit

`reference.json` is the usable verified handoff. `unreached-target.json` is structurally valid and geometrically consistent but its 190 cm height target is not achieved. The four other states are invalid.

| State | Classification | Actual maximum target error (cm) | Reason |
|---|---|---:|---|
| reference.json | verified | 0.004172058 | All contract, fingerprint, pose name/angle and neutral measurement checks passed; largest actual target residual 0.00417205842277 cm. |
| metre-label.json | invalid | 0.004172058 | State units must be cm; supplied m |
| nonfinite-angle.json | invalid | 0.004172058 | Nonfinite or invalid joint rotation: lowerarm01.L |
| pose-joint.json | invalid | 0.004172058 | Unknown pose bone: left_elbow_invented |
| reported-bust.json | invalid | 0.004172058 | Saved measuredNeutral disagrees with reconstructed mesh by 2 cm; maximumTargetErrorCm disagrees with actual reconstructed target residual |
| unreached-target.json | closest_supported | 9.999987571 | Valid saved coefficients and honest measurements; target not achieved: requested height 190 cm, measured 180.000012429 cm, residual 9.99998757099 cm. Usable only with this unmet target disclosed; no new solver/calibration run performed. |

All six neutral meshes were actually rebuilt from the matching asset's base vertices and signed sparse morph coefficients; all 12 dimensions were recomputed. `neutral_mesh_checked=true` denotes that numerical reconstruction was performed, including on invalid inputs; it does not imply that an invalid state passed. A separate call of candidate v2's helper agrees on valid states and rejects the invalid ones.

## Reference neutral dimensions

All values have basis `mesh_parameter`, units cm, neutral pose, and derive from the MakeHuman model rather than a photographed person. Height uses Y extent of body vertices; the other measurements sum the asset's specified tape paths or two-landmark distances. Shoulder breadth is bilateral acromion distance, not joint spacing or silhouette width.

| Key | Recomputed cm | Definition |
|---|---:|---|
| height | 180.000012429 | standing_height |
| bust | 96.004172058 | surface_tape_path |
| waist | 76.000038174 | surface_tape_path |
| hips | 102.000125098 | surface_tape_path |
| shoulders | 36.999422539 | landmark_distance |
| upperArm | 27.000032246 | surface_tape_path |
| thigh | 54.000107668 | surface_tape_path |
| neck | 32.000029190 | surface_tape_path |
| upperArmLength | 29.000078690 | landmark_distance |
| forearmLength | 23.000009302 | landmark_distance |
| thighLength | 40.000093735 | landmark_distance |
| calf | 36.000006785 | surface_tape_path |

The seated posed OBJ contains 13380 vertices and 26756 faces. Its Y bounding-box height is **132.672357000 cm**, while independently rebuilt neutral standing height is **180.000012429 cm**. The OBJ bounding box cannot establish neutral standing height. OBJ coordinates were read directly in cm; no metre conversion was applied.

The source manifest's hashes match all six states and the OBJ, and the asset fingerprint is `a75b6a2d59b2fa60ea29393e380182174627ba66d0993c649c8c571a6ccecda6`. A before/after hash check found no input changes.

Camera recovery is false: these saved states and OBJ do not contain camera settings. Real-person accuracy is false: these are controlled synthetic model data. Browser import/rendering, posed skinning/correspondence, topology/intersections and a fresh bounded calibration/nearest-solution proof were not run. The closest-supported label preserves an honest supported saved shape with an unmet target; it does not assert that a new optimization proved a global optimum.

Reproduce with `python work/anatomical-skill-evals-20261117/iteration-2/eval-1-state-audit/with_skill/run-1/outputs/run_audit.py` from the repository, or run that script by absolute path from any directory. Only its output directory is written. See `TRACE.md` and `audit.json` for executed checks and complete per-case measurements.
