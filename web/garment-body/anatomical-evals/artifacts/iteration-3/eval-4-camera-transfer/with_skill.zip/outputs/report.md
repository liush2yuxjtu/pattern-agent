# Camera transfer evidence

Executed the supplied generic triangle renderer on the supplied actual seated anatomical mannequin, with its real 163-joint rig. No fitting, photographs, image generation or human accuracy claim is involved. Mesh coordinates and joints are centimetres, Y up. MakeHuman CC0 adult female model; matching asset fingerprint is recorded in provenance.json.

All source mesh, state, joints and camera files were copied byte-for-byte. The posed and neutral meshes have 13,380 vertices and 26,756 triangles, zero boundary or nonmanifold edges, finite coordinates and positive triangle areas. The complete supplied morph coefficients, shape and seated pose map remain unchanged.

The NEW supplied camera is retained exactly: orthographic 448 × 576, main center [3.5,77] cm, 2.15 px/cm; close-up center [2,112] cm, 4.3 px/cm; depth range [-55,75] cm. Pose and depth face front. No automatic reframing or camera optimization was performed. The exact supplied naming `close-up.png` is retained.

Results:

- Neutral height: 179.9999101 cm. Posed Y-span: 132.672357 cm; this is not standing height.
- Neutral measurements are recomputed from the actual neutral OBJ using the matching asset's paths and landmark indices. No off-surface fallback was needed. Largest difference from supplied state measurements: 0.00410912 cm, below 0.03 cm.
- Independent morph reconstruction matches supplied neutral coordinates within 0.00110508 cm. This reconstruction comparison is separate from transfer preservation, whose coordinate difference is exactly zero.
- All six saved renders match deterministic renderer replay with MAE 0; masks have IoU 1. These are reproducibility checks using the supplied renderer, not an independent rendering algorithm.
- Raw depth has 16,571 finite pixels, range -1.66732669 to 62.75587845 cm. Independent triangle-hit calculations at 257 deterministic foreground pixels give maximum error 0.000001902 cm, below 0.001 cm. This is a sampled independent check.
- All 163 saved projected joint coordinates agree with independent camera projection, maximum error 0 px. Visibility means inside canvas; it does not classify occlusion. The renderer draws its selected anatomical skeleton subset.

Depth is the largest signed front-axis coordinate at each integer pixel ray, in cm, with larger Z nearer. It is not distance from an unspecified camera origin. Invalid raw pixels are negative infinity; `depth-valid.png` exactly selects finite triangle hits. Grayscale uses the supplied [-55,75] range: `clip(1 + 253*(z+55)/130,1,254)`, converted to uint8; invalid pixels are zero. The generic renderer's silhouette uses rounded polygon rasterization, so `depth-mask.png` can include edge pixels without an actual integer-ray triangle hit; `depth-valid.png` is authoritative for raw depth validity.

Pose and depth images were visually inspected: front-facing joint overlay aligns with the seated mesh, and depth has a black invalid background. This checks controlled model geometry only, not real-person anatomy or physical tissue behavior.

Reproduce from repository root:

```bash
python work/anatomical-skill-evals-20261117/iteration-3/eval-4-camera-transfer/with_skill/run-1/outputs/run.py
```

Use `--root` if the repository is moved. The copied renderer, run.py, metrics.json, provenance.json and run.log record the implementation and evidence. Six images and six masks are in `renders/`, alongside `depth.npy`, `rawdepth.npy`, `depth-valid.png`, and `pose-joints.json`.
