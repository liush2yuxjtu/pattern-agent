#!/usr/bin/env python3
"""Reproduce this camera-transfer evidence; no fitting or generated imagery."""
import argparse,hashlib,json,shutil,platform
from pathlib import Path
import numpy as np
import cv2
import render_mesh

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('/workspace/work/pattern-agent'));a=p.parse_args();root=a.root;out=Path(__file__).resolve().parent
 fixture=root/'work/anatomical-skill-evals-20261117/fixtures/camera-transfer-holdout'
 asset=root/'web/human-studio/assets/human.json'
 mapping={'source-posed.obj':'final.obj','source-neutral.obj':'neutral.obj','source-state.json':'state.json','source-joints.json':'joints.json','camera.json':'camera.json'}
 for src,dst in mapping.items():shutil.copyfile(fixture/src,out/dst)
 state=json.loads((out/'state.json').read_text());camera=json.loads((out/'camera.json').read_text());joints=json.loads((out/'joints.json').read_text())
 v,f=render_mesh.render(out/'final.obj',camera,out/'renders',joints)
 n,nf=render_mesh.obj(out/'neutral.obj');data=json.loads(asset.read_text());assert sha(asset)==state['asset']
 reconstructed=np.array(data['vertices'],float).reshape(-1,3)
 for control,weight in zip(data['controls'],state['morphWeights']):
  for idx,x,y,z in control['incr' if weight>=0 else 'decr']:reconstructed[idx]+=abs(weight)*np.array([x,y,z])
 ids=np.array(data['bodyVertexIds']);neutral_reconstructed=reconstructed[ids].copy();neutral_reconstructed[:,1]-=neutral_reconstructed[:,1].min()
 surface_error=float(np.abs(neutral_reconstructed-n).max());assert surface_error<.003
 # Measure supplied neutral vertices using remapped asset paths; off-surface landmarks use independently reconstructed coordinates.
 remap={int(old):i for i,old in enumerate(ids)}
 measured={'height':float(np.ptp(n[:,1]))};methods={};fallbacks={}
 for c in data['controls'][1:]:
  points=np.array([n[remap[i]] if i in remap else reconstructed[i] for i in c['path']]);measured[c['key']]=float(np.linalg.norm(np.diff(points,axis=0),axis=1).sum());methods[c['key']]='landmark_distance' if len(c['path'])==2 else 'surface_tape_path';fallbacks[c['key']]=sum(i not in remap for i in c['path'])
 measurement_error=max(abs(measured[k]-state['measuredNeutral'][k]) for k in measured);assert measurement_error<.03
 unique,counts=np.unique(np.sort(np.concatenate([f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]]),axis=1),axis=0,return_counts=True)
 areas=np.linalg.norm(np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]]),axis=1)/2
 assert len(v)==len(n) and np.array_equal(f,nf) and np.all(counts==2) and np.isfinite(v).all() and areas.min()>0
 source_v,source_f=render_mesh.obj(fixture/'source-posed.obj');source_n,_=render_mesh.obj(fixture/'source-neutral.obj')
 checks={'posed_source_max_coordinate_difference_cm':float(np.abs(source_v-v).max()),'neutral_source_max_coordinate_difference_cm':float(np.abs(source_n-n).max()),'source_faces_preserved':bool(np.array_equal(source_f,f)),'copied_source_sha256_equal':all(sha(fixture/s)==sha(out/d) for s,d in mapping.items()),'neutral_reconstruction_max_coordinate_error_cm':surface_error,'neutral_measurement_max_difference_cm':measurement_error,'vertex_count':len(v),'triangle_count':len(f),'boundary_edges':int(np.sum(counts==1)),'nonmanifold_edges':int(np.sum(counts>2)),'minimum_posed_triangle_area_cm2':float(areas.min()),'views':{}}
 for name,c in camera['views'].items():
  m,im,d,z=render_mesh.raster(v,f,camera,name,joints);actual=cv2.imread(str(out/'renders'/f'{name}.png'));expected=d if name=='depth' else im
  if name=='depth':actual=cv2.cvtColor(actual,cv2.COLOR_BGR2GRAY)
  am=cv2.imread(str(out/'renders'/f'{name}-mask.png'),0)>0;bm=m>0
  checks['views'][name]={'render_mae':float(np.abs(actual.astype(float)-expected).mean()),'mask_iou':float((am&bm).sum()/(am|bm).sum()),'valid_triangle_depth_pixels':int(np.isfinite(z).sum())}
 # Independent orthographic triangle-hit depth calculation at reproducibly sampled covered integer pixels.
 raw=np.load(out/'renders/depth.npy');valid=cv2.imread(str(out/'renders/depth-valid.png'),0)>0
 assert np.array_equal(valid,np.isfinite(raw)) and valid.any() and np.isfinite(raw[valid]).all()
 c=camera['views']['depth'];axis=c['axis'];s=c['px_per_cm'];cx,cy=c['center_cm'];h,w=raw.shape
 horizontal=v[:,2] if axis=='side' else v[:,0]*(-1 if axis=='back' else 1);dd=v[:,0] if axis=='side' else v[:,2]*(-1 if axis=='back' else 1)
 tri=np.stack([horizontal,v[:,1],dd],axis=1)[f];A=tri[:,0,:2];B=tri[:,1,:2];C=tri[:,2,:2];det=(B[:,1]-C[:,1])*(A[:,0]-C[:,0])+(C[:,0]-B[:,0])*(A[:,1]-C[:,1]);ok=np.abs(det)>1e-12
 samples=np.argwhere(valid);samples=samples[np.linspace(0,len(samples)-1,min(257,len(samples)),dtype=int)];errors=[]
 for yy,xx in samples:
  x=(xx-w/2)/s+cx;y=(h/2-yy)/s+cy
  u=np.full(len(f),-1.);b=u.copy();u[ok]=((B[ok,1]-C[ok,1])*(x-C[ok,0])+(C[ok,0]-B[ok,0])*(y-C[ok,1]))/det[ok];b[ok]=((C[ok,1]-A[ok,1])*(x-C[ok,0])+(A[ok,0]-C[ok,0])*(y-C[ok,1]))/det[ok];q=1-u-b
  hit=ok&(u>=-1e-7)&(b>=-1e-7)&(q>=-1e-7);depth=np.max(u[hit]*tri[hit,0,2]+b[hit]*tri[hit,1,2]+q[hit]*tri[hit,2,2]);errors.append(abs(float(raw[yy,xx])-float(depth)))
 checks['depth']={'semantics':'largest signed front-axis coordinate in centimetres; orthographic ray surface hit, not camera-origin distance','background':'negative infinity; exclude using depth-valid.png','valid_pixels':int(valid.sum()),'min_cm':float(raw[valid].min()),'max_cm':float(raw[valid].max()),'independent_ray_sample_count':len(samples),'max_raw_ray_depth_difference_cm':max(errors),'valid_mask_equals_finite_raw':True}
 assert max(errors)<.001
 annotation=json.loads((out/'renders/pose-joints.json').read_text());pc=camera['views']['pose'];errors=[]
 for source,saved in zip(joints['joints'],annotation['joints']):
  xyz=source['position'];hor=xyz[2] if pc['axis']=='side' else xyz[0]*(-1 if pc['axis']=='back' else 1)
  expected=[(hor-pc['center_cm'][0])*pc['px_per_cm']+camera['width']/2,camera['height']/2-(xyz[1]-pc['center_cm'][1])*pc['px_per_cm']];errors.append(float(np.max(np.abs(np.array(saved['pixel'])-expected))))
 checks['joints']={'count':len(errors),'max_projection_error_px':max(errors),'visibility':'inside canvas only, not occlusion classification'};assert max(errors)<.001
 metrics={'units':'cm','basis':'mesh_parameter','neutral_height_cm':float(np.ptp(n[:,1])),'posed_height_cm':float(np.ptp(v[:,1])),'neutral_measurements_cm':measured,'measurement_methods':{'height':'neutral Y-axis span',**methods},'reconstructed_off_surface_landmark_counts':fallbacks,'checks':checks}
 save(out/'metrics.json',metrics)
 save(out/'provenance.json',{'source':'supplied MakeHuman CC0 anatomical mannequin; no photograph or image generation','inputs':{str(fixture/s):sha(fixture/s) for s in mapping},'asset':{'path':str(asset),'sha256':sha(asset)},'renderer_sha256':sha(out/'render_mesh.py'),'outputs':{d:sha(out/d) for d in mapping.values()},'versions':{'python':platform.python_version(),'numpy':np.__version__,'opencv':cv2.__version__},'camera_convention':'orthographic; integer pixel coordinates; X left/right Y up Z front/back; original camera file copied byte-for-byte','depth_semantics':checks['depth']['semantics']})
 print(json.dumps(metrics,indent=2))
if __name__=='__main__':main()
