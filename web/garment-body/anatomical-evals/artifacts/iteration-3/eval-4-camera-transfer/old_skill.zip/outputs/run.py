#!/usr/bin/env python3
"""Reproduce source-preserving camera-transfer evidence; all writes beside this script."""
import hashlib, json, shutil, sys
from pathlib import Path
import numpy as np
import cv2
OUT=Path(__file__).resolve().parent
ROOT=next(p for p in OUT.parents if (p/'AGENTS.md').is_file())
FIX=ROOT/'work/anatomical-skill-evals-20261117/fixtures'
SOURCE=FIX/'camera-transfer-holdout'
sys.path.insert(0,str(OUT))
# Keep an exact runnable copy of the authorized generic renderer.
shutil.copyfile(FIX/'render_mesh.py',OUT/'render_mesh.py')
from render_mesh import obj, render, raster

def save(name,data):
    (OUT/name).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

files={'source-posed.obj':'final.obj','source-neutral.obj':'neutral.obj','source-state.json':'state.json','source-joints.json':'joints.json','camera.json':'camera.json'}
for source,dest in files.items():shutil.copyfile(SOURCE/source,OUT/dest)
state=json.loads((OUT/'state.json').read_text());camera=json.loads((OUT/'camera.json').read_text());joints=json.loads((OUT/'joints.json').read_text())
v,f=obj(OUT/'final.obj');nv,nf=obj(OUT/'neutral.obj')
asset_path=ROOT/'web/human-studio/assets/human.json';assert sha(asset_path)==state['asset'];asset=json.loads(asset_path.read_text())
assert len(nv)==len(asset['bodyVertexIds'])
remap={original:compact for compact,original in enumerate(asset['bodyVertexIds'])}
paths={c['key']:[remap[i] for i in c['path']] for c in asset['controls'] if c['key']!='height'}
save('measurement-paths.json',{'basis':'mesh_parameter','units':'cm','asset_sha256':state['asset'],'indexing':'0-based exported neutral surface vertex indices','paths':paths})
measured={'height':float(np.ptp(nv[:,1]))}
for key,path in paths.items():measured[key]=float(np.linalg.norm(np.diff(nv[path],axis=0),axis=1).sum())
metrics={'neutral_height_cm':measured['height'],'posed_height_cm':float(np.ptp(v[:,1])),'neutral_measurements_cm':measured,'measurement_definition':state['measurementDefinition'],'basis':'mesh_parameter','units':'cm','axes':'X left/right, Y up, Z front/back','source':'MakeHuman CC0 existing anatomical model; no photographed person','mesh_sha256':sha(OUT/'final.obj'),'neutral_mesh_sha256':sha(OUT/'neutral.obj')}
save('metrics.json',metrics)
render(OUT/'final.obj',camera,OUT/'renders',joints)
# Validate exact preservation and mesh topology at the exported boundary.
assert np.array_equal(f,nf)
edges=np.sort(np.concatenate([f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]]),axis=1)
_,counts=np.unique(edges,axis=0,return_counts=True)
areas=np.linalg.norm(np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]]),axis=1)/2
check={'source_preservation':{dest:{'byte_identical':sha(SOURCE/src)==sha(OUT/dest),'sha256':sha(OUT/dest)} for src,dest in files.items()},'topology':{'vertices':len(v),'triangles':len(f),'boundary_edges':int((counts==1).sum()),'nonmanifold_edges':int((counts>2).sum()),'zero_area_triangles':int((areas<1e-12).sum()),'neutral_posed_face_indices_equal':True},'neutral_measurements_max_difference_from_state_cm':max(abs(measured[k]-state['measuredNeutral'][k]) for k in measured)}
# Re-evaluate every saved deterministic image and mask from actual triangles.
image_checks={}
for view in camera['views']:
    m,im,dep,z=raster(v,f,camera,view,joints)
    actual=cv2.imread(str(OUT/'renders'/f'{view}.png'),cv2.IMREAD_UNCHANGED)
    expected=dep if view=='depth' else im
    savedmask=cv2.imread(str(OUT/'renders'/f'{view}-mask.png'),0)>0
    image_checks[view]={'size':[actual.shape[1],actual.shape[0]],'deterministic_image_mae':float(np.abs(actual.astype(float)-expected).mean()),'mask_iou':float(((m>0)&savedmask).sum()/((m>0)|savedmask).sum())}
check['renders']=image_checks
# Independent triangle/ray intersection: front orthographic rays along -Z.
# Check a deterministic spread over all ray-hit pixels, plus background rays.
depth=np.load(OUT/'renders/depth.npy');valid=cv2.imread(str(OUT/'renders/depth-valid.png'),0)>0
assert np.array_equal(valid,np.isfinite(depth))
c=camera['views']['depth'];assert c['axis']=='front'
ys,xs=np.where(valid);pick=np.linspace(0,len(xs)-1,min(512,len(xs)),dtype=int)
by,bx=np.where(~valid);bp=np.linspace(0,len(bx)-1,32,dtype=int)
rays=list(zip(xs[pick],ys[pick]))+list(zip(bx[bp],by[bp]))
tri=v[f];a=tri[:,0];e1=tri[:,1]-a;e2=tri[:,2]-a;direction=np.array([0.,0.,-1.]);h=np.cross(np.broadcast_to(direction,e2.shape),e2);det=np.einsum('ij,ij->i',e1,h);good=np.abs(det)>1e-12;inv=np.zeros_like(det);inv[good]=1/det[good]
errors=[];ray_rows=[]
for x,y in rays:
    origin=np.array([(x-camera['width']/2)/c['px_per_cm']+c['center_cm'][0],(camera['height']/2-y)/c['px_per_cm']+c['center_cm'][1],float(v[:,2].max()+10)])
    s=origin-a;u=inv*np.einsum('ij,ij->i',s,h);q=np.cross(s,e1);vv=inv*(q@direction);t=inv*np.einsum('ij,ij->i',e2,q)
    hit=good&(u>=-1e-7)&(vv>=-1e-7)&(u+vv<=1+1e-7)&(t>=0)
    d=float(origin[2]-t[hit].min()) if hit.any() else None
    saved=float(depth[y,x]) if valid[y,x] else None
    assert (d is None)==(saved is None)
    if d is not None:errors.append(abs(d-saved))
    ray_rows.append({'pixel':[int(x),int(y)],'ray_depth_cm':d,'saved_depth_cm':saved})
save('independent-ray-samples.json',ray_rows)
check['depth']={'semantics':'nearest visible triangle Z coordinate (cm); front orthographic rays from +Z toward -Z; -inf background','ray_sample_count':len(rays),'finite_ray_sample_count':len(errors),'max_independent_ray_difference_cm':max(errors),'finite_pixel_count':int(valid.sum()),'valid_mask_matches_finiteness':True,'validation_scope':'544 sampled rays; not an exhaustive ray check'}
# Reproject all actual source joints independently, retaining subpixel precision.
annotation=json.loads((OUT/'renders/pose-joints.json').read_text());names={j['name']:j for j in joints['joints']};c=camera['views']['pose'];assert c['axis']=='front'
projection_error=[]
for row in annotation['joints']:
    p=names[row['name']]['position'];expected=[(p[0]-c['center_cm'][0])*c['px_per_cm']+camera['width']/2,camera['height']/2-(p[1]-c['center_cm'][1])*c['px_per_cm']]
    projection_error.append(float(np.linalg.norm(np.array(expected)-row['pixel'])))
check['joints']={'count':len(projection_error),'max_projection_error_px':max(projection_error),'visibility':'canvas inclusion only, not occlusion'}
assert all(x['byte_identical'] for x in check['source_preservation'].values())
assert check['neutral_measurements_max_difference_from_state_cm']<.03
assert max(errors)<.001 and max(projection_error)<.001
assert all(x['deterministic_image_mae']<=2 and x['mask_iou']>=.99 for x in image_checks.values())
check['verdict']='PASS for executed source, measurement, deterministic render, joint and sampled-ray checks'
save('validation.json',check)
save('provenance.json',{'source_directory':str(SOURCE),'renderer_sha256':sha(OUT/'render_mesh.py'),'asset_sha256':state['asset'],'software':{'python':sys.version.split()[0],'numpy':np.__version__,'opencv':cv2.__version__},'mode':'existing_model_evidence','image_generation_used':False,'photographed_person_accuracy_claimed':False})
print(json.dumps({'metrics':metrics,'validation':check},indent=2))
