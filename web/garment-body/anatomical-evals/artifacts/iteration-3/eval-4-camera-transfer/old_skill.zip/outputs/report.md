# Camera transfer evidence handoff

Completed using the supplied existing MakeHuman CC0 anatomical mannequin. This is controlled model evidence, not photographed-person reconstruction, image generation, a tissue simulation, or a clothing-fit result.

`final.obj` and `neutral.obj` are exact byte copies of the supplied posed and neutral source meshes. `state.json`, `joints.json`, and `camera.json` likewise preserve the exact source bytes. Coordinate difference is therefore zero. The seated joint edits and calibrated shape coefficients remain intact. Coordinates are centimetres, X left/right, Y up, Z front/back.

The supplied generic renderer produced six actual triangle renders and their masks in `renders/`: front, side, back, close-up, pose, and depth. All images are 448 × 576. Orthographic framing, per-view axis, center, scale, and depth range [-55, 75] cm come directly from camera.json. Pose and depth both use the supplied front camera. The close-up retains its supplied separate framing.

Neutral height: 179.9999101 cm. Posed bounding-box height: 132.6723570 cm. These are different quantities. The 12 neutral measurements in metrics.json were recalculated on the actual exported neutral vertices, using original mesh tape paths and named landmarks from the SHA256-matching Human Studio asset; paths are retained in measurement-paths.json. Maximum difference from the source state's measuredNeutral values is 0.004109113 cm, below 0.03 cm. Target dimensions and source state were not rewritten.

Executed validation:

- 13,380 vertices, 26,756 triangles; matching neutral/posed face indices; zero boundary edges, nonmanifold edges, or degenerate triangles.
- All five preserved source artifacts are byte-identical. Geometry source coordinate difference is 0 cm.
- Six deterministic rerender comparisons: image MAE 0, mask IoU 1. Depth grayscale MAE 0. These are reproducibility checks against the generic renderer, not an external accuracy estimate.
- Raw renders/depth.npy contains actual triangle-hit Z coordinates in cm, with -inf background. renders/depth-valid.png exactly matches finite pixels (16,571). This is signed front-camera world Z, not camera-distance or normalized grayscale. rawdepth.npy is the renderer's alias.
- Independent Möller–Trumbore ray intersections checked 512 deterministic foreground rays and 32 background rays. Maximum saved float32 depth error: 1.86946789427e-06 cm. This ray validation is sampled, not exhaustive; all samples are saved in independent-ray-samples.json.
- All 163 real source joints have independently recomputed subpixel projection error 0 px. pose-joints.json includes source world positions and rig edges; visibility means inside canvas, not absence of occlusion.
- Front render visually inspected: anatomical mesh visibly retained with the seated pose and full-body framing.

Reproduce from the repository checkout:

```bash
python work/anatomical-skill-evals-20261117/iteration-3/eval-4-camera-transfer/old_skill/run-1/outputs/run.py
```

The runnable script only writes beside itself, and reads the authorized source fixture, generic renderer, and matching Human Studio asset. Software versions and input hashes are in provenance.json. Full numerical evidence is in validation.json. No private oracle, grader, other run output, network, paid tool, commit, or subagent was used.
