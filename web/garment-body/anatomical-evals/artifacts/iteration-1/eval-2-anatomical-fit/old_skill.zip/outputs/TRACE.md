# Anatomical fitting execution trace

Scope: synthetic MakeHuman anatomical control, not a photograph or recovered person measurements. Read repository AGENTS.md, specified snapshot SKILL.md and its human-studio/tools-and-evidence references, and only prompt/files fields from the designated evaluation metadata. No graders, oracles, other run outputs or skill versions were read. No network, image generation, paid tools, commits or shared-file edits.

Inputs: supplied reference front/side PNGs and binary masks, initial state and OBJ, fixed camera, source human.json and body-engine.js. Input/output SHA-256 and sizes are in provenance.json. Source front image was visually inspected. Y up, cm, neutral pose throughout; fixed camera JSON copied verbatim.

Execution:
1. Implemented fit.py with source dense asymmetric morph reconstruction, bodyVertexIds-aware source triangle remapping, grounded full rest vertices, and OpenCV fillConvexPoly triangle unions at 384x512. An initial exploratory implementation used bulk fillPoly, detected as inappropriate overlapping triangle parity, stopped, and replaced by union rasterization before the retained search and metrics.
2. Started actual retained search from the supplied initial morphWeights. SciPy bounded Powell optimized all 12 source morph coefficients within [-1.5,1.5], using equal front/side IoU loss. Three rounds, 731 evaluations. First round reached front/side 0.991132/0.994381; next round changed the best mean by 0.0000204; final round made no change. Retained search-history.json records every improved candidate, elapsed time, coefficients and scores. Bounds retain authored source morph family; final dimensions additionally checked against all source physiological control ranges.
3. finalize.mjs loaded the actual body-engine implementation, measured optimized full rest geometry, normalized dimensions to the engine's 0.1 cm convention and ran fitDimensions with retained coefficients. Exported final.obj in original body vertex order, remapping source indices explicitly; preserved exact source triangles. Saved state.json, all 163 bone heads using actual jointPosition(data, fullRestBuffer, bone.head), and exact camera.json.
4. Ran supplied deterministic render_mesh.py once on final.obj with camera.json and joints.json. Produced six independent triangle renders and masks, skeleton projection metadata, raw signed side-X float32 depths (larger nearer), -inf background and finite valid mask. No camera fitting or image generation.
5. verify.py independently recomputed rounded triangle-union masks from initial/final OBJ; wrote metrics.json, 384x512 OpenCV overlays, and initial masks. Reconstructed saved morph geometry directly from source asset for mesh consistency; checked topology, camera, pose, dimensional bounds, depth buffers and every render mask. Software versions are in environment.json.

Commands (run from repository root):
```
OPENBLAS_NUM_THREADS=1 python <outputs>/fit.py
node <outputs>/finalize.mjs
python work/anatomical-skill-evals-20261117/fixtures/render_mesh.py --mesh <outputs>/final.obj --camera <outputs>/camera.json --joints <outputs>/joints.json --out <outputs>/renders
OPENBLAS_NUM_THREADS=1 python <outputs>/verify.py
```
Here `<outputs>` is the directory containing this trace. Actual scripts are retained alongside this file.

Results after engine normalization and OBJ export:
- Front IoU 0.9130463664 -> 0.9893591542; improvement 0.0763127878. Dice 0.9946511188; symmetric contour mean 0.133134 px, P95 1 px.
- Side IoU 0.9169400187 -> 0.9938430271; improvement 0.0769030083. Dice 0.9969120072; symmetric contour mean 0.076144 px, P95 1 px.
- 13,380 finite vertices, exact 26,756 source triangles; initial topology preserved. Saved neutral state morph reconstruction maximum coordinate difference 5e-10 cm. Largest target/tape residual 0.0000192 cm. 163 rig bone heads. poseDegrees is empty.
- All six independent OBJ projection versus rendered-mask IoUs exactly 1.0. Depth files float32 and equal; finite mask exactly equals depth-valid.png. RGB/depth files come directly from supplied renderer, without postprocessing. No second independent full shading/depth raster pass was executed; independent verification here checks masks and depth-file consistency, not an additional renderer implementation.

Visual checks: inspected final front overlay and rendered side skeleton view; source anatomy and neutral rig projection are visible. Overlay green means overlap, pink reference-only, cyan candidate-only. No segmentation modification. Final front is weakest at IoU 0.989359. Small remaining boundary errors and the slight score decrease after engine target rounding are retained, not hidden.

Limitations: two synthetic silhouettes only constrain this model family. No real-world body measurements, medical accuracy, garment fit, or physical validity is claimed. No independent physical intersection audit or browser-viewer testing was performed. The requested exact artifacts are actual geometry/renders and calibrated state; an interactive browser viewer was outside this frozen task's output contract.
