import json,sys,hashlib,importlib.util
from pathlib import Path
import numpy as np,cv2
R=Path.cwd();O=Path(__file__).resolve().parent;F=R/'work/anatomical-skill-evals-20261117/fixtures/anatomical-fit'
spec=importlib.util.spec_from_file_location('renderer',R/'work/anatomical-skill-evals-20261117/fixtures/render_mesh.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
v,f=mod.obj(O/'final.obj');iv,iff=mod.obj(F/'initial.obj');C=json.load(open(O/'camera.json'));state=json.load(open(O/'state.json'));data=json.load(open(R/'web/human-studio/assets/human.json'))
def mask(v,f,name):
 c=C['views'][name];x=v[:,2] if c['axis']=='side' else v[:,0]*(-1 if c['axis']=='back' else 1);xy=np.rint(np.column_stack(((x-c['center_cm'][0])*c['px_per_cm']+C['width']/2,C['height']/2-(v[:,1]-c['center_cm'][1])*c['px_per_cm']))).astype('int32');m=np.zeros((512,384),np.uint8)
 for t in xy[f]:cv2.fillConvexPoly(m,t,255)
 return m>127
def stats(a,b):
 intersection=(a&b).sum();union=(a|b).sum();ab=a&~cv2.erode(a.astype('uint8'),np.ones((3,3),np.uint8)).astype(bool);bb=b&~cv2.erode(b.astype('uint8'),np.ones((3,3),np.uint8)).astype(bool);da=cv2.distanceTransform((~ab).astype('uint8'),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);db=cv2.distanceTransform((~bb).astype('uint8'),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);dist=np.r_[da[bb],db[ab]]
 return {'iou':float(intersection/union),'dice':float(2*intersection/(a.sum()+b.sum())),'symmetric_contour_mean_px':float(dist.mean()),'symmetric_contour_p95_px':float(np.percentile(dist,95))}
(O/'overlays').mkdir(exist_ok=True);(O/'evidence').mkdir(exist_ok=True)
results={}
for name in ['front','side']:
 ref=cv2.imread(str(F/f'reference-{name}-mask.png'),0)>127;initial=mask(iv,iff,name);final=mask(v,f,name);im=np.full((512,384,3),242,np.uint8);im[ref&final]=[70,200,70];im[ref&~final]=[190,70,220];im[final&~ref]=[230,210,40];cv2.imwrite(str(O/'overlays'/f'{name}.png'),im);cv2.imwrite(str(O/'evidence'/f'initial-{name}-mask.png'),initial.astype('uint8')*255);results[name]={'initial':stats(ref,initial),'final':stats(ref,final)};results[name]['iou_improvement']=results[name]['final']['iou']-results[name]['initial']['iou']
raw=np.load(O/'renders/rawdepth.npy');dep=np.load(O/'renders/depth.npy');valid=cv2.imread(str(O/'renders/depth-valid.png'),0)>127
source_ids=np.asarray(data['bodyVertexIds']);inv=np.full(len(data['vertices'])//3,-1);inv[source_ids]=np.arange(len(source_ids));sf=inv[np.asarray(data['indices']).reshape(-1,3)]
rest=np.asarray(data['vertices']).reshape(-1,3)
for w,c in zip(state['morphWeights'],data['controls']):
 rows=np.asarray(c['incr'] if w>=0 else c['decr']);rest[rows[:,0].astype(int)]+=abs(w)*rows[:,1:]
rest[:,1]-=rest[source_ids,1].min()
mesh_error=float(np.max(np.abs(rest[source_ids]-v)))
measure_error=max(abs(state['dimensions'][k]-state['measuredNeutral'][k]) for k in state['dimensions'])
checks={'finite_vertices':bool(np.isfinite(v).all()),'vertex_count':len(v),'triangle_count':len(f),'source_topology_exact':bool(np.array_equal(f,sf)),'initial_topology_preserved':bool(np.array_equal(f,iff)),'camera_exact':json.load(open(F/'camera.json'))==C,'state_morph_mesh_max_coordinate_error_cm':mesh_error,'neutral_measurement_max_target_error_cm':measure_error,'all_dimensions_within_control_bounds':all(c['min']<=state['dimensions'][c['key']]<=c['max'] for c in data['controls']),'pose_neutral':state['poseDegrees']=={},'joint_count':len(json.load(open(O/'joints.json'))['joints']),'depth_dtype':str(raw.dtype),'depth_files_equal':bool(np.array_equal(raw,dep)),'depth_valid_exact':bool(np.array_equal(np.isfinite(raw),valid))}
for name in C['views']:
 m=cv2.imread(str(O/'renders'/f'{name}-mask.png'),0)>127;checks[f'{name}_mask_iou_against_obj_projection']=stats(mask(v,f,name),m)['iou']
metrics={'mode':'synthetic anatomical control','protocol':{'projection':'fixed orthographic; fixture camera unchanged','resolution':[384,512],'units':'cm, Y up','silhouette':'OpenCV union of rounded projected source triangles','contours':'all boundaries, symmetric nearest-boundary Euclidean pixel distance','optimization':'SciPy Powell, 12 source morph coefficients, bounded [-1.5,1.5], 3 rounds; final source engine recalibration to 0.1 cm target dimensions','limitations':['Synthetic source-model control; no recovered person measurements.','No external real-world validation.','Morph shape fixed to source family and neutral pose.'],'overlay_BGR':{'overlap':[70,200,70],'reference_only':[190,70,220],'candidate_only':[230,210,40]}},'views':results,'checks':checks,'search':json.load(open(O/'search-result.json'))}
(O/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
files=[F/'reference-front.png',F/'reference-side.png',F/'reference-front-mask.png',F/'reference-side-mask.png',F/'initial.obj',F/'initial-state.json',F/'camera.json',R/'web/human-studio/assets/human.json',R/'web/human-studio/body-engine.js',O/'final.obj',O/'state.json']
(O/'provenance.json').write_text(json.dumps({str(p.relative_to(R)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files},indent=2))
print(json.dumps({'views':results,'checks':checks},indent=2))
