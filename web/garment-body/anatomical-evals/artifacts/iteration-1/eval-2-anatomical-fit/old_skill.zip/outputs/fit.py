import json,sys,time,hashlib,shutil
from pathlib import Path
import numpy as np,cv2
from scipy.optimize import minimize
ROOT=Path.cwd(); O=Path(__file__).resolve().parent; F=ROOT/'work/anatomical-skill-evals-20261117/fixtures/anatomical-fit'; D=json.load(open(ROOT/'web/human-studio/assets/human.json')); C=json.load(open(F/'camera.json')); S=json.load(open(F/'initial-state.json'))
v0=np.asarray(D['vertices']).reshape(-1,3); ids=np.asarray(D['bodyVertexIds']); inv=np.full(len(v0),-1);inv[ids]=np.arange(len(ids));faces=inv[np.asarray(D['indices']).reshape(-1,3)]; assert faces.min()>=0
plus=np.zeros((12,*v0.shape)); minus=plus.copy()
for i,c in enumerate(D['controls']):
 for rows,m in [(c['incr'],plus),(c['decr'],minus)]:
  r=np.asarray(rows);m[i,r[:,0].astype(int)]=r[:,1:]
def build(w):
 v=v0+np.sum(plus*np.maximum(w,0)[:,None,None]+minus*np.maximum(-w,0)[:,None,None],axis=0);v[:,1]-=v[ids,1].min();return v
refs=[cv2.imread(str(F/f'reference-{x}-mask.png'),0)>127 for x in ['front','side']]
def masks(v):
 out=[]
 for name in ['front','side']:
  c=C['views'][name];x=v[:,2] if name=='side' else v[:,0]; p=np.column_stack(((x-c['center_cm'][0])*c['px_per_cm']+C['width']/2,C['height']/2-(v[:,1]-c['center_cm'][1])*c['px_per_cm']));p=np.rint(p).astype(np.int32);m=np.zeros((512,384),np.uint8);
  for tri in p[faces]:cv2.fillConvexPoly(m,tri,1)
  out.append(m.astype(bool))
 return out
def ious(ms):return [float((m&r).sum()/(m|r).sum()) for m,r in zip(ms,refs)]
history=[];best=[1e9,None];start=time.time()
def objective(w):
 v=build(w); scores=ious(masks(v[ids]));loss=2-sum(scores)
 # Physiological control bounds are enforced separately by dimension measurement.
 if loss<best[0]:
  best[:]=[loss,w.copy()]; history.append({'evaluation':counter[0],'elapsed_seconds':time.time()-start,'loss':loss,'iou':scores,'weights':w.tolist()})
 counter[0]+=1
 return loss
counter=[0];initial=ious(masks(build(np.array(S['morphWeights']))[ids]));print('initial',initial,flush=True)
w=np.array(S['morphWeights']);
for round in range(3):
 r=minimize(objective,w,method='Powell',bounds=[(-1.5,1.5)]*12,options={'maxiter':7,'xtol':.003,'ftol':.00004});w=best[1].copy();print('round',round,'evals',counter[0],'best',1-best[0]/2,'scores',history[-1]['iou'],flush=True)
 np.save(O/'best-weights.npy',w);(O/'search-history.json').write_text(json.dumps(history,indent=2))
v=build(w);measures={}
for c in D['controls']:
 p=v[np.array(c['path'])] if c.get('path') else None
 measures[c['key']]=float(np.ptp(v[ids,1]) if c['key']=='height' else np.linalg.norm(np.diff(p,axis=0),axis=1).sum())
(O/'search-result.json').write_text(json.dumps({'initial_iou':initial,'weights':w.tolist(),'measurements':measures,'evaluations':counter[0]},indent=2))
