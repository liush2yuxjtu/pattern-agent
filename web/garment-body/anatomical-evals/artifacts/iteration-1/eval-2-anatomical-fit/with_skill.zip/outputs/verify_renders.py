from validate import *
metrics=json.load(open(OUT/'metrics.json'));checks={}
for view,c in cam['views'].items():
 horizontal=final[:,2] if c['axis']=='side' else final[:,0]*(-1 if c['axis']=='back' else 1)
 xy=np.column_stack(((horizontal-c['center_cm'][0])*c['px_per_cm']+cam['width']/2,cam['height']/2-(final[:,1]-c['center_cm'][1])*c['px_per_cm']))
 p=np.rint(xy).astype(np.int32);mask=np.zeros((cam['height'],cam['width']),np.uint8)
 for tri in p[ff]:cv2.fillConvexPoly(mask,tri,255)
 actual=cv2.imread(str(OUT/f'renders/{view}-mask.png'),0);im=cv2.imread(str(OUT/f'renders/{view}.png'),cv2.IMREAD_UNCHANGED)
 checks[view]={'mask_iou_independent_obj_projection':float(((mask>0)&(actual>0)).sum()/((mask>0)|(actual>0)).sum()),'shape':list(im.shape),'triangle_render_nonempty':bool(np.ptp(im)>0)}
# Independent nearest-triangle barycentric computation at a deterministic sample of pixels.
c=cam['views']['depth'];xy=np.column_stack(((final[:,2]-c['center_cm'][0])*c['px_per_cm']+192,256-(final[:,1]-c['center_cm'][1])*c['px_per_cm']));tri=xy[ff];a,b,cc=tri[:,0],tri[:,1],tri[:,2];den=(b[:,1]-cc[:,1])*(a[:,0]-cc[:,0])+(cc[:,0]-b[:,0])*(a[:,1]-cc[:,1]);safe=np.where(abs(den)<1e-10,np.nan,den);depth=final[ff,0];z=np.load(OUT/'renders/rawdepth.npy');rng=np.random.default_rng(20261117);fg=np.argwhere(np.isfinite(z));bg=np.argwhere(~np.isfinite(z));points=np.concatenate([fg[rng.choice(len(fg),512,replace=False)],bg[rng.choice(len(bg),128,replace=False)]]);errors=[];bgok=True
for y,x in points:
 u=((b[:,1]-cc[:,1])*(x-cc[:,0])+(cc[:,0]-b[:,0])*(y-cc[:,1]))/safe;v=((cc[:,1]-a[:,1])*(x-cc[:,0])+(a[:,0]-cc[:,0])*(y-cc[:,1]))/safe;w=1-u-v;hit=(u>=-1e-7)&(v>=-1e-7)&(w>=-1e-7);d=(u*depth[:,0]+v*depth[:,1]+w*depth[:,2])[hit];expected=np.max(d) if len(d) else -np.inf
 if np.isfinite(z[y,x]):errors.append(float(abs(expected-z[y,x])))
 else:bgok &= bool(np.isneginf(expected))
metrics['render_checks']=checks;metrics['depth']['independent_sample_count']=len(points);metrics['depth']['independent_sample_maximum_error_cm']=max(errors);metrics['depth']['independent_sample_background_correct']=bgok
j=json.load(open(OUT/'joints.json'));pj=json.load(open(OUT/'renders/pose-joints.json'));metrics['skeleton']={'bone_count':len(j['joints']),'projected_joint_count':len(pj['joints']),'edge_count':len(pj['edges']),'actual_rig_names_match':set(x['name'] for x in j['joints'])==set(b['name'] for b in data['bones']),'source':'body-engine jointPosition(data, final full rest buffer, bone.head)','pose':'fixture neutral source pose'}
metrics['optimization']['last_best_evaluation']=metrics['optimization'].pop('evaluations');(OUT/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n');print(json.dumps({'render_checks':checks,'depth':metrics['depth'],'skeleton':metrics['skeleton']},indent=2))
