from fit import *
import hashlib,importlib.util

def load_obj(p):
 vs=[];fs=[]
 for l in p.read_text().splitlines():
  t=l.split()
  if t and t[0]=='v':vs.append(list(map(float,t[1:4])))
  if t and t[0]=='f':fs.append([int(x)-1 for x in t[1:]])
 return np.array(vs),np.array(fs)
def metric(r,m):
 a=r.sum();b=m.sum();i=(r&m).sum();u=(r|m).sum()
 rb=r&~cv2.erode(r.astype('uint8'),np.ones((3,3),np.uint8)).astype(bool);mb=m&~cv2.erode(m.astype('uint8'),np.ones((3,3),np.uint8)).astype(bool)
 dr=cv2.distanceTransform((~rb).astype('uint8'),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);dm=cv2.distanceTransform((~mb).astype('uint8'),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);d=np.r_[dr[mb],dm[rb]]
 return {'iou':float(i/u),'dice':float(2*i/(a+b)),'symmetric_contour_mean_px':float(d.mean()),'symmetric_contour_p95_px':float(np.percentile(d,95)),'reference_area_px':int(a),'candidate_area_px':int(b)}
def overlay(r,m):
 img=np.full((*r.shape,3),242,np.uint8);img[r&m]=[60,190,60];img[r&~m]=[180,50,230];img[m&~r]=[230,210,30];return img
final,ff=load_obj(OUT/'final.obj');iv,ifaces=load_obj(OUT/'initial.obj')
state=json.load(open(OUT/'state.json'));reconstructed=vertices(np.array(state['morphWeights']));mf=masks(reconstructed);mi=masks(vertices(np.array(initial['morphWeights'])))
# Independently measure exported surface using source-id remapping, not saved measuredNeutral.
measured={}
for c in data['controls']:
 if c['key']=='height':val=np.ptp(final[:,1])
 else:val=np.linalg.norm(np.diff(final[inv[np.array(c['path'])]],axis=0),axis=1).sum()
 measured[c['key']]=float(val)
metrics={'mode':'synthetic_anatomical_control','units':'cm','camera_frozen':json.load(open(OUT/'camera.json'))==cam,'optimization':{'method':'scipy.optimize.minimize Powell; actual anatomical morph weights, bounds [-1.9,1.9], 3 rounds, same cameras and 384x512 binary union triangles','objective':'sum of front and side silhouette IoU','evaluations':json.load(open(OUT/'history.json'))[-1]['n'],'parameter_rounding':'final engine fit targets rounded to 0.1 cm; final metrics recomputed after canonicalization'},'views':{},'mesh':{'vertex_count':len(final),'triangle_count':len(ff),'finite_vertices':bool(np.isfinite(final).all()),'exact_source_triangles':bool(np.array_equal(ff,faces)),'initial_obj_exact_source_triangles':bool(np.array_equal(ifaces,faces)),'maximum_export_reconstruction_error_cm':float(abs(final-reconstructed[ids]).max()),'maximum_initial_obj_reconstruction_error_cm':float(abs(iv-vertices(np.array(initial['morphWeights']))[ids]).max())},'independent_exported_obj_measurements_cm':measured,'maximum_dimension_error_cm':max(abs(measured[k]-state['dimensions'][k]) for k in measured),'limits':['Synthetic reference consistency only; no recovered person measurements.','Model uses fixed MakeHuman female anatomy and source neutral pose.','No cloth fit, tissue simulation or real-person accuracy certification.'],'hashes':{}}
(OUT/'overlays').mkdir(exist_ok=True);(OUT/'evidence').mkdir(exist_ok=True)
for j,name in enumerate(['front','side']):
 fm=cv2.imread(str(OUT/f'renders/{name}-mask.png'),0)>127
 assert np.array_equal(fm,mf[j]),name+' final mask does not match independent projection'
 metrics['views'][name]={'initial':metric(refs[j],mi[j]),'final':metric(refs[j],fm)}
 metrics['views'][name]['iou_improvement']=metrics['views'][name]['final']['iou']-metrics['views'][name]['initial']['iou']
 cv2.imwrite(str(OUT/f'overlays/{name}.png'),overlay(refs[j],fm));cv2.imwrite(str(OUT/f'evidence/initial-{name}-mask.png'),mi[j].astype('uint8')*255);cv2.imwrite(str(OUT/f'evidence/final-{name}-mask.png'),fm.astype('uint8')*255);cv2.imwrite(str(OUT/f'evidence/initial-{name}-overlay.png'),overlay(refs[j],mi[j]))
# Read raw arrays and encoded output independently to verify depth semantics and common geometry.
z=np.load(OUT/'renders/rawdepth.npy');zz=np.load(OUT/'renders/depth.npy');valid=cv2.imread(str(OUT/'renders/depth-valid.png'),0)>127;dep=cv2.imread(str(OUT/'renders/depth.png'),0);lo,hi=cam['depth_range_cm'];expected=np.zeros(z.shape,np.uint8);expected[np.isfinite(z)]=np.clip(1+253*(z[np.isfinite(z)]-lo)/(hi-lo),1,254).astype('uint8')
metrics['depth']={'raw_dtype':str(z.dtype),'array_shape':list(z.shape),'valid_mask_matches_finite':bool(np.array_equal(valid,np.isfinite(z))),'background_negative_infinity':bool(np.isneginf(z[~valid]).all()),'raw_arrays_equal':bool(np.array_equal(z,zz)),'encoded_mean_absolute_error_px':float(np.abs(dep.astype(float)-expected).mean()),'depth_semantics':'signed source X, centimetres; larger is nearer (side orthographic camera)','finite_pixels':int(valid.sum())}
for p in [FIX/'reference-front.png',FIX/'reference-side.png',FIX/'reference-front-mask.png',FIX/'reference-side-mask.png',FIX/'camera.json',ROOT/'web/human-studio/assets/human.json',ROOT/'web/human-studio/body-engine.js',OUT/'final.obj',OUT/'state.json',OUT/'joints.json']:
 metrics['hashes'][str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
(OUT/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n');print(json.dumps({'views':metrics['views'],'mesh':metrics['mesh'],'maximum_dimension_error_cm':metrics['maximum_dimension_error_cm'],'depth':metrics['depth']},indent=2))
