# Actual anatomical fit execution

Working directory: `/workspace/work/pattern-agent`.
Mode: synthetic anatomical control; fixed orthographic cameras; Y-up centimetres; source neutral pose.
Read only evaluation metadata prompt/files fields, fixture inputs, public renderer, requested skill and relevant references, AGENTS.md, engine and anatomical asset. No grader, oracle, other run outputs, external network, image generation, paid tools, subagents or commits used. All newly written support code is here. Shared source/fixtures/skill were not modified.

## Executed workflow

1. Inspected reference front and side images. Used supplied binary masks unchanged.
2. `OPENBLAS_NUM_THREADS=1 python <outputs>/fit.py` executed 3 bounded Powell rounds, optimizing 12 actual MakeHuman morph weights with bounds [-1.9, 1.9]. Each objective rebuilt full rest vertices, grounded to source floor, preserved source body vertex mapping, and rasterized the actual 26756 triangles with OpenCV at the supplied 384x512 fixed camera settings. Objective was summed front and side IoU. Improvement history is `history.json`. The last best objective was encountered at evaluation 789; this is not the total evaluation count.
3. Converted `optimized_weights.npy` to `weights.json`; `node <outputs>/export.mjs` used the actual body-engine `measureRest`, `fitDimensions`, `buildRestVertices` and `jointPosition`. The optimized shape's tape measurements were rounded to supported 0.1 cm targets, then canonically fit from engine default weights. Final OBJ and final metrics use that canonical fitted shape. The slight reduction in front IoU after rounding is retained honestly.
4. Copied fixture camera.json, initial.obj and initial-state.json here unchanged.
5. Executed provided deterministic rasterizer once after optimization:
   `python work/anatomical-skill-evals-20261117/fixtures/render_mesh.py --mesh <outputs>/final.obj --camera <outputs>/camera.json --out <outputs>/renders --joints <outputs>/joints.json`.
6. `OPENBLAS_NUM_THREADS=1 python <outputs>/validate.py` read the final OBJ and recomputed neutral tape/landmark values, source triangles, source-order positions, fixed-camera initial/final masks, OpenCV overlays, IoU/Dice/contour distances and depth encoding checks.
7. `python work/anatomical-skill-evals-20261117/skill-candidate-v1/scripts/inspect_human_state.py --state <outputs>/state.json --asset-json web/human-studio/assets/human.json --require-match --out <outputs>/independent-state-check.json` returned PASS with independent neutral reconstruction and measurement.
8. `OPENBLAS_NUM_THREADS=1 python <outputs>/verify_renders.py` independently projected all six final OBJ masks; each IoU 1.0. It independently checked nearest triangle depth at 640 deterministic sample pixels, including 128 background points. It imports validation, so also rechecks the final silhouette metrics. Final metrics.json contains the complete combined measurements.
9. Viewed final front/side overlays and the actual side pose/skeleton render.

## Actual results

Front IoU: 0.9130463664 -> **0.9904501112**, improvement 0.0774037448.
Side IoU: 0.9169400187 -> **0.9951531833**, improvement 0.0782131646.
Mean symmetric contour distance: front 1.27842 -> 0.11868 px; side 1.13093 -> 0.06329 px. Final P95 is 1 pixel for each.

Topology: 13380 finite body vertices, 26756 exact source triangles with explicit source-to-compact mapping. Maximum OBJ reconstruction difference is 5.0e-10 cm. Maximum independently measured final tape/landmark target residual is 0.000113188 cm.

Final source-space bone heads: all 163 actual rig bones, derived from full rest buffer using each bone's head landmark; 162 parent edges. Pose is empty/neutral. Pose view uses the fixture's side camera.

Depth: float32 arrays, -inf background, 16034 finite pixels; finite mask exact; encoded uint8 mean absolute error 0.0. Independent 640-point nearest-triangle check maximum error 1.9063e-6 cm. Side depth is signed source X (larger nearer), never a camera-distance relabeling. The float32 raw arrays retain actual geometry; display encoding maps fixed [-90,90] cm to 1..254 with background 0.

## Limits

This is synthetic reference consistency, not recovered person measurements. No physical garment fit or tissue simulation is claimed. All six renders were produced by the required fixed triangle lighting rasterizer; image appearance was not independently re-rendered for an exhaustive per-pixel lighting audit. The independent depth check samples 640 pixels rather than exhaustively recomputing every triangle/pixel. Full depth arrays and renderer are retained for exhaustive reproduction.

The weakest silhouette is front at 0.9904501. Fixed cameras were never optimized. `state.json`, `final.obj`, `joints.json`, renders, overlays and final metrics correspond to the same canonical state. `optimized_weights.npy` and weights.json are pre-canonicalization optimization intermediates and are identified separately.
