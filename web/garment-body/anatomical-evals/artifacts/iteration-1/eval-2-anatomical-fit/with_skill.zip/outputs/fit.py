import numpy as np,cv2,json,time,sys
from pathlib import Path
from scipy.optimize import minimize
ROOT=Path('/workspace/work/pattern-agent'); OUT=Path(__file__).parent; FIX=ROOT/'work/anatomical-skill-evals-20261117/fixtures/anatomical-fit'
data=json.load(open(ROOT/'web/human-studio/assets/human.json'));initial=json.load(open(FIX/'initial-state.json'));cam=json.load(open(FIX/'camera.json'))
base=np.array(data['vertices']).reshape(-1,3);ids=np.array(data['bodyVertexIds']);inv=np.full(len(base),-1);inv[ids]=np.arange(len(ids));faces=inv[np.array(data['indices']).reshape(-1,3)]
mods=[]
for c in data['controls']:
 pair=[]
 for key in ['incr','decr']:
  a=np.zeros_like(base);r=np.array(c[key]);a[r[:,0].astype(int)]=r[:,1:];pair.append(a)
 mods.append(pair)
mods=np.array(mods)
refs=[cv2.imread(str(FIX/f'reference-{v}-mask.png'),0)>127 for v in ['front','side']]
def vertices(w):
 a=base+np.einsum('i,ijk->jk',np.maximum(w,0),mods[:,0])+np.einsum('i,ijk->jk',np.maximum(-w,0),mods[:,1]);a[:,1]-=a[ids,1].min();return a

def masks(a):
 result=[]
 for axis in [0,2]:
  p=np.rint(np.column_stack((a[ids,axis]*2.4+192,256-(a[ids,1]-92)*2.4))).astype(np.int32);m=np.zeros((512,384),np.uint8)
  for tri in p[faces]:cv2.fillConvexPoly(m,tri,1)
  result.append(m.astype(bool))
 return result

def ious(ms):return [float((r&m).sum()/(r|m).sum()) for r,m in zip(refs,ms)]
w=np.array(initial['morphWeights']);t=time.time();print('baseline',ious(masks(vertices(w))),'time',time.time()-t,flush=True)
count=0;best=1;hist=[]
def objective(w):
 global count,best
 score=ious(masks(vertices(w)));loss=2-sum(score);count+=1
 if loss<best:
  best=loss;np.save(OUT/'best_weights.npy',w);hist.append({'n':count,'weights':w.tolist(),'iou':score,'loss':loss});(OUT/'history.json').write_text(json.dumps(hist,indent=2))
  if count%10==0 or loss<.025:print(count,score,flush=True)
 return loss
if __name__=='__main__':
 for cycle in range(3):
  res=minimize(objective,w,method='Powell',bounds=[(-1.9,1.9)]*12,options={'maxiter':12,'xtol':.002,'ftol':.00001});w=np.load(OUT/'best_weights.npy');print('cycle',cycle,ious(masks(vertices(w))),flush=True)
 np.save(OUT/'optimized_weights.npy',w)
