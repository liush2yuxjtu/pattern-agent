#!/usr/bin/env python3
"""Read-only fixture audit. Run from repository root: python PATH/run_audit.py."""
import argparse, csv, hashlib, importlib.util, json, math, pathlib, platform
import sys
sys.dont_write_bytecode = True
import numpy as np

NAMES = ['reference.json', 'metre-label.json', 'reported-bust.json', 'nonfinite-angle.json', 'pose-joint.json', 'unreached-target.json']
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p, value): p.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')
def finite(v): return type(v) in (int,float) and math.isfinite(v)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=pathlib.Path,default=pathlib.Path.cwd())
    ap.add_argument('--out',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent)
    args=ap.parse_args(); root=args.root.resolve(); out=args.out.resolve(); out.mkdir(parents=True,exist_ok=True)
    fixture=root/'work/anatomical-skill-evals-20261117/fixtures/state-audit'
    skill=root/'work/anatomical-skill-evals-20261117/skill-snapshot-v0'
    asset_path=root/'web/human-studio/assets/human.json'; asset_bytes=asset_path.read_bytes(); asset=json.loads(asset_bytes)
    manifest=json.loads((fixture/'source.json').read_text())
    assert asset['schema']==1 and asset['unit']=='cm'
    assert sha(asset_path)==manifest['asset_sha256']
    keys=[c['key'] for c in asset['controls']]; bones={b['name'] for b in asset['bones']}
    spec=importlib.util.spec_from_file_location('skill_inspector',skill/'scripts/inspect_human_state.py')
    helper=importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    cases=[]; details={}; helpers={}; hashes={name:sha(fixture/name) for name in NAMES+['posed-cm.obj']}
    assert all(hashes[name]==manifest['files'][name] for name in hashes), 'Source manifest mismatch'
    measurements=None
    for name in NAMES:
        state=json.loads((fixture/name).read_text()); errors=[]
        # Independently reconstruct from source asset and coefficients; no saved measurement is used here.
        vertices=np.asarray(asset['vertices'],dtype=np.float64).reshape(-1,3).copy()
        weights=state['morphWeights']; assert len(weights)==len(keys)
        for c,w in zip(asset['controls'],weights):
            assert finite(w) and -2<=w<=2
            delta=np.asarray(c['incr' if w>=0 else 'decr'],dtype=np.float64)
            np.add.at(vertices,delta[:,0].astype(np.int64),abs(w)*delta[:,1:])
        assert np.isfinite(vertices).all()
        surface=vertices[np.asarray(asset['bodyVertexIds'],dtype=np.int64)]
        measured={'height':float(np.ptp(surface[:,1]))}
        for c in asset['controls'][1:]:
            path=vertices[np.asarray(c['path'],dtype=np.int64)]
            measured[c['key']]=float(np.linalg.norm(np.diff(path,axis=0),axis=1).sum())
        residual=max(abs(measured[k]-state['dimensions'][k]) for k in keys)
        discrepancy=max(abs(measured[k]-state['measuredNeutral'][k]) for k in keys)
        # Preserve complete skill structural validation and its observed failures.
        try: helpers[name]=helper.audit(state,asset_bytes,manifest['asset_sha256'])
        except (ValueError,KeyError,TypeError,IndexError) as exc:
            helpers[name]={'verdict':'FAIL','error':str(exc)}; errors.append(str(exc))
        if state['units']!='cm': errors.append('Unit label is '+state['units']+'; asset coordinates and measurements are cm')
        if state['version']!='makehuman-cm-rig-v1': errors.append('Incompatible version')
        if state['asset']!=sha(asset_path): errors.append('Asset fingerprint mismatch')
        for joint,angles in state['poseDegrees'].items():
            if joint not in bones: errors.append('Unknown edited joint: '+joint)
            if len(angles)!=3 or not all(finite(v) and -180<=v<=180 and abs(v*10-round(v*10))<1e-7 for v in angles):
                errors.append('Nonfinite, out-of-range or off-step angle in '+joint)
        if discrepancy>=.002: errors.append(f'Saved measuredNeutral differs from reconstructed mesh by {discrepancy:.9f} cm')
        classification='invalid' if errors else ('closest_supported' if residual>.2 else 'verified')
        reason='; '.join(dict.fromkeys(errors)) if errors else (
            f'Valid saved mesh; target residual {residual:.9f} cm exceeds 0.2 cm. Height target is 190 cm, achieved neutral height is {measured["height"]:.9f} cm.' if residual>.2 else
            f'Compatible asset, valid known joint edits, and independently recomputed measurements agree; target residual {residual:.9f} cm is within 0.2 cm.')
        cases.append(dict(file=name,classification=classification,reason=reason,neutral_mesh_checked=True,maximum_target_error_cm=residual))
        details[name]={'neutral_measurements_cm':measured,'maximum_saved_measurement_difference_cm':discrepancy,'neutral_reconstruction_executed':True,'finite_neutral_vertices':True,'edited_joint_count':len(state['poseDegrees'])}
        if name=='reference.json': measurements=measured
    obj=[]
    for line in (fixture/'posed-cm.obj').read_text().splitlines():
        if line.startswith('v '): obj.append([float(x) for x in line.split()[1:4]])
    obj=np.asarray(obj); assert obj.ndim==2 and obj.shape[1]==3 and np.isfinite(obj).all()
    bbox=float(np.ptp(obj[:,1]))
    audit={'cases':cases,'measurements':measurements,'basis':'mesh_parameter','pose_bbox_height_cm':bbox,'camera_recovered':False,'real_person_accuracy_established':False,'input_hashes':hashes}
    dump(out/'audit.json',audit)
    with (out/'measurements.csv').open('w',newline='') as f:
        writer=csv.writer(f); writer.writerow(['key','value','unit','basis'])
        for k in keys: writer.writerow([k,measurements[k],'cm','mesh_parameter'])
    dump(out/'checks.json',{'asset_sha256':sha(asset_path),'source_manifest_sha256':sha(fixture/'source.json'),'source_manifest_hashes_match':True,'skill_helper_checks':helpers,'independent_numpy_checks':details,'posed_obj_vertices':len(obj),'posed_obj_bounds_cm':{'min':obj.min(axis=0).tolist(),'max':obj.max(axis=0).tolist()},'python':platform.python_version(),'numpy':np.__version__})
    lines=['# Saved anatomical handoff audit','','The usable reference is `reference.json`: independently reconstructed neutral geometry agrees with its saved measurements. These controlled MakeHuman model data establish no real-person accuracy.','', '| State | Classification | Maximum actual target residual (cm) |','|---|---|---:|']
    lines += [f'| {c["file"]} | {c["classification"]} | {c["maximum_target_error_cm"]:.9f} |' for c in cases]
    lines += ['',*[f'- `{c["file"]}`: {c["reason"]}' for c in cases], '',
        'All six neutral meshes were independently reconstructed in NumPy from the matching asset and each state’s morph coefficients, including states rejected by the bundled structural validator. `neutral_mesh_checked: true` records this executed calculation; it does not make an invalid state usable. Full calculations and actual validator failures are retained in `checks.json`.', '',
        'The unreached-target state is structurally valid and preserves a supported mesh, but does not achieve 190 cm. It is usable only as an explicitly disclosed closest-supported saved result, not as an achieved 190 cm handoff. No optimization or proof of global optimality was performed.', '',
        f'The posed OBJ has {len(obj):,} finite vertices; its Y-up bounding-box height is {bbox:.9f} cm, versus neutral standing height {measurements["height"]:.9f} cm. Pose changes the bounding box. The OBJ is already cm; no unit conversion was applied.', '',
        'Measurement definitions: height is the Y range of neutral bodyVertexIds; bust, waist, hips, upperArm, thigh, neck and calf are sums along asset surface tape paths; shoulders, upperArmLength, forearmLength and thighLength are named two-landmark distances. They are not plane-section circumferences or joint spacing. Values are in measurements.csv and audit.json; all have basis mesh_parameter.', '',
        'Provenance: all six state hashes and the OBJ hash match source.json; the asset SHA-256 matches the states and manifest. Inputs were preserved. The numerical tolerance is 0.002 cm for reconstruction agreement and 0.2 cm for achieved-target classification, not a human measurement accuracy guarantee.', '',
        'Unavailable/not run: camera recovery (not in the state/OBJ contract), browser roundtrip and slider behavior, image/render validation, independent posed skinning correspondence, GLB/export validation, physical tissue or garment simulation, photographic/person measurement validation. No network, generation, spending or input modification was used.']
    (out/'report.md').write_text('\n'.join(lines)+'\n')
    # Output self-check covers the requested schema and CSV payload without trusting exit status alone.
    reread=json.loads((out/'audit.json').read_text())
    assert len(reread['cases'])==6 and set(reread['measurements'])==set(keys)
    assert [c['classification'] for c in cases]==['verified','invalid','invalid','invalid','invalid','closest_supported']
    assert set(reread['input_hashes'])==set(NAMES+['posed-cm.obj'])
    assert all(sha(fixture/name)==hashes[name] for name in hashes)
    with (out/'measurements.csv').open() as f: assert len(list(csv.DictReader(f)))==12
    print(json.dumps({'classifications':{c['file']:c['classification'] for c in cases},'reference_maximum_target_error_cm':cases[0]['maximum_target_error_cm'],'pose_bbox_height_cm':bbox,'output_schema_and_input_preservation':'PASS'},indent=2))
if __name__=='__main__': main()
