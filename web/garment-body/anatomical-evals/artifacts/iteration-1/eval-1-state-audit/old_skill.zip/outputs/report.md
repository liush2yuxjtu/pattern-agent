# Saved anatomical handoff audit

The usable reference is `reference.json`: independently reconstructed neutral geometry agrees with its saved measurements. These controlled MakeHuman model data establish no real-person accuracy.

| State | Classification | Maximum actual target residual (cm) |
|---|---|---:|
| reference.json | verified | 0.004172058 |
| metre-label.json | invalid | 0.004172058 |
| reported-bust.json | invalid | 0.004172058 |
| nonfinite-angle.json | invalid | 0.004172058 |
| pose-joint.json | invalid | 0.004172058 |
| unreached-target.json | closest_supported | 9.999987571 |

- `reference.json`: Compatible asset, valid known joint edits, and independently recomputed measurements agree; target residual 0.004172058 cm is within 0.2 cm.
- `metre-label.json`: State units must be cm; Unit label is m; asset coordinates and measurements are cm
- `reported-bust.json`: Saved measuredNeutral disagrees with reconstructed mesh; Saved measuredNeutral differs from reconstructed mesh by 2.000000000 cm
- `nonfinite-angle.json`: Invalid joint rotation; Nonfinite, out-of-range or off-step angle in lowerarm01.L
- `pose-joint.json`: Unknown pose bone; Unknown edited joint: left_elbow_invented
- `unreached-target.json`: Valid saved mesh; target residual 9.999987571 cm exceeds 0.2 cm. Height target is 190 cm, achieved neutral height is 180.000012429 cm.

All six neutral meshes were independently reconstructed in NumPy from the matching asset and each state’s morph coefficients, including states rejected by the bundled structural validator. `neutral_mesh_checked: true` records this executed calculation; it does not make an invalid state usable. Full calculations and actual validator failures are retained in `checks.json`.

The unreached-target state is structurally valid and preserves a supported mesh, but does not achieve 190 cm. It is usable only as an explicitly disclosed closest-supported saved result, not as an achieved 190 cm handoff. No optimization or proof of global optimality was performed.

The posed OBJ has 13,380 finite vertices; its Y-up bounding-box height is 132.672357000 cm, versus neutral standing height 180.000012429 cm. Pose changes the bounding box. The OBJ is already cm; no unit conversion was applied.

Measurement definitions: height is the Y range of neutral bodyVertexIds; bust, waist, hips, upperArm, thigh, neck and calf are sums along asset surface tape paths; shoulders, upperArmLength, forearmLength and thighLength are named two-landmark distances. They are not plane-section circumferences or joint spacing. Values are in measurements.csv and audit.json; all have basis mesh_parameter.

Provenance: all six state hashes and the OBJ hash match source.json; the asset SHA-256 matches the states and manifest. Inputs were preserved. The numerical tolerance is 0.002 cm for reconstruction agreement and 0.2 cm for achieved-target classification, not a human measurement accuracy guarantee.

Unavailable/not run: camera recovery (not in the state/OBJ contract), browser roundtrip and slider behavior, image/render validation, independent posed skinning correspondence, GLB/export validation, physical tissue or garment simulation, photographic/person measurement validation. No network, generation, spending or input modification was used.
