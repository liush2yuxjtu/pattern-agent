#!/usr/bin/env python3
"""Read-only anatomical state audit. Run from repository root; no network required."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np

RANGES = dict(height=(145,195), bust=(72,120), waist=(54,108), hips=(80,126),
              shoulders=(30,46), upperArm=(20,40), thigh=(40,76), neck=(28,44),
              upperArmLength=(24,38), forearmLength=(18,31), thighLength=(30,52), calf=(28,48))
FILES = ['reference.json', 'metre-label.json', 'nonfinite-angle.json',
         'pose-joint.json', 'reported-bust.json', 'unreached-target.json']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def finite(v):
    return type(v) in (int, float) and math.isfinite(v)

def reconstruct(asset, weights):
    """Independent NumPy reconstruction from original coordinates and sparse morphs."""
    p = np.asarray(asset['vertices'], dtype=np.float64).reshape(-1,3).copy()
    assert np.isfinite(p).all()
    for control, weight in zip(asset['controls'], weights):
        entries = np.asarray(control['incr' if weight >= 0 else 'decr'], dtype=np.float64)
        if len(entries):
            # add.at also correctly handles any repeated sparse vertex entries.
            np.add.at(p, entries[:,0].astype(int), abs(weight)*entries[:,1:])
    result = {'height': float(np.ptp(p[asset['bodyVertexIds'],1]))}
    for control in asset['controls'][1:]:
        path = p[control['path']]
        result[control['key']] = float(np.linalg.norm(np.diff(path,axis=0),axis=1).sum())
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs',type=Path,default=Path('work/anatomical-skill-evals-20261117/fixtures/state-audit'))
    parser.add_argument('--asset',type=Path,default=Path('web/human-studio/assets/human.json'))
    parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    asset = json.loads(args.asset.read_text())
    asset_hash = sha(args.asset)
    assert asset['schema']==1 and asset['unit']=='cm'
    assert [c['key'] for c in asset['controls']]==list(RANGES)
    bone_names = {b['name'] for b in asset['bones']}
    source = json.loads((args.inputs/'source.json').read_text())
    hashes = {f:sha(args.inputs/f) for f in FILES+['posed-cm.obj']}
    assert source['asset_sha256']==asset_hash
    assert all(source['files'][f]==h for f,h in hashes.items()), 'Source manifest hash mismatch'
    cases = []
    details = {}
    for filename in FILES:
        state = json.loads((args.inputs/filename).read_text())
        errors = []
        if state.get('version')!='makehuman-cm-rig-v1': errors.append('Unsupported model version')
        if state.get('asset')!=asset_hash: errors.append('Asset fingerprint mismatch')
        if state.get('units')!='cm': errors.append('State units must be cm; relabelling as m is invalid')
        for field in ['dimensions','measuredNeutral']:
            values = state.get(field,{})
            if set(values)!=set(RANGES) or not all(finite(v) and v>0 for v in values.values()):
                errors.append('Invalid '+field)
        for key,(lo,hi) in RANGES.items():
            value = state['dimensions'][key]
            if not finite(value) or not lo<=value<=hi or abs(value*10-round(value*10))>1e-7:
                errors.append('Invalid target '+key)
        weights = state.get('morphWeights')
        valid_weights = isinstance(weights,list) and len(weights)==12 and all(finite(v) and -2<=v<=2 for v in weights)
        if not valid_weights: errors.append('Invalid morphWeights')
        pose = state.get('poseDegrees')
        if not isinstance(pose,dict):
            errors.append('Missing pose map')
            pose = {}
        for joint, triple in pose.items():
            if joint not in bone_names: errors.append('Unknown edited joint: '+joint)
            if not (isinstance(triple,list) and len(triple)==3 and all(finite(v) and -180<=v<=180 and abs(v*10-round(v*10))<1e-7 for v in triple)):
                errors.append('Invalid/nonfinite degree rotation: '+joint)
        checked = valid_weights and state.get('asset')==asset_hash
        measured = reconstruct(asset,weights) if checked else None
        residual = max(abs(measured[k]-state['dimensions'][k]) for k in RANGES) if measured else None
        mismatch = max(abs(measured[k]-state['measuredNeutral'][k]) for k in RANGES) if measured else None
        if mismatch is not None and mismatch>=.002:
            errors.append(f'Saved measuredNeutral disagrees with independently reconstructed mesh by {mismatch:.9f} cm')
        self_residual = max(abs(state['dimensions'][k]-state['measuredNeutral'][k]) for k in RANGES)
        reported = state.get('maximumTargetErrorCm')
        if not finite(reported) or reported<0 or abs(reported-self_residual)>=.002:
            errors.append('False reported maximumTargetErrorCm')
        classification = 'invalid' if errors else ('verified' if residual<=.2 else 'closest_supported')
        reason = '; '.join(errors) if errors else ('Matching asset, finite valid pose and neutral measurements independently recomputed; targets achieved within 0.2 cm' if classification=='verified' else f'Valid saved model and measurements, but target residual {residual:.9f} cm exceeds 0.2 cm; usable only as an unmet-target/closest-supported state')
        cases.append(dict(file=filename,classification=classification,reason=reason,
                          neutral_mesh_checked=checked,maximum_target_error_cm=residual))
        details[filename] = dict(recomputed_neutral=measured,maximum_saved_measurement_difference_cm=mismatch,
                                 target_dimensions=state['dimensions'],reported_maximum_target_error_cm=reported,
                                 edited_joint_count=len(pose),errors=errors)
    vertices = []
    face_count = 0
    for line in (args.inputs/'posed-cm.obj').read_text().splitlines():
        if line.startswith('v '): vertices.append([float(x) for x in line.split()[1:4]])
        elif line.startswith('f '): face_count+=1
    posed = np.asarray(vertices)
    assert posed.shape==(len(asset['bodyVertexIds']),3) and np.isfinite(posed).all()
    assert face_count==len(asset['indices'])//3
    bbox_height = float(np.ptp(posed[:,1]))
    reference_measurements = details['reference.json']['recomputed_neutral']
    audit = dict(cases=cases,measurements=reference_measurements,basis='mesh_parameter',
                 pose_bbox_height_cm=bbox_height,camera_recovered=False,
                 real_person_accuracy_established=False,input_hashes=hashes)
    (args.out/'audit.json').write_text(json.dumps(audit,indent=2,allow_nan=False)+'\n')
    evidence = dict(asset_sha256=asset_hash,source_manifest_sha256=sha(args.inputs/'source.json'),
                    source_manifest_hashes_matched=True,cases=details,
                    posed_obj=dict(vertex_count=len(vertices),face_count=face_count,
                        xyz_spans_cm=np.ptp(posed,axis=0).tolist(),finite_vertices=True),
                    measurement_tolerance_cm=.002,target_tolerance_cm=.2,
                    neutral_mesh_checked_semantics='Coordinates reconstructed and measured, including structurally invalid cases; does not imply valid pose or units')
    (args.out/'checks.json').write_text(json.dumps(evidence,indent=2,allow_nan=False)+'\n')
    with (args.out/'measurements.csv').open('w',newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['key','value','unit','basis'])
        writer.writerows((key,value,'cm','mesh_parameter') for key,value in reference_measurements.items())
    lines = ['# Anatomical state handoff audit','',
             'The usable achieved-target state is **reference.json**. These controlled model data establish mesh consistency, not real-person accuracy. No inputs were modified.','',
             '| State | Classification | Reason |','| --- | --- | --- |']
    lines.extend(f"| {c['file']} | {c['classification']} | {c['reason']} |" for c in cases)
    lines += ['',f'All six neutral meshes were independently reconstructed from matching MakeHuman asset `{asset_hash}` using the saved morph coefficients. Height uses the surface Y span; other values use the asset’s tape paths or landmark paths. All 12 reference values are in measurements.csv and audit.json. The maximum reference target residual is {cases[0]["maximum_target_error_cm"]:.9f} cm.',
              '', 'For invalid cases, neutral_mesh_checked=true records the actual independent shape reconstruction; it does not approve their units, pose, or self-reported measurements. The corrupted bust reports 98.004172058 cm, while the mesh yields '+f'{reference_measurements["bust"]:.9f} cm.',
              '', 'unreached-target.json retains the same measured neutral height '+f'{reference_measurements["height"]:.9f} cm against a 190 cm target. It is valid as a saved closest-supported/unmet-target state, not an achieved 190 cm body. This audit does not re-optimize or prove a global nearest solution.',
              '', f'The provided posed OBJ has {len(vertices)} finite vertices and {face_count} faces. Its Y-up bounding-box height is {bbox_height:.9f} cm. Bent knees make this a posed extent, not neutral standing height. Units are interpreted using the supplied cm contract and matching manifest; no independent absolute physical scale was measured.',
              '', 'Camera recovery: unavailable (the state has no camera). Not run: browser import/reload, animated joint deformation, independent posed skinning correspondence, GLB/metre comparison, collisions, photos or physical fit. A valid joint name and finite angle do not establish collision-free anatomy. No image generation, network or paid compute was used.',
              '', 'Reproduce from the repository root:', '```sh', f'python {Path(__file__).resolve().relative_to(Path.cwd())}', '```']
    (args.out/'report.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(dict(classifications={c['file']:c['classification'] for c in cases},
                          reference_max_error_cm=cases[0]['maximum_target_error_cm'],posed_bbox_height_cm=bbox_height),indent=2))

if __name__=='__main__':
    main()
