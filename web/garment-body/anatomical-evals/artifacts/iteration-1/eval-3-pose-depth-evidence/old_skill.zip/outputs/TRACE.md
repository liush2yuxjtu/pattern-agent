# Executed synthetic anatomical pose/depth evidence

Applied the provided garment-body-six-view skill snapshot and its Human Studio and tools/evidence references. Read repository AGENTS.md. Task explicitly prohibits commits and limits writes to this outputs directory, so no commit, push or shared-source modification was performed. No network, image generation, paid tools, or additional agents were used. Private oracles, graders and other runs were not inspected.

## Reproduce

From any working directory with this checkout available:

```sh
python /workspace/work/pattern-agent/work/anatomical-skill-evals-20261117/iteration-1/eval-3-pose-depth-evidence/old_skill/run-1/outputs/run.py
```

The script copies the supplied posed surface to final.obj, neutral surface to neutral.obj, and the exact source state, camera and all 163 rig joint entries. It calls the supplied generic triangle renderer with --joints joints.json. It does not refit, reconstruct, change vertex order, change poses, or auto-fit the camera. All geometry remains Y-up centimetres.

Then it reopens every delivered OBJ, JSON, six PNG images, six masks, raw depth arrays, valid mask and pose-joints file. Neutral tape measurements are computed from delivered neutral.obj, remapping the actual asset's original control path vertex indices through bodyVertexIds. These are tape paths and landmark distances, not arbitrary horizontal plane sections. Asset SHA256 matches saved state. Each image and mask is compared to the supplied fixture's public reference-renders.

## Observed results

- Exact posed and neutral source coordinates and triangle topology retained; 13,380 finite vertices, 26,756 triangles.
- State and camera are exactly equal to fixture metadata. Joints exactly preserve the supplied source rig positions, parents and names.
- Neutral standing height: 179.9999101 cm. Seated posed bounding-box height: 132.672357 cm. Difference: 47.3275531 cm.
- Maximum recomputed neutral dimension discrepancy against source-state measuredNeutral: 0.0041091131 cm. All twelve actual neutral measurements and definitions are in metrics.json. Requested dimensions remain separately preserved.
- All six image mean absolute pixel errors: 0.0. All six masks IoU: 1.0. Pose colored annotation error: 0.0.
- Both depth.npy and rawdepth.npy are float32 nearest-triangle signed side depth (source X, larger nearer), with -inf background. depth-valid.png exactly equals finite depth coverage. depth.png is single channel uint8: 0 background, 1..254 fixed depth_range_cm encoding.
- Independent Moller-Trumbore 3D ray-triangle intersections at 40 deterministically distributed valid pixels: maximum raw-depth error 0.00000165523 cm. The per-pixel comparisons are recorded in metrics.json.
- All 163 saved joint projections match the supplied frozen camera with maximum error 0.0 px; parent-child edge list and inside-canvas flags also checked.
- Opened actual saved pose.png and depth.png using the image viewer; seated legs and flexed arms are visible, skeleton annotations follow actual rig joints, and depth matches the same side projection. All other saved PNGs were reopened as arrays for numerical comparison.

## Limits

This is a synthetic CC0 MakeHuman model control, not measurements of a photographed person. The source posed surface was preserved rather than independently re-skinned from the state. Neutral tape measures and pose dimensions are separate. Rig visibility means inside canvas, not occlusion. Skeletal skinning does not certify anatomical tissue, collision correctness or physical garment fit. Numerical rendering comparison uses the supplied public fixture reference; independent ray intersections and camera projections check saved geometric evidence separately.

manifest.json records SHA256 for generated evidence and the runnable script at execution time. TRACE.md was written after that manifest, so is not included in the initial execution manifest.
