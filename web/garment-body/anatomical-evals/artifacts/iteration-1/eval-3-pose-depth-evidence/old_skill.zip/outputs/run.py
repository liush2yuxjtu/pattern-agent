#!/usr/bin/env python3
"""Reproduce the exact source surface and deterministic renders; audit actual saved files."""
from pathlib import Path
import hashlib, importlib.util, json, shutil, subprocess, sys
import cv2
import numpy as np
OUT=Path(__file__).resolve().parent
ROOT=next(p for p in OUT.parents if (p/'web/human-studio/assets/human.json').exists())
BASE=ROOT/'work/anatomical-skill-evals-20261117'
FIX=BASE/'fixtures/pose-depth-evidence'
def read(p): return json.loads(p.read_text())
def dump(p,d): p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for src,dst in [('source-posed.obj','final.obj'),('source-neutral.obj','neutral.obj'),('source-state.json','state.json'),('source-joints.json','joints.json'),('camera.json','camera.json')]:shutil.copyfile(FIX/src,OUT/dst)
subprocess.run([sys.executable,str(BASE/'fixtures/render_mesh.py'),'--mesh',str(OUT/'final.obj'),'--camera',str(OUT/'camera.json'),'--joints',str(OUT/'joints.json'),'--out',str(OUT/'renders')],check=True)
# All subsequent checks reopen the delivered artifacts.
spec=importlib.util.spec_from_file_location('renderer',BASE/'fixtures/render_mesh.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
v,f=r.obj(OUT/'final.obj');n,nf=r.obj(OUT/'neutral.obj');sv,sf=r.obj(FIX/'source-posed.obj');sn,snf=r.obj(FIX/'source-neutral.obj')
assert v.shape==(13380,3) and f.shape==(26756,3) and np.isfinite(v).all()
assert np.array_equal(f,sf) and np.array_equal(nf,snf) and np.array_equal(v,sv) and np.array_equal(n,sn)
state=read(OUT/'state.json');camera=read(OUT/'camera.json');joints=read(OUT/'joints.json');assetpath=ROOT/'web/human-studio/assets/human.json';asset=read(assetpath)
assert state==read(FIX/'source-state.json') and camera==read(FIX/'camera.json') and joints==read(FIX/'source-joints.json')
assert sha(assetpath)==state['asset'] and len(joints['joints'])==len(asset['bones'])==163
assert joints['units']=='cm'
# Tape paths use original asset vertex ids, so remap to the preserved compact surface order.
ids={original:i for i,original in enumerate(asset['bodyVertexIds'])}
measured={'height':float(np.ptp(n[:,1]))};methods={'height':'neutral standing Y extent'}
for c in asset['controls'][1:]:
    p=n[[ids[i] for i in c['path']]]
    measured[c['key']]=float(np.linalg.norm(np.diff(p,axis=0),axis=1).sum())
    methods[c['key']]='landmark_distance' if len(p)==2 else 'surface_tape_path'
neutral_height=measured['height'];posed_height=float(np.ptp(v[:,1]));assert neutral_height-posed_height>20
maxdim=max(abs(measured[k]-state['measuredNeutral'][k]) for k in measured);assert maxdim<.03
renders={}
for view in camera['views']:
    image=cv2.imread(str(OUT/'renders'/f'{view}.png'),cv2.IMREAD_UNCHANGED)
    reference=cv2.imread(str(FIX/'reference-renders'/f'{view}.png'),cv2.IMREAD_UNCHANGED)
    mask=cv2.imread(str(OUT/'renders'/f'{view}-mask.png'),0)>0
    refmask=cv2.imread(str(FIX/'reference-renders'/f'{view}-mask.png'),0)>0
    mae=float(np.abs(image.astype(float)-reference.astype(float)).mean());iou=float((mask&refmask).sum()/(mask|refmask).sum())
    assert mae<=2 and iou>=.99
    renders[view]={'shape':list(image.shape),'mean_absolute_pixel_error':mae,'mask_iou':iou}
z=np.load(OUT/'renders/rawdepth.npy');z2=np.load(OUT/'renders/depth.npy');valid=cv2.imread(str(OUT/'renders/depth-valid.png'),0)
assert z.dtype==np.float32 and np.array_equal(z,z2) and np.array_equal(valid,np.isfinite(z).astype(np.uint8)*255) and np.isneginf(z[valid==0]).all()
dep=cv2.imread(str(OUT/'renders/depth.png'),cv2.IMREAD_UNCHANGED);assert dep.dtype==np.uint8 and dep.ndim==2
assert np.all(dep[valid==0]==0)
# Independent 3D ray / triangle intersections (Moller-Trumbore), outside rasterizer code.
c=camera['views']['depth'];assert c['axis']=='side'
tri=v[f];e1=tri[:,1]-tri[:,0];e2=tri[:,2]-tri[:,0];direction=np.array([-1.,0.,0.]);h=np.cross(np.broadcast_to(direction,e2.shape),e2);a=np.einsum('ij,ij->i',e1,h);nonparallel=np.abs(a)>1e-12;inv=np.zeros_like(a);inv[nonparallel]=1/a[nonparallel]
yx=np.argwhere(np.isfinite(z));samples=yx[np.linspace(0,len(yx)-1,40,dtype=int)];errors=[];records=[]
for yy,xx in samples:
    horizontal=(xx-camera['width']/2)/c['px_per_cm']+c['center_cm'][0];vertical=(camera['height']/2-yy)/c['px_per_cm']+c['center_cm'][1]
    origin=np.array([1000.,vertical,horizontal]);s=origin-tri[:,0];u=inv*np.einsum('ij,ij->i',s,h);q=np.cross(s,e1);vv=inv*(q@direction);t=inv*np.einsum('ij,ij->i',e2,q)
    hits=nonparallel&(u>=-1e-7)&(vv>=-1e-7)&(u+vv<=1+1e-7)&(t>=0)
    assert hits.any();expected=float(1000-t[hits].min());error=abs(expected-float(z[yy,xx]));errors.append(error);records.append({'pixel':[int(xx),int(yy)],'intersection_depth_cm':expected,'saved_depth_cm':float(z[yy,xx]),'error_cm':error})
assert max(errors)<.001
pj=read(OUT/'renders/pose-joints.json');c=camera['views']['pose'];joint_by_name={j['name']:j for j in joints['joints']};jerrors=[]
for row in pj['joints']:
    original=joint_by_name[row['name']];x,y,zz=original['position'];horizontal=zz if c['axis']=='side' else (-x if c['axis']=='back' else x)
    expected=np.array([(horizontal-c['center_cm'][0])*c['px_per_cm']+camera['width']/2,camera['height']/2-(y-c['center_cm'][1])*c['px_per_cm']]);jerrors.append(float(np.linalg.norm(expected-row['pixel'])))
    assert row['world_cm']==original['position'] and row['visible']==bool(0<=expected[0]<camera['width'] and 0<=expected[1]<camera['height'])
assert max(jerrors)<.001
expectededges=[[j['parent'],j['name']] for j in joints['joints'] if j.get('parent') in joint_by_name];assert pj['edges']==expectededges
colored=cv2.imread(str(OUT/'renders/pose.png'));refcolored=cv2.imread(str(FIX/'reference-renders/pose.png'));annotation=np.any(refcolored.max(2,keepdims=True)-refcolored.astype(float)>100,axis=2)
annmae=float(np.abs(colored.astype(float)-refcolored.astype(float))[annotation].mean());assert annmae<=2
metrics={'units':'cm','coordinate_system':'X left/right; Y up; Z front/back','mode':'synthetic_control','neutral_height_cm':neutral_height,'posed_height_cm':posed_height,'neutralHeightCm':neutral_height,'posedHeightCm':posed_height,'height_difference_cm':neutral_height-posed_height,'measuredNeutral':measured,'neutral_measurements_cm':measured,'measurement_methods':methods,'dimensions':state['dimensions'],'maximum_neutral_measurement_difference_cm':maxdim,'maximumTargetErrorCm':max(abs(measured[k]-state['dimensions'][k]) for k in measured),'topology':{'vertices':len(v),'triangles':len(f),'source_vertex_order_and_faces_preserved':True},'source_coordinate_max_error_cm':float(np.abs(v-sv).max()),'neutral_coordinate_max_error_cm':float(np.abs(n-sn).max()),'fixed_camera_exact':True,'renders':renders,'pose_annotation_mae':annmae,'rig_bones':len(joints['joints']),'maximum_joint_pixel_error':max(jerrors),'rawdepth':{'dtype':str(z.dtype),'semantics':'nearest triangle signed source X for side; larger is nearer; background -inf','valid_pixels':int(np.isfinite(z).sum()),'independent_ray_test_count':len(errors),'maximum_error_cm':max(errors),'tests':records},'limitations':['Synthetic MakeHuman control, not a photograph or a recovered human body.','Measurements describe the neutral model surface; seated bounding-box height is distinct.','Skeleton visibility means inside canvas, not occlusion.','Skinning is not tissue or physical collision simulation.']}
dump(OUT/'metrics.json',metrics)
dump(OUT/'manifest.json',{str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name not in ['manifest.json']})
print(json.dumps({k:metrics[k] for k in ['neutral_height_cm','posed_height_cm','maximum_neutral_measurement_difference_cm','maximum_joint_pixel_error','pose_annotation_mae']}));print('Independent ray max error cm:',max(errors));print('All six image MAE:',{k:d['mean_absolute_pixel_error'] for k,d in renders.items()})
