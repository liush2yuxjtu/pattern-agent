#!/usr/bin/env python3
"""Reproduce posed anatomical control and independently audit saved geometry."""
import hashlib, importlib.util, json, platform, shutil, subprocess, sys
from pathlib import Path
import cv2
import numpy as np
OUT=Path(__file__).resolve().parent
ROOT=next(p for p in OUT.parents if (p/'web/human-studio/assets/human.json').is_file())
BASE=ROOT/'work/anatomical-skill-evals-20261117'
SRC=BASE/'fixtures/pose-depth-evidence'
ASSET=ROOT/'web/human-studio/assets/human.json'
def load(p): return json.loads(p.read_text())
def save(p,x): p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def obj(p):
    vertices=[]; faces=[]
    for line in p.read_text().splitlines():
        t=line.split()
        if t and t[0]=='v': vertices.append([float(n) for n in t[1:4]])
        elif t and t[0]=='f':
            ix=[int(x.split('/')[0])-1 for x in t[1:]]
            faces.extend([[ix[0],ix[i],ix[i+1]] for i in range(1,len(ix)-1)])
    return np.array(vertices),np.array(faces)
for src,dst in [('source-posed.obj','final.obj'),('source-neutral.obj','neutral.obj'),('source-state.json','state.json'),('source-joints.json','joints.json'),('camera.json','camera.json')]:
    shutil.copyfile(SRC/src,OUT/dst)
subprocess.run([sys.executable,str(BASE/'fixtures/render_mesh.py'),'--mesh',str(OUT/'final.obj'),'--camera',str(OUT/'camera.json'),'--joints',str(OUT/'joints.json'),'--out',str(OUT/'renders')],check=True)
# Reopen every contract file rather than relying on in-memory source values.
v,f=obj(OUT/'final.obj'); n,nf=obj(OUT/'neutral.obj'); source,sf=obj(SRC/'source-posed.obj'); sn,snf=obj(SRC/'source-neutral.obj')
state=load(OUT/'state.json'); camera=load(OUT/'camera.json'); joints=load(OUT/'joints.json'); asset=load(ASSET)
assert v.shape==(13380,3) and f.shape==(26756,3) and np.isfinite(v).all()
assert np.array_equal(f,sf) and np.array_equal(nf,snf) and np.array_equal(v,source) and np.array_equal(n,sn)
assert load(SRC/'camera.json')==camera and load(SRC/'source-state.json')==state and load(SRC/'source-joints.json')==joints
assert sha(ASSET)==state['asset']
# Independent tape measurement on the saved compact neutral OBJ via asset index map.
compact={int(original):i for i,original in enumerate(asset['bodyVertexIds'])}
measured={'height':float(np.ptp(n[:,1]))}
for control in asset['controls'][1:]:
    path=n[[compact[i] for i in control['path']]]
    measured[control['key']]=float(np.linalg.norm(np.diff(path,axis=0),axis=1).sum())
# Independent full-rest reconstruction from actual sparse morph targets.
rest=np.asarray(asset['vertices'],float).reshape(-1,3).copy()
for c,weight in zip(asset['controls'],state['morphWeights']):
    changes=np.asarray(c['incr' if weight>=0 else 'decr'],float)
    rest[changes[:,0].astype(int)]+=abs(weight)*changes[:,1:]
rest_surface=rest[asset['bodyVertexIds']].copy();rest_surface[:,1]-=rest_surface[:,1].min()
neutral_reconstruction_error=float(np.max(np.abs(rest_surface-n)))
assert neutral_reconstruction_error<.003
assert max(abs(measured[k]-state['measuredNeutral'][k]) for k in measured)<.03
# Independent ray/triangle hit audit. Orthographic side rays point along -X;
# solve 3-D ray intersections from a plane beyond the entire source surface.
z=np.load(OUT/'renders/rawdepth.npy'); zcopy=np.load(OUT/'renders/depth.npy')
valid=cv2.imread(str(OUT/'renders/depth-valid.png'),cv2.IMREAD_UNCHANGED)
dep=cv2.imread(str(OUT/'renders/depth.png'),cv2.IMREAD_UNCHANGED)
assert z.dtype==np.float32 and np.array_equal(z,zcopy) and np.array_equal(valid,np.isfinite(z).astype(np.uint8)*255)
assert np.isneginf(z[valid==0]).all() and dep.ndim==2 and dep.dtype==np.uint8
finite=np.argwhere(np.isfinite(z)); chosen=finite[np.linspace(0,len(finite)-1,40,dtype=int)]
tri=v[f]; e1=tri[:,1]-tri[:,0];e2=tri[:,2]-tri[:,0]; direction=np.array([-1.,0.,0.])
h=np.cross(np.broadcast_to(direction,e2.shape),e2);a=np.einsum('ij,ij->i',e1,h); good=np.abs(a)>1e-12
inv=np.zeros_like(a);inv[good]=1/a[good]
c=camera['views']['depth']; assert c['axis']=='side'
hit_rows=[]
for y,x in chosen:
    yworld=c['center_cm'][1]+(camera['height']/2-y)/c['px_per_cm']
    zworld=c['center_cm'][0]+(x-camera['width']/2)/c['px_per_cm']
    origin=np.array([v[:,0].max()+10,yworld,zworld]);s=origin-tri[:,0]
    u=inv*np.einsum('ij,ij->i',s,h);q=np.cross(s,e1);vv=inv*(q@direction);t=inv*np.einsum('ij,ij->i',e2,q)
    hits=good&(u>=-1e-7)&(vv>=-1e-7)&(u+vv<=1+1e-7)&(t>=0)
    assert hits.any()
    actual=float(origin[0]-t[hits].min()); error=abs(actual-float(z[y,x]));assert error<.001
    hit_rows.append({'pixel':[int(x),int(y)],'triangle_hit_depth_cm':actual,'saved_depth_cm':float(z[y,x]),'absolute_error_cm':error})
# All skeleton heads projected separately with double precision.
proj=load(OUT/'renders/pose-joints.json'); saved={j['name']:j for j in proj['joints']}; c=camera['views']['pose'];errors=[]
assert len(joints['joints'])==len(asset['bones'])==163
expected_edges=[]
for j in joints['joints']:
    p=j['position']; horizontal=p[2] if c['axis']=='side' else p[0]*(-1 if c['axis']=='back' else 1)
    pixel=np.array([(horizontal-c['center_cm'][0])*c['px_per_cm']+camera['width']/2,camera['height']/2-(p[1]-c['center_cm'][1])*c['px_per_cm']])
    row=saved[j['name']];errors.append(float(np.max(np.abs(pixel-row['pixel']))))
    assert row['world_cm']==p and row['visible']==bool(0<=pixel[0]<camera['width'] and 0<=pixel[1]<camera['height'])
    if j.get('parent') in saved:expected_edges.append([j['parent'],j['name']])
assert proj['edges']==expected_edges and max(errors)<.001
# Decode depth semantics independently from float32 raw buffer (quantization <=1).
lo,hi=camera['depth_range_cm'];expect=np.clip(1+253*(z[valid>0].astype(float)-lo)/(hi-lo),1,254).astype(np.uint8)
dep_error=float(np.max(abs(expect.astype(float)-dep[valid>0].astype(float))))
assert dep_error<=1 and (dep[valid==0]==0).all()
images={}
for view in camera['views']:
    im=cv2.imread(str(OUT/'renders'/f'{view}.png'),cv2.IMREAD_UNCHANGED); mask=cv2.imread(str(OUT/'renders'/f'{view}-mask.png'),0)
    assert im.shape[:2]==(camera['height'],camera['width']) and mask.shape==(camera['height'],camera['width'])
    images[view]={'width':im.shape[1],'height':im.shape[0],'channels':1 if im.ndim==2 else im.shape[2],'mask_pixels':int((mask>0).sum()),'sha256':sha(OUT/'renders'/f'{view}.png')}
# Independent raw-OBJ silhouette projections, plus comparison with public fixture renders.
render_checks={}
for view,c in camera['views'].items():
    axis=c['axis']; horizontal=v[:,2] if axis=='side' else v[:,0]*(-1 if axis=='back' else 1)
    xy=np.column_stack(((horizontal-c['center_cm'][0])*c['px_per_cm']+camera['width']/2,camera['height']/2-(v[:,1]-c['center_cm'][1])*c['px_per_cm']))
    independent=np.zeros((camera['height'],camera['width']),np.uint8)
    for face in f: cv2.fillConvexPoly(independent,np.round(xy[face]).astype(np.int32),255)
    mask=cv2.imread(str(OUT/'renders'/f'{view}-mask.png'),0)
    a=independent>0;b=mask>0;iou=float((a&b).sum()/(a|b).sum())
    im=cv2.imread(str(OUT/'renders'/f'{view}.png'),cv2.IMREAD_UNCHANGED)
    ref=cv2.imread(str(SRC/'reference-renders'/f'{view}.png'),cv2.IMREAD_UNCHANGED)
    mae=float(np.mean(np.abs(im.astype(float)-ref.astype(float))))
    assert iou>=.99 and mae<=2
    row={'independent_raw_obj_mask_iou':iou,'public_fixture_render_mae':mae}
    if view=='pose':
        annotation=(ref[:,:,2]>200)&(ref[:,:,0]<50)
        row['public_fixture_annotation_pixel_mae']=float(np.mean(np.abs(im[annotation].astype(float)-ref[annotation].astype(float))))
        assert row['public_fixture_annotation_pixel_mae']<=2
    render_checks[view]=row
metrics={'render_checks':render_checks,'basis' :'synthetic anatomical model; not a photographed person','units':'cm','coordinate_convention':'Y-up; original vertex order','vertices':len(v),'triangles':len(f),'neutralHeightCm':measured['height'],'posedHeightCm':float(np.ptp(v[:,1])),'neutral_height_cm':measured['height'],'posed_height_cm':float(np.ptp(v[:,1])),'measuredNeutral':measured,'neutral_measurements_cm':measured,'dimensions':state['dimensions'],'maximumTargetErrorCm':max(abs(measured[k]-state['dimensions'][k]) for k in measured),'maximum_neutral_reconstruction_coordinate_error_cm':neutral_reconstruction_error,'posed_source_max_coordinate_error_cm':float(np.max(abs(v-source))),'neutral_source_max_coordinate_error_cm':float(np.max(abs(n-sn))),'fixed_camera_preserved':True,'rawdepth_valid_pixels':int((valid>0).sum()),'independent_ray_triangle_samples':hit_rows,'max_independent_depth_error_cm':max(r['absolute_error_cm'] for r in hit_rows),'joint_count':len(saved),'max_joint_projection_error_px':max(errors),'depth_encoding_max_error':dep_error,'images':images,'limitations':['Synthetic control only; no inference about a photographed person.','Neutral tape measurements describe standing neutral geometry; seated height is a separate posed bounding box.','Rig visibility means inside canvas, not occlusion.','Skinning is not physical tissue or collision simulation.']}
assert metrics['neutralHeightCm']-metrics['posedHeightCm']>20
save(OUT/'metrics.json',metrics)
files=['final.obj','neutral.obj','state.json','camera.json','joints.json','metrics.json']+[str(p.relative_to(OUT)) for p in sorted((OUT/'renders').glob('*'))]
save(OUT/'manifest.json',{'inputs':{str(p.relative_to(ROOT)):sha(p) for p in [SRC/'source-posed.obj',SRC/'source-neutral.obj',SRC/'source-state.json',SRC/'source-joints.json',SRC/'camera.json',ASSET,BASE/'fixtures/render_mesh.py']},'outputs':{p:sha(OUT/p) for p in files},'software':{'python':sys.version,'numpy':np.__version__,'opencv':cv2.__version__,'platform':platform.platform()}})
print(json.dumps({k:metrics[k] for k in ['vertices','triangles','neutralHeightCm','posedHeightCm','max_independent_depth_error_cm','max_joint_projection_error_px','maximum_neutral_reconstruction_coordinate_error_cm','joint_count']},indent=2))
