# Executed pose/depth evidence

Run from repository root:

```sh
python work/anatomical-skill-evals-20261117/iteration-1/eval-3-pose-depth-evidence/with_skill/run-1/outputs/run_evidence.py
```

The script was executed twice, with the final run including every check described here. It copies the supplied actual skinned posed mesh and neutral mesh byte-for-byte, retaining centimetres, Y-up, all 13,380 vertices in source order and all 26,756 triangles. The complete original state, frozen camera, and genuine 163-bone posed skeleton are also copied unchanged. It calls the supplied `fixtures/render_mesh.py` with `--joints joints.json`; it does not copy any reference image into the output.

All saved meshes, JSON, six images, six masks, raw arrays and validity image were reopened and parsed. Inputs and outputs are SHA-256 bound in `manifest.json`; Python, NumPy and OpenCV versions are recorded there. No source, fixtures, skill files or other output directories were modified.

## Actual results

- Standing neutral height measured from saved neutral OBJ: **179.9999101 cm**.
- Seated posed bounding-box height measured from saved final OBJ: **132.672357 cm**. These are different quantities, separated in metrics.
- All 12 neutral measurements were recomputed from saved neutral OBJ using actual asset surface tape paths / landmarks. Maximum target residual: **0.000248508 cm**. Preserved state contains its original full-rest measurements; those differ slightly from exported, rounded surface coordinates and are not overwritten.
- Actual asset fingerprint matches the state. Independently reconstructing full rest geometry with sparse morph targets and grounding its compact surface produced maximum saved-neutral coordinate difference **0.001105075 cm**, within the 0.003 cm surface tolerance.
- Posed and neutral coordinates, topology, source vertex order, dimensions, poseDegrees, joints and camera are exactly preserved from supplied files.
- Independently projected raw-OBJ triangle silhouettes: **IoU 1.0** for all six masks.
- Six images compared to supplied public fixture reference renders: **MAE 0.0** each. Pose annotation colored pixels: **MAE 0.0**.
- Independent 3-D ray/triangle intersections at 40 deterministic finite pixels: maximum raw-depth error **0.00000165523 cm**. Per-pixel samples and errors are saved in metrics.
- All **163** projected joint heads: maximum error **0.0 pixels**; parent edges and inside-canvas flags match independently recomputed values.
- Both rawdepth.npy and depth.npy are float32, equal, and use negative infinity outside finite triangles. depth-valid.png equals their finite mask exactly. Depth encoding validation passed (maximum quantization discrepancy <=1).
- Side, pose and depth images were additionally opened and visually inspected: seated thighs, bent knees and flexed arms are retained; actual joint points/lines align with the body.

## Interpretation and limits

This is a synthetic MakeHuman anatomical control, not a photograph or reconstructed person. Neutral measurements describe model geometry. Seated bbox height is not standing height. Rig `visible` means inside canvas, not unoccluded; lines can cross the visible surface. The fixed depth view is orthographic side projection: raw depth is signed source X in centimetres; larger is nearer, and it is not camera distance. depth.png uses fixed [-90,90] cm mapping to 1..254 with 0 background. All images are 384 x 512, using fixed per-view camera settings, with no automatic fitting. Skinning provides no tissue, joint collision or physical garment-fit claim.

Checks executed locally above passed. No browser UI, new live skinning export, physical simulation or photographed-person validation was performed; those are outside this preservation control. No commits or network operations were performed, following the evaluation task's explicit boundary.
